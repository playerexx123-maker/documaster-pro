import 'package:get_it/get_it.dart';

// Data sources - local
import 'data/datasources/local/database_helper.dart';
import 'data/datasources/local/document_dao.dart';
import 'data/datasources/local/folder_dao.dart';
import 'data/datasources/local/scan_session_dao.dart';
import 'data/datasources/local/ocr_result_dao.dart';
import 'data/datasources/local/annotation_dao.dart';
import 'data/datasources/local/search_index_dao.dart';
import 'data/datasources/local/secure_storage.dart';
import 'data/datasources/local/biometric_auth.dart';

// Data sources - remote
import 'data/datasources/remote/google_drive_api.dart';
import 'data/datasources/remote/dropbox_api.dart';
import 'data/datasources/remote/onedrive_api.dart';

// Services
import 'services/pdf_service.dart';
import 'services/ocr_service.dart';
import 'services/image_processing_service.dart';
import 'services/ai_service.dart';
import 'services/thumbnail_service.dart';

// Repository implementations
import 'data/repositories/document_repository_impl.dart';
import 'data/repositories/folder_repository_impl.dart';
import 'data/repositories/scanner_repository_impl.dart';
import 'data/repositories/ocr_repository_impl.dart';
import 'data/repositories/pdf_editor_repository_impl.dart';
import 'data/repositories/file_manager_repository_impl.dart';
import 'data/repositories/converter_repository_impl.dart';
import 'data/repositories/image_editor_repository_impl.dart';
import 'data/repositories/ai_repository_impl.dart';
import 'data/repositories/search_repository_impl.dart';
import 'data/repositories/cloud_repository_impl.dart';
import 'data/repositories/auth_repository_impl.dart';

// Repository interfaces
import 'domain/repositories/document_repository.dart';
import 'domain/repositories/folder_repository.dart';
import 'domain/repositories/scanner_repository.dart';
import 'domain/repositories/ocr_repository.dart';
import 'domain/repositories/pdf_editor_repository.dart';
import 'domain/repositories/file_manager_repository.dart';
import 'domain/repositories/converter_repository.dart';
import 'domain/repositories/image_editor_repository.dart';
import 'domain/repositories/ai_repository.dart';
import 'domain/repositories/search_repository.dart';
import 'domain/repositories/cloud_repository.dart';
import 'domain/repositories/auth_repository.dart';

// Cubits
import 'presentation/blocs/home/home_cubit.dart';
import 'presentation/blocs/scanner/scanner_cubit.dart';
import 'presentation/blocs/ocr/ocr_cubit.dart';
import 'presentation/blocs/files/files_cubit.dart';
import 'presentation/blocs/editor/editor_cubit.dart';
import 'presentation/blocs/ai_assistant/ai_assistant_cubit.dart';
import 'presentation/blocs/settings/settings_cubit.dart';
import 'presentation/blocs/auth/auth_cubit.dart';
import 'presentation/blocs/search/search_cubit.dart';
import 'presentation/blocs/image_editor/image_editor_cubit.dart';

final GetIt getIt = GetIt.instance;

Future<void> configureDependencies() async {
  // ─── Data Sources ───
  getIt.registerLazySingleton<DocumentDao>(() => DocumentDao());
  getIt.registerLazySingleton<FolderDao>(() => FolderDao());
  getIt.registerLazySingleton<ScanSessionDao>(() => ScanSessionDao());
  getIt.registerLazySingleton<OcrResultDao>(() => OcrResultDao());
  getIt.registerLazySingleton<AnnotationDao>(() => AnnotationDao());
  getIt.registerLazySingleton<SearchIndexDao>(() => SearchIndexDao());
  getIt.registerLazySingleton<SecureStorage>(() => SecureStorage());
  getIt.registerLazySingleton<BiometricAuth>(() => BiometricAuth());

  // ─── Remote APIs ───
  getIt.registerLazySingleton<GoogleDriveApi>(() => GoogleDriveApi());
  getIt.registerLazySingleton<DropboxApi>(() => DropboxApi());
  getIt.registerLazySingleton<OneDriveApi>(() => OneDriveApi());

  // ─── Services ───
  getIt.registerLazySingleton<PdfService>(() => PdfService());
  getIt.registerLazySingleton<OcrService>(() => OcrService());
  getIt.registerLazySingleton<ImageProcessingService>(() => ImageProcessingService());
  getIt.registerLazySingleton<AIService>(() => AIService());
  getIt.registerLazySingleton<ThumbnailService>(() => ThumbnailService());

  // ─── Repositories ───
  getIt.registerLazySingleton<DocumentRepository>(
    () => DocumentRepositoryImpl(getIt<DocumentDao>()),
  );
  getIt.registerLazySingleton<FolderRepository>(
    () => FolderRepositoryImpl(getIt<FolderDao>()),
  );
  getIt.registerLazySingleton<ScannerRepository>(
    () => ScannerRepositoryImpl(
      getIt<ScanSessionDao>(),
      getIt<ImageProcessingService>(),
      getIt<OcrService>(),
      getIt<PdfService>(),
      getIt<DocumentDao>(),
    ),
  );
  getIt.registerLazySingleton<OcrRepository>(
    () => OcrRepositoryImpl(
      getIt<OcrService>(),
      getIt<OcrResultDao>(),
      getIt<DocumentDao>(),
    ),
  );
  getIt.registerLazySingleton<PdfEditorRepository>(
    () => PdfEditorRepositoryImpl(
      getIt<PdfService>(),
      getIt<AnnotationDao>(),
    ),
  );
  getIt.registerLazySingleton<FileManagerRepository>(
    () => FileManagerRepositoryImpl(),
  );
  getIt.registerLazySingleton<ConverterRepository>(
    () => ConverterRepositoryImpl(
      getIt<PdfService>(),
      getIt<ImageProcessingService>(),
    ),
  );
  getIt.registerLazySingleton<ImageEditorRepository>(
    () => ImageEditorRepositoryImpl(getIt<ImageProcessingService>()),
  );
  getIt.registerLazySingleton<AIRepository>(
    () => AIRepositoryImpl(getIt<AIService>()),
  );
  getIt.registerLazySingleton<SearchRepository>(
    () => SearchRepositoryImpl(getIt<SearchIndexDao>()),
  );
  getIt.registerLazySingleton<CloudRepository>(
    () => CloudRepositoryImpl(
      getIt<GoogleDriveApi>(),
      getIt<DropboxApi>(),
      getIt<OneDriveApi>(),
    ),
  );
  getIt.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(
      getIt<BiometricAuth>(),
      getIt<SecureStorage>(),
    ),
  );

  // ─── Cubits ───
  getIt.registerFactory<HomeCubit>(
    () => HomeCubit(getIt<DocumentRepository>()),
  );
  getIt.registerFactory<ScannerCubit>(
    () => ScannerCubit(getIt<ScannerRepository>()),
  );
  getIt.registerFactory<OcrCubit>(
    () => OcrCubit(getIt<OcrRepository>()),
  );
  getIt.registerFactory<FilesCubit>(
    () => FilesCubit(
      getIt<FolderRepository>(),
      getIt<FileManagerRepository>(),
      getIt<DocumentRepository>(),
    ),
  );
  getIt.registerFactory<EditorCubit>(
    () => EditorCubit(getIt<PdfEditorRepository>()),
  );
  getIt.registerFactory<AIAssistantCubit>(
    () => AIAssistantCubit(getIt<AIRepository>()),
  );
  getIt.registerFactory<SettingsCubit>(
    () => SettingsCubit(),
  );
  getIt.registerFactory<AuthCubit>(
    () => AuthCubit(getIt<AuthRepository>()),
  );
  getIt.registerFactory<SearchCubit>(
    () => SearchCubit(getIt<SearchRepository>()),
  );
  getIt.registerFactory<ImageEditorCubit>(
    () => ImageEditorCubit(getIt<ImageEditorRepository>()),
  );
}
