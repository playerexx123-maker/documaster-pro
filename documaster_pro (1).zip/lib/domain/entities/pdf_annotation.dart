import 'package:equatable/equatable.dart';
import 'dart:math';
import 'package:flutter/material.dart';

enum AnnotationType { highlight, underline, strikeout, draw, comment, stickyNote, signature, textBox }
enum Rotation { clockwise90, counterClockwise90, rotate180 }
enum CompressionLevel { low, medium, high }

class PdfAnnotation extends Equatable {
  final int? id;
  final int documentId;
  final int pageNumber;
  final AnnotationType type;
  final Color? color;
  final String? content;
  final List<Point<double>>? points;
  final Rect? rect;
  final DateTime createdAt;
  final DateTime updatedAt;

  const PdfAnnotation({
    this.id,
    required this.documentId,
    required this.pageNumber,
    required this.type,
    this.color,
    this.content,
    this.points,
    this.rect,
    required this.createdAt,
    required this.updatedAt,
  });

  @override
  List<Object?> get props => [id, documentId, pageNumber, type, color, content, points, rect];
}

class WatermarkOptions extends Equatable {
  final String text;
  final double fontSize;
  final Color color;
  final double opacity;
  final int pages;

  const WatermarkOptions({
    required this.text,
    this.fontSize = 48,
    this.color = Colors.grey,
    this.opacity = 0.3,
    this.pages = 0,
  });

  @override
  List<Object?> get props => [text, fontSize, color, opacity, pages];
}

class PageNumberOptions extends Equatable {
  final int startNumber;
  final String format;
  final double fontSize;
  final Color color;
  final String position;

  const PageNumberOptions({
    this.startNumber = 1,
    this.format = '{n}',
    this.fontSize = 12,
    this.color = Colors.black,
    this.position = 'bottom_center',
  });

  @override
  List<Object?> get props => [startNumber, format, fontSize, color, position];
}
