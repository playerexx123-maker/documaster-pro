import 'package:equatable/equatable.dart';

class ConversionJob extends Equatable {
  final int? id;
  final String sourcePath;
  final String? targetPath;
  final String sourceFormat;
  final String targetFormat;
  final String status;
  final double progress;
  final String? errorMessage;
  final DateTime createdAt;
  final DateTime? completedAt;

  const ConversionJob({
    this.id,
    required this.sourcePath,
    this.targetPath,
    required this.sourceFormat,
    required this.targetFormat,
    this.status = 'pending',
    this.progress = 0,
    this.errorMessage,
    required this.createdAt,
    this.completedAt,
  });

  @override
  List<Object?> get props => [id, sourcePath, targetPath, sourceFormat, targetFormat, status, progress];
}
