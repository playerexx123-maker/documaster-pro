import 'package:equatable/equatable.dart';

class CloudFile extends Equatable {
  final String id;
  final String name;
  final int size;
  final String mimeType;
  final DateTime modifiedAt;
  final bool isFolder;
  final String? parentId;

  const CloudFile({
    required this.id,
    required this.name,
    required this.size,
    required this.mimeType,
    required this.modifiedAt,
    this.isFolder = false,
    this.parentId,
  });

  @override
  List<Object?> get props => [id, name, size, mimeType, modifiedAt, isFolder, parentId];
}

class CloudAccount extends Equatable {
  final int? id;
  final String provider;
  final String accountEmail;
  final bool syncEnabled;
  final DateTime? lastSyncAt;
  final DateTime createdAt;

  const CloudAccount({
    this.id,
    required this.provider,
    required this.accountEmail,
    this.syncEnabled = true,
    this.lastSyncAt,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [id, provider, accountEmail, syncEnabled, lastSyncAt];
}
