import 'package:equatable/equatable.dart';
import 'document.dart';

class Folder extends Equatable {
  final int? id;
  final String name;
  final int? parentId;
  final String color;
  final String icon;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<Folder> children;
  final List<Document> documents;

  const Folder({
    this.id,
    required this.name,
    this.parentId,
    this.color = '#2196F3',
    this.icon = 'folder',
    required this.createdAt,
    required this.updatedAt,
    this.children = const [],
    this.documents = const [],
  });

  Folder copyWith({
    int? id,
    String? name,
    int? parentId,
    String? color,
    String? icon,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<Folder>? children,
    List<Document>? documents,
  }) {
    return Folder(
      id: id ?? this.id,
      name: name ?? this.name,
      parentId: parentId ?? this.parentId,
      color: color ?? this.color,
      icon: icon ?? this.icon,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      children: children ?? this.children,
      documents: documents ?? this.documents,
    );
  }

  @override
  List<Object?> get props => [id, name, parentId, color, icon, createdAt, updatedAt];
}
