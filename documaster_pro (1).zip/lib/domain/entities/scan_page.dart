import 'package:equatable/equatable.dart';
import 'dart:math';

enum ScanFilter { none, color, grayscale, bw, autoEnhance, shadowRemoval }
enum SaveFormat { pdf, images }

class ScanSession extends Equatable {
  final int? id;
  final String name;
  final int? documentId;
  final String status;
  final ScanFilter filterType;
  final DateTime createdAt;
  final DateTime? completedAt;
  final List<ScanPage> pages;

  const ScanSession({
    this.id,
    required this.name,
    this.documentId,
    this.status = 'in_progress',
    this.filterType = ScanFilter.color,
    required this.createdAt,
    this.completedAt,
    this.pages = const [],
  });

  @override
  List<Object?> get props => [id, name, documentId, status, filterType, createdAt, completedAt];
}

class ScanPage extends Equatable {
  final int? id;
  final int sessionId;
  final String imagePath;
  final String? processedPath;
  final int pageNumber;
  final List<Point<double>>? edgePoints;
  final String filterApplied;
  final String? ocrText;

  const ScanPage({
    this.id,
    required this.sessionId,
    required this.imagePath,
    this.processedPath,
    required this.pageNumber,
    this.edgePoints,
    this.filterApplied = 'none',
    this.ocrText,
  });

  @override
  List<Object?> get props => [id, sessionId, imagePath, processedPath, pageNumber, edgePoints, filterApplied];
}
