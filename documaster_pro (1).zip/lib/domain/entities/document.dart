import 'package:equatable/equatable.dart';

enum FileType { pdf, docx, xlsx, pptx, txt, md, csv, json, xml, html, image, unknown }

class Document extends Equatable {
  final int? id;
  final String name;
  final String filePath;
  final FileType fileType;
  final int fileSize;
  final int? folderId;
  final int pageCount;
  final String? ocrText;
  final List<String> tags;
  final bool isFavorite;
  final bool isEncrypted;
  final String? passwordHash;
  final String? thumbnailPath;
  final String? cloudSyncId;
  final String? cloudProvider;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? accessedAt;
  final Map<String, dynamic>? metadata;

  const Document({
    this.id,
    required this.name,
    required this.filePath,
    required this.fileType,
    required this.fileSize,
    this.folderId,
    this.pageCount = 1,
    this.ocrText,
    this.tags = const [],
    this.isFavorite = false,
    this.isEncrypted = false,
    this.passwordHash,
    this.thumbnailPath,
    this.cloudSyncId,
    this.cloudProvider,
    required this.createdAt,
    required this.updatedAt,
    this.accessedAt,
    this.metadata,
  });

  Document copyWith({
    int? id,
    String? name,
    String? filePath,
    FileType? fileType,
    int? fileSize,
    int? folderId,
    int? pageCount,
    String? ocrText,
    List<String>? tags,
    bool? isFavorite,
    bool? isEncrypted,
    String? passwordHash,
    String? thumbnailPath,
    String? cloudSyncId,
    String? cloudProvider,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? accessedAt,
    Map<String, dynamic>? metadata,
  }) {
    return Document(
      id: id ?? this.id,
      name: name ?? this.name,
      filePath: filePath ?? this.filePath,
      fileType: fileType ?? this.fileType,
      fileSize: fileSize ?? this.fileSize,
      folderId: folderId ?? this.folderId,
      pageCount: pageCount ?? this.pageCount,
      ocrText: ocrText ?? this.ocrText,
      tags: tags ?? this.tags,
      isFavorite: isFavorite ?? this.isFavorite,
      isEncrypted: isEncrypted ?? this.isEncrypted,
      passwordHash: passwordHash ?? this.passwordHash,
      thumbnailPath: thumbnailPath ?? this.thumbnailPath,
      cloudSyncId: cloudSyncId ?? this.cloudSyncId,
      cloudProvider: cloudProvider ?? this.cloudProvider,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      accessedAt: accessedAt ?? this.accessedAt,
      metadata: metadata ?? this.metadata,
    );
  }

  @override
  List<Object?> get props => [
    id, name, filePath, fileType, fileSize, folderId, pageCount,
    ocrText, tags, isFavorite, isEncrypted, passwordHash,
    thumbnailPath, cloudSyncId, cloudProvider,
    createdAt, updatedAt, accessedAt, metadata,
  ];
}
