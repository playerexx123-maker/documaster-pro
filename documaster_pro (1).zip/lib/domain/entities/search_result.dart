import 'package:equatable/equatable.dart';

enum SearchResultType { filename, pdfContent, ocrText, tag, note }

class SearchResult extends Equatable {
  final int documentId;
  final String documentName;
  final String snippet;
  final SearchResultType type;
  final int relevance;

  const SearchResult({
    required this.documentId,
    required this.documentName,
    required this.snippet,
    required this.type,
    this.relevance = 0,
  });

  @override
  List<Object?> get props => [documentId, documentName, snippet, type, relevance];
}
