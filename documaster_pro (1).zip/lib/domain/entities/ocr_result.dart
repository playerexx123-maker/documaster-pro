import 'package:equatable/equatable.dart';

class OcrResult extends Equatable {
  final int? id;
  final int documentId;
  final int pageNumber;
  final String recognizedText;
  final String language;
  final double? confidence;
  final DateTime createdAt;

  const OcrResult({
    this.id,
    required this.documentId,
    this.pageNumber = 1,
    required this.recognizedText,
    this.language = 'en',
    this.confidence,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [id, documentId, pageNumber, recognizedText, language, confidence];
}

enum ExportFormat { txt, pdf, docx }
