import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

class AppSettings extends Equatable {
  final ThemeMode themeMode;
  final bool biometricEnabled;
  final bool pinEnabled;
  final String? pinHash;
  final bool cloudSyncEnabled;
  final String? defaultCloudProvider;
  final String defaultSaveLocation;
  final String defaultOcrLanguage;
  final bool autoEnhanceScans;
  final String defaultPdfQuality;
  final bool keepOriginalScans;

  const AppSettings({
    this.themeMode = ThemeMode.system,
    this.biometricEnabled = false,
    this.pinEnabled = false,
    this.pinHash,
    this.cloudSyncEnabled = false,
    this.defaultCloudProvider,
    this.defaultSaveLocation = 'internal',
    this.defaultOcrLanguage = 'en',
    this.autoEnhanceScans = true,
    this.defaultPdfQuality = 'medium',
    this.keepOriginalScans = true,
  });

  AppSettings copyWith({
    ThemeMode? themeMode,
    bool? biometricEnabled,
    bool? pinEnabled,
    String? pinHash,
    bool? cloudSyncEnabled,
    String? defaultCloudProvider,
    String? defaultSaveLocation,
    String? defaultOcrLanguage,
    bool? autoEnhanceScans,
    String? defaultPdfQuality,
    bool? keepOriginalScans,
  }) {
    return AppSettings(
      themeMode: themeMode ?? this.themeMode,
      biometricEnabled: biometricEnabled ?? this.biometricEnabled,
      pinEnabled: pinEnabled ?? this.pinEnabled,
      pinHash: pinHash ?? this.pinHash,
      cloudSyncEnabled: cloudSyncEnabled ?? this.cloudSyncEnabled,
      defaultCloudProvider: defaultCloudProvider ?? this.defaultCloudProvider,
      defaultSaveLocation: defaultSaveLocation ?? this.defaultSaveLocation,
      defaultOcrLanguage: defaultOcrLanguage ?? this.defaultOcrLanguage,
      autoEnhanceScans: autoEnhanceScans ?? this.autoEnhanceScans,
      defaultPdfQuality: defaultPdfQuality ?? this.defaultPdfQuality,
      keepOriginalScans: keepOriginalScans ?? this.keepOriginalScans,
    );
  }

  @override
  List<Object?> get props => [
    themeMode, biometricEnabled, pinEnabled, pinHash,
    cloudSyncEnabled, defaultCloudProvider, defaultSaveLocation,
    defaultOcrLanguage, autoEnhanceScans, defaultPdfQuality, keepOriginalScans,
  ];
}
