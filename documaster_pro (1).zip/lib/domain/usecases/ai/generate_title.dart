import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ai_repository.dart';

class GenerateTitleUseCase implements UseCase<String, GenerateTitleParams> {
  final AIRepository _repository;

  GenerateTitleUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(GenerateTitleParams params) async {
    return await _repository.generateTitle(params.documentPath);
  }
}

class GenerateTitleParams {
  final String documentPath;

  const GenerateTitleParams({
    required this.documentPath,
  });
}
