import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ai_repository.dart';

class ExtractTablesUseCase implements UseCase<List<Map<String, dynamic>>, ExtractTablesParams> {
  final AIRepository _repository;

  ExtractTablesUseCase(this._repository);

  @override
  Future<Either<Failure, List<Map<String, dynamic>>>> call(ExtractTablesParams params) async {
    return await _repository.extractTables(params.pdfPath, params.pageNumber);
  }
}

class ExtractTablesParams {
  final String pdfPath;
  final int pageNumber;

  const ExtractTablesParams({
    required this.pdfPath,
    required this.pageNumber,
  });
}
