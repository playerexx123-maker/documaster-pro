import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ai_repository.dart';

class SummarizePdfUseCase implements UseCase<String, SummarizePdfParams> {
  final AIRepository _repository;

  SummarizePdfUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(SummarizePdfParams params) async {
    return await _repository.summarizePdf(params.pdfPath);
  }
}

class SummarizePdfParams {
  final String pdfPath;

  const SummarizePdfParams({
    required this.pdfPath,
  });
}
