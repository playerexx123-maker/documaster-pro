import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ai_repository.dart';

class TranslateDocumentUseCase implements UseCase<String, TranslateDocumentParams> {
  final AIRepository _repository;

  TranslateDocumentUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(TranslateDocumentParams params) async {
    return await _repository.translateDocument(params.documentPath, params.targetLanguage);
  }
}

class TranslateDocumentParams {
  final String documentPath;
  final String targetLanguage;

  const TranslateDocumentParams({
    required this.documentPath,
    required this.targetLanguage,
  });
}
