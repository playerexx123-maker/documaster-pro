import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ai_repository.dart';

class ExplainTextUseCase implements UseCase<String, ExplainTextParams> {
  final AIRepository _repository;

  ExplainTextUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(ExplainTextParams params) async {
    return await _repository.explainText(params.text, context: params.context);
  }
}

class ExplainTextParams {
  final String text;
  final String? context;

  const ExplainTextParams({
    required this.text,
    this.context,
  });
}
