import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ai_repository.dart';

class GenerateTagsUseCase implements UseCase<List<String>, GenerateTagsParams> {
  final AIRepository _repository;

  GenerateTagsUseCase(this._repository);

  @override
  Future<Either<Failure, List<String>>> call(GenerateTagsParams params) async {
    return await _repository.generateTags(params.documentPath);
  }
}

class GenerateTagsParams {
  final String documentPath;

  const GenerateTagsParams({
    required this.documentPath,
  });
}
