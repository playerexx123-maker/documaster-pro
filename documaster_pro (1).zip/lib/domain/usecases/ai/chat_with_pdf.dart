import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ai_repository.dart';

class ChatWithPdfUseCase implements UseCase<String, ChatWithPdfParams> {
  final AIRepository _repository;

  ChatWithPdfUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(ChatWithPdfParams params) async {
    return await _repository.chatWithPdf(params.pdfPath, params.question);
  }
}

class ChatWithPdfParams {
  final String pdfPath;
  final String question;

  const ChatWithPdfParams({
    required this.pdfPath,
    required this.question,
  });
}
