import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/cloud_repository.dart';

class UploadToCloudParams {
  final String provider;
  final String localPath;
  final String? parentId;

  const UploadToCloudParams(this.provider, this.localPath, {this.parentId});
}

class UploadToCloud implements UseCase<void, UploadToCloudParams> {
  final CloudRepository _repository;

  UploadToCloud(this._repository);

  @override
  Future<Either<Failure, void>> call(UploadToCloudParams params) async {
    return await _repository.uploadFile(
      params.provider,
      params.localPath,
      parentId: params.parentId,
    );
  }
}
