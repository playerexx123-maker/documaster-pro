import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/cloud_repository.dart';

class DisconnectCloudProviderParams {
  final String provider;

  const DisconnectCloudProviderParams(this.provider);
}

class DisconnectCloudProvider implements UseCase<void, DisconnectCloudProviderParams> {
  final CloudRepository _repository;

  DisconnectCloudProvider(this._repository);

  @override
  Future<Either<Failure, void>> call(DisconnectCloudProviderParams params) async {
    return await _repository.logout(params.provider);
  }
}
