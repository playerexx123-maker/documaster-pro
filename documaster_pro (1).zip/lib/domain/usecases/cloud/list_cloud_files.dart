import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/entities/cloud_file.dart';
import '../../../domain/repositories/cloud_repository.dart';

class ListCloudFilesParams {
  final String provider;
  final String? folderId;

  const ListCloudFilesParams(this.provider, {this.folderId});
}

class ListCloudFiles implements UseCase<List<CloudFile>, ListCloudFilesParams> {
  final CloudRepository _repository;

  ListCloudFiles(this._repository);

  @override
  Future<Either<Failure, List<CloudFile>>> call(ListCloudFilesParams params) async {
    return await _repository.listFiles(
      params.provider,
      folderId: params.folderId,
    );
  }
}
