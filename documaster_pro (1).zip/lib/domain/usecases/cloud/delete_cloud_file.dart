import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/cloud_repository.dart';

class DeleteCloudFileParams {
  final String provider;
  final String fileId;

  const DeleteCloudFileParams(this.provider, this.fileId);
}

class DeleteCloudFile implements UseCase<void, DeleteCloudFileParams> {
  final CloudRepository _repository;

  DeleteCloudFile(this._repository);

  @override
  Future<Either<Failure, void>> call(DeleteCloudFileParams params) async {
    return await _repository.deleteFile(params.provider, params.fileId);
  }
}
