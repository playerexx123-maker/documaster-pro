import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/entities/cloud_file.dart';
import '../../../domain/repositories/cloud_repository.dart';

class GetCloudAccounts implements UseCase<List<CloudAccount>, NoParams> {
  final CloudRepository _repository;

  GetCloudAccounts(this._repository);

  @override
  Future<Either<Failure, List<CloudAccount>>> call(NoParams params) async {
    return await _repository.getConnectedAccounts();
  }
}
