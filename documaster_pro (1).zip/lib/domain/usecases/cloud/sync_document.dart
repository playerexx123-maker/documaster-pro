import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/cloud_repository.dart';

class SyncDocumentParams {
  final String provider;
  final String localPath;
  final String? parentId;

  const SyncDocumentParams({
    required this.provider,
    required this.localPath,
    this.parentId,
  });
}

class SyncDocument implements UseCase<void, SyncDocumentParams> {
  final CloudRepository _repository;

  SyncDocument(this._repository);

  @override
  Future<Either<Failure, void>> call(SyncDocumentParams params) async {
    return await _repository.uploadFile(
      params.provider,
      params.localPath,
      parentId: params.parentId,
    );
  }
}
