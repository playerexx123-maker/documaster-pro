import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/cloud_repository.dart';

class ConnectCloudProviderParams {
  final String provider;

  const ConnectCloudProviderParams(this.provider);
}

class ConnectCloudProvider implements UseCase<bool, ConnectCloudProviderParams> {
  final CloudRepository _repository;

  ConnectCloudProvider(this._repository);

  @override
  Future<Either<Failure, bool>> call(ConnectCloudProviderParams params) async {
    return await _repository.authenticate(params.provider);
  }
}
