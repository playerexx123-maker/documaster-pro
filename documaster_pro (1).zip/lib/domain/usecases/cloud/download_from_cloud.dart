import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/cloud_repository.dart';

class DownloadFromCloudParams {
  final String provider;
  final String fileId;
  final String localPath;

  const DownloadFromCloudParams({
    required this.provider,
    required this.fileId,
    required this.localPath,
  });
}

class DownloadFromCloud implements UseCase<void, DownloadFromCloudParams> {
  final CloudRepository _repository;

  DownloadFromCloud(this._repository);

  @override
  Future<Either<Failure, void>> call(DownloadFromCloudParams params) async {
    return await _repository.downloadFile(
      params.provider,
      params.fileId,
      params.localPath,
    );
  }
}
