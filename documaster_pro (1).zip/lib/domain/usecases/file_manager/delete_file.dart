import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class DeleteFile implements UseCase<void, DeleteFileParams> {
  final FileManagerRepository _repository;

  DeleteFile(this._repository);

  @override
  Future<Either<Failure, void>> call(DeleteFileParams params) {
    return _repository.delete(params.path);
  }
}

class DeleteFileParams {
  final String path;

  const DeleteFileParams(this.path);
}
