import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class RenameFile implements UseCase<void, RenameFileParams> {
  final FileManagerRepository _repository;

  RenameFile(this._repository);

  @override
  Future<Either<Failure, void>> call(RenameFileParams params) {
    return _repository.rename(params.path, params.newName);
  }
}

class RenameFileParams {
  final String path;
  final String newName;

  const RenameFileParams({required this.path, required this.newName});
}
