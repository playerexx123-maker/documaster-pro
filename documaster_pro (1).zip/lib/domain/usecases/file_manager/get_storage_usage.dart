import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class GetStorageUsage implements UseCase<int, NoParams> {
  final FileManagerRepository _repository;

  GetStorageUsage(this._repository);

  @override
  Future<Either<Failure, int>> call(NoParams params) {
    return _repository.getStorageUsage();
  }
}
