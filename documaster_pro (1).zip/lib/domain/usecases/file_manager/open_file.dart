import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class OpenFile implements UseCase<void, OpenFileParams> {
  final FileManagerRepository _repository;

  OpenFile(this._repository);

  @override
  Future<Either<Failure, void>> call(OpenFileParams params) {
    return _repository.openFile(params.path);
  }
}

class OpenFileParams {
  final String path;

  const OpenFileParams(this.path);
}
