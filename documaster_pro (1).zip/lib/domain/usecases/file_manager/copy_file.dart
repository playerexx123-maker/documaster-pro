import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class CopyFile implements UseCase<void, CopyFileParams> {
  final FileManagerRepository _repository;

  CopyFile(this._repository);

  @override
  Future<Either<Failure, void>> call(CopyFileParams params) {
    return _repository.copy(params.sourcePath, params.destPath);
  }
}

class CopyFileParams {
  final String sourcePath;
  final String destPath;

  const CopyFileParams({required this.sourcePath, required this.destPath});
}
