import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class CreateFolder implements UseCase<void, CreateFolderParams> {
  final FileManagerRepository _repository;

  CreateFolder(this._repository);

  @override
  Future<Either<Failure, void>> call(CreateFolderParams params) {
    return _repository.createFolder(params.path, params.name);
  }
}

class CreateFolderParams {
  final String path;
  final String name;

  const CreateFolderParams({required this.path, required this.name});
}
