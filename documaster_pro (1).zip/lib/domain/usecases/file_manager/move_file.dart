import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class MoveFile implements UseCase<void, MoveFileParams> {
  final FileManagerRepository _repository;

  MoveFile(this._repository);

  @override
  Future<Either<Failure, void>> call(MoveFileParams params) {
    return _repository.move(params.sourcePath, params.destPath);
  }
}

class MoveFileParams {
  final String sourcePath;
  final String destPath;

  const MoveFileParams({required this.sourcePath, required this.destPath});
}
