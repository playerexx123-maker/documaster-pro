import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class ShareFile implements UseCase<void, ShareFileParams> {
  final FileManagerRepository _repository;

  ShareFile(this._repository);

  @override
  Future<Either<Failure, void>> call(ShareFileParams params) {
    return _repository.share(params.path);
  }
}

class ShareFileParams {
  final String path;

  const ShareFileParams(this.path);
}
