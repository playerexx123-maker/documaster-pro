import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/document.dart';
import '../../repositories/file_manager_repository.dart';

class SearchFiles implements UseCase<List<FileItem>, SearchFilesParams> {
  final FileManagerRepository _repository;

  SearchFiles(this._repository);

  @override
  Future<Either<Failure, List<FileItem>>> call(SearchFilesParams params) {
    return _repository.search(params.query, type: params.fileType);
  }
}

class SearchFilesParams {
  final String query;
  final FileType? fileType;

  const SearchFilesParams({required this.query, this.fileType});
}
