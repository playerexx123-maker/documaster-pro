import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/file_manager_repository.dart';

class ListDirectory implements UseCase<List<FileItem>, ListDirectoryParams> {
  final FileManagerRepository _repository;

  ListDirectory(this._repository);

  @override
  Future<Either<Failure, List<FileItem>>> call(ListDirectoryParams params) {
    return _repository.listDirectory(params.path);
  }
}

class ListDirectoryParams {
  final String path;

  const ListDirectoryParams(this.path);
}
