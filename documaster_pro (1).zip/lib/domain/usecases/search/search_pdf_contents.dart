import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/search_result.dart';
import '../../repositories/search_repository.dart';

class SearchPdfContents implements UseCase<List<SearchResult>, SearchPdfContentsParams> {
  final SearchRepository _repository;

  SearchPdfContents(this._repository);

  @override
  Future<Either<Failure, List<SearchResult>>> call(SearchPdfContentsParams params) {
    return _repository.searchPdfContents(params.query);
  }
}

class SearchPdfContentsParams {
  final String query;

  const SearchPdfContentsParams(this.query);
}
