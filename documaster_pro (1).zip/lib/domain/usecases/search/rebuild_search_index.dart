import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/search_repository.dart';

class RebuildSearchIndex implements UseCase<void, NoParams> {
  final SearchRepository _repository;

  RebuildSearchIndex(this._repository);

  @override
  Future<Either<Failure, void>> call(NoParams params) {
    return _repository.rebuildIndex();
  }
}
