import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/search_result.dart';
import '../../repositories/search_repository.dart';

class GlobalSearch implements UseCase<List<SearchResult>, GlobalSearchParams> {
  final SearchRepository _repository;

  GlobalSearch(this._repository);

  @override
  Future<Either<Failure, List<SearchResult>>> call(GlobalSearchParams params) {
    return _repository.globalSearch(params.query);
  }
}

class GlobalSearchParams {
  final String query;

  const GlobalSearchParams(this.query);
}
