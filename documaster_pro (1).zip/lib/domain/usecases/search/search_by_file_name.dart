import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/search_result.dart';
import '../../repositories/search_repository.dart';

class SearchByFileName implements UseCase<List<SearchResult>, SearchByFileNameParams> {
  final SearchRepository _repository;

  SearchByFileName(this._repository);

  @override
  Future<Either<Failure, List<SearchResult>>> call(SearchByFileNameParams params) {
    return _repository.searchFileNames(params.query);
  }
}

class SearchByFileNameParams {
  final String query;

  const SearchByFileNameParams(this.query);
}
