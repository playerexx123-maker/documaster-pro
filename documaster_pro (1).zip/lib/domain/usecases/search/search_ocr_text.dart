import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/search_result.dart';
import '../../repositories/search_repository.dart';

class SearchOcrText implements UseCase<List<SearchResult>, SearchOcrTextParams> {
  final SearchRepository _repository;

  SearchOcrText(this._repository);

  @override
  Future<Either<Failure, List<SearchResult>>> call(SearchOcrTextParams params) {
    return _repository.searchOcrText(params.query);
  }
}

class SearchOcrTextParams {
  final String query;

  const SearchOcrTextParams(this.query);
}
