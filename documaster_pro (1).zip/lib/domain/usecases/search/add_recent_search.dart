import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/search_repository.dart';

class AddRecentSearch implements UseCase<void, AddRecentSearchParams> {
  final SearchRepository _repository;

  AddRecentSearch(this._repository);

  @override
  Future<Either<Failure, void>> call(AddRecentSearchParams params) {
    return _repository.addRecentSearch(params.query);
  }
}

class AddRecentSearchParams {
  final String query;

  const AddRecentSearchParams(this.query);
}
