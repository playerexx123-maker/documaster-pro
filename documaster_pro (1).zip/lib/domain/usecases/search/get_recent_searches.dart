import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/search_repository.dart';

class GetRecentSearches implements UseCase<List<String>, NoParams> {
  final SearchRepository _repository;

  GetRecentSearches(this._repository);

  @override
  Future<Either<Failure, List<String>>> call(NoParams params) {
    return _repository.getRecentSearches();
  }
}
