import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/search_result.dart';
import '../../repositories/search_repository.dart';

class SearchByTags implements UseCase<List<SearchResult>, SearchByTagsParams> {
  final SearchRepository _repository;

  SearchByTags(this._repository);

  @override
  Future<Either<Failure, List<SearchResult>>> call(SearchByTagsParams params) {
    return _repository.searchTags(params.query);
  }
}

class SearchByTagsParams {
  final String query;

  const SearchByTagsParams(this.query);
}
