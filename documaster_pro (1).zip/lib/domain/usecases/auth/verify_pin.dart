import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/auth_repository.dart';

class VerifyPinParams {
  final String pin;

  const VerifyPinParams(this.pin);
}

class VerifyPin implements UseCase<bool, VerifyPinParams> {
  final AuthRepository _repository;

  VerifyPin(this._repository);

  @override
  Future<Either<Failure, bool>> call(VerifyPinParams params) async {
    return await _repository.verifyPin(params.pin);
  }
}
