import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/auth_repository.dart';

class AuthStatus {
  final bool isBiometricAvailable;
  final bool isBiometricEnabled;
  final bool isPinSetup;

  const AuthStatus({
    required this.isBiometricAvailable,
    required this.isBiometricEnabled,
    required this.isPinSetup,
  });
}

class GetAuthStatus implements UseCase<AuthStatus, NoParams> {
  final AuthRepository _repository;

  GetAuthStatus(this._repository);

  @override
  Future<Either<Failure, AuthStatus>> call(NoParams params) async {
    final biometricAvailable = await _repository.isBiometricAvailable();
    final biometricEnabled = await _repository.isBiometricEnabled();
    final pinSetup = await _repository.isPinSetup();

    return biometricAvailable.fold(
      (failure) => Left(failure),
      (bioAvailable) => biometricEnabled.fold(
        (failure) => Left(failure),
        (bioEnabled) => pinSetup.fold(
          (failure) => Left(failure),
          (hasPin) => Right(AuthStatus(
            isBiometricAvailable: bioAvailable,
            isBiometricEnabled: bioEnabled,
            isPinSetup: hasPin,
          )),
        ),
      ),
    );
  }
}
