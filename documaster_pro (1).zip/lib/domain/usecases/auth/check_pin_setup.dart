import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/auth_repository.dart';

class CheckPinSetup implements UseCase<bool, NoParams> {
  final AuthRepository _repository;

  CheckPinSetup(this._repository);

  @override
  Future<Either<Failure, bool>> call(NoParams params) async {
    return await _repository.isPinSetup();
  }
}
