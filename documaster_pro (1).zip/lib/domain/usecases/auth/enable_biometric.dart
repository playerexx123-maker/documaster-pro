import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/auth_repository.dart';

class EnableBiometricParams {
  final bool enable;

  const EnableBiometricParams(this.enable);
}

class EnableBiometric implements UseCase<void, EnableBiometricParams> {
  final AuthRepository _repository;

  EnableBiometric(this._repository);

  @override
  Future<Either<Failure, void>> call(EnableBiometricParams params) async {
    return await _repository.enableBiometric(params.enable);
  }
}
