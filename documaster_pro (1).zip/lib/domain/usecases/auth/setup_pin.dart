import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/repositories/auth_repository.dart';

class SetupPinParams {
  final String pin;

  const SetupPinParams(this.pin);
}

class SetupPin implements UseCase<bool, SetupPinParams> {
  final AuthRepository _repository;

  SetupPin(this._repository);

  @override
  Future<Either<Failure, bool>> call(SetupPinParams params) async {
    return await _repository.setupPin(params.pin);
  }
}
