import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class CompressImageUseCase implements UseCase<String, CompressImageParams> {
  final ImageEditorRepository _repository;

  CompressImageUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(CompressImageParams params) async {
    return await _repository.compressImage(params.imagePath, params.quality);
  }
}

class CompressImageParams {
  final String imagePath;
  final int quality;

  const CompressImageParams({
    required this.imagePath,
    required this.quality,
  });
}
