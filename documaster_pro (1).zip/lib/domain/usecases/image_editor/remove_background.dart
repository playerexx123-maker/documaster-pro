import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class RemoveBackgroundUseCase implements UseCase<String, RemoveBackgroundParams> {
  final ImageEditorRepository _repository;

  RemoveBackgroundUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(RemoveBackgroundParams params) async {
    return await _repository.removeBackground(params.imagePath);
  }
}

class RemoveBackgroundParams {
  final String imagePath;

  const RemoveBackgroundParams({
    required this.imagePath,
  });
}
