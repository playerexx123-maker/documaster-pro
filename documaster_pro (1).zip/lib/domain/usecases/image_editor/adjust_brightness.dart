import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class AdjustBrightnessUseCase implements UseCase<String, AdjustBrightnessParams> {
  final ImageEditorRepository _repository;

  AdjustBrightnessUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(AdjustBrightnessParams params) async {
    return await _repository.adjustBrightness(params.imagePath, params.value);
  }
}

class AdjustBrightnessParams {
  final String imagePath;
  final double value;

  const AdjustBrightnessParams({
    required this.imagePath,
    required this.value,
  });
}
