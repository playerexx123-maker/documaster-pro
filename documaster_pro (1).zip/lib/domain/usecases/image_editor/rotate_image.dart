import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class RotateImageUseCase implements UseCase<String, RotateImageParams> {
  final ImageEditorRepository _repository;

  RotateImageUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(RotateImageParams params) async {
    return await _repository.rotate(params.imagePath, params.angle);
  }
}

class RotateImageParams {
  final String imagePath;
  final double angle;

  const RotateImageParams({
    required this.imagePath,
    required this.angle,
  });
}
