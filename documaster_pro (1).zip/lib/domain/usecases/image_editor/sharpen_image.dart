import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class SharpenImageUseCase implements UseCase<String, SharpenImageParams> {
  final ImageEditorRepository _repository;

  SharpenImageUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(SharpenImageParams params) async {
    return await _repository.sharpen(params.imagePath, params.amount);
  }
}

class SharpenImageParams {
  final String imagePath;
  final double amount;

  const SharpenImageParams({
    required this.imagePath,
    required this.amount,
  });
}
