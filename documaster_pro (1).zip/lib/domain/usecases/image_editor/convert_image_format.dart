import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class ConvertImageFormatUseCase implements UseCase<String, ConvertImageFormatParams> {
  final ImageEditorRepository _repository;

  ConvertImageFormatUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(ConvertImageFormatParams params) async {
    return await _repository.convertFormat(params.imagePath, params.format);
  }
}

class ConvertImageFormatParams {
  final String imagePath;
  final ImageFormat format;

  const ConvertImageFormatParams({
    required this.imagePath,
    required this.format,
  });
}
