import 'dart:ui';
import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class CropImageUseCase implements UseCase<String, CropImageParams> {
  final ImageEditorRepository _repository;

  CropImageUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(CropImageParams params) async {
    return await _repository.crop(params.imagePath, params.cropRect);
  }
}

class CropImageParams {
  final String imagePath;
  final Rect cropRect;

  const CropImageParams({
    required this.imagePath,
    required this.cropRect,
  });
}
