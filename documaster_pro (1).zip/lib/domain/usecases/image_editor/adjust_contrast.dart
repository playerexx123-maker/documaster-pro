import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class AdjustContrastUseCase implements UseCase<String, AdjustContrastParams> {
  final ImageEditorRepository _repository;

  AdjustContrastUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(AdjustContrastParams params) async {
    return await _repository.adjustContrast(params.imagePath, params.value);
  }
}

class AdjustContrastParams {
  final String imagePath;
  final double value;

  const AdjustContrastParams({
    required this.imagePath,
    required this.value,
  });
}
