import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/image_editor_repository.dart';

class ResizeImageUseCase implements UseCase<String, ResizeImageParams> {
  final ImageEditorRepository _repository;

  ResizeImageUseCase(this._repository);

  @override
  Future<Either<Failure, String>> call(ResizeImageParams params) async {
    return await _repository.resize(params.imagePath, params.width, params.height);
  }
}

class ResizeImageParams {
  final String imagePath;
  final int width;
  final int height;

  const ResizeImageParams({
    required this.imagePath,
    required this.width,
    required this.height,
  });
}
