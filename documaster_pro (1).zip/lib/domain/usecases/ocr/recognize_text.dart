import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/ocr_result.dart';
import '../../repositories/ocr_repository.dart';

class RecognizeText implements UseCase<OcrResult, RecognizeTextParams> {
  final OcrRepository _repository;

  RecognizeText(this._repository);

  @override
  Future<Either<Failure, OcrResult>> call(RecognizeTextParams params) async {
    return await _repository.recognizeText(
      params.imagePath,
      language: params.language,
    );
  }
}

class RecognizeTextParams {
  final String imagePath;
  final String language;

  const RecognizeTextParams({
    required this.imagePath,
    this.language = 'en',
  });
}
