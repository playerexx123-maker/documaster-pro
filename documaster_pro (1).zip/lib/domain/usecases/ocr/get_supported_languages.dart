import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ocr_repository.dart';

class LanguageInfo {
  final String code;
  final String name;
  final bool isSupported;

  const LanguageInfo({
    required this.code,
    required this.name,
    required this.isSupported,
  });
}

class GetSupportedLanguages implements UseCase<List<LanguageInfo>, NoParams> {
  final OcrRepository _repository;

  GetSupportedLanguages(this._repository);

  static const Map<String, String> _languageNames = {
    'en': 'English',
    'ro': 'Romanian',
    'hu': 'Hungarian',
    'de': 'German',
    'it': 'Italian',
  };

  @override
  Future<Either<Failure, List<LanguageInfo>>> call(NoParams params) async {
    try {
      final languages = <LanguageInfo>[];
      for (final entry in _languageNames.entries) {
        final result = await _repository.isLanguageSupported(entry.key);
        final isSupported = result.getOrElse(() => false);
        languages.add(LanguageInfo(
          code: entry.key,
          name: entry.value,
          isSupported: isSupported,
        ));
      }
      return Right(languages);
    } catch (e) {
      return Left(UnknownFailure('Failed to get supported languages: $e'));
    }
  }
}
