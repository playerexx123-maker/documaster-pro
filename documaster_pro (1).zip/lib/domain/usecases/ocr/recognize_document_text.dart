import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/ocr_result.dart';
import '../../repositories/ocr_repository.dart';

class RecognizeDocumentText implements UseCase<List<OcrResult>, RecognizeDocumentTextParams> {
  final OcrRepository _repository;

  RecognizeDocumentText(this._repository);

  @override
  Future<Either<Failure, List<OcrResult>>> call(RecognizeDocumentTextParams params) async {
    return await _repository.recognizeDocument(
      params.documentId,
      language: params.language,
    );
  }
}

class RecognizeDocumentTextParams {
  final int documentId;
  final String language;

  const RecognizeDocumentTextParams({
    required this.documentId,
    this.language = 'en',
  });
}
