import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/ocr_repository.dart';

class GetDocumentText implements UseCase<String, GetDocumentTextParams> {
  final OcrRepository _repository;

  GetDocumentText(this._repository);

  @override
  Future<Either<Failure, String>> call(GetDocumentTextParams params) async {
    return await _repository.getRecognizedText(params.documentId);
  }
}

class GetDocumentTextParams {
  final int documentId;

  const GetDocumentTextParams({required this.documentId});
}
