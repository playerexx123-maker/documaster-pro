import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/ocr_result.dart';
import '../../repositories/ocr_repository.dart';

class ExportOcrText implements UseCase<String, ExportOcrTextParams> {
  final OcrRepository _repository;

  ExportOcrText(this._repository);

  @override
  Future<Either<Failure, String>> call(ExportOcrTextParams params) async {
    return await _repository.exportText(params.documentId, params.format);
  }
}

class ExportOcrTextParams {
  final int documentId;
  final ExportFormat format;

  const ExportOcrTextParams({
    required this.documentId,
    required this.format,
  });
}
