import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/scanner_repository.dart';

class CancelScanSession implements UseCase<void, CancelScanSessionParams> {
  final ScannerRepository _repository;

  CancelScanSession(this._repository);

  @override
  Future<Either<Failure, void>> call(CancelScanSessionParams params) async {
    return await _repository.cancelSession(params.sessionId);
  }
}

class CancelScanSessionParams {
  final int sessionId;

  const CancelScanSessionParams({required this.sessionId});
}
