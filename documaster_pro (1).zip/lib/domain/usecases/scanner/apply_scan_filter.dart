import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/scan_page.dart';
import '../../repositories/scanner_repository.dart';

class ApplyScanFilter implements UseCase<String, ApplyScanFilterParams> {
  final ScannerRepository _repository;

  ApplyScanFilter(this._repository);

  @override
  Future<Either<Failure, String>> call(ApplyScanFilterParams params) async {
    return await _repository.applyFilter(params.imagePath, params.filter);
  }
}

class ApplyScanFilterParams {
  final String imagePath;
  final ScanFilter filter;

  const ApplyScanFilterParams({
    required this.imagePath,
    required this.filter,
  });
}
