import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/scan_page.dart';
import '../../repositories/scanner_repository.dart';

class StartScanSession implements UseCase<ScanSession, StartScanSessionParams> {
  final ScannerRepository _repository;

  StartScanSession(this._repository);

  @override
  Future<Either<Failure, ScanSession>> call(StartScanSessionParams params) async {
    return await _repository.startSession(params.name);
  }
}

class StartScanSessionParams {
  final String name;

  const StartScanSessionParams({required this.name});
}
