import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/scan_page.dart';
import '../../repositories/scanner_repository.dart';

class CapturePage implements UseCase<void, CapturePageParams> {
  final ScannerRepository _repository;

  CapturePage(this._repository);

  @override
  Future<Either<Failure, void>> call(CapturePageParams params) async {
    return await _repository.addPage(params.sessionId, params.imagePath);
  }
}

class CapturePageParams {
  final int sessionId;
  final String imagePath;

  const CapturePageParams({
    required this.sessionId,
    required this.imagePath,
  });
}
