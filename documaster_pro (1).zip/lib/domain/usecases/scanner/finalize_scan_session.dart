import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/document.dart';
import '../../entities/scan_page.dart';
import '../../repositories/scanner_repository.dart';

class FinalizeScanSession implements UseCase<Document, FinalizeScanSessionParams> {
  final ScannerRepository _repository;

  FinalizeScanSession(this._repository);

  @override
  Future<Either<Failure, Document>> call(FinalizeScanSessionParams params) async {
    return await _repository.finalizeSession(
      params.sessionId,
      name: params.name,
      format: params.format,
    );
  }
}

class FinalizeScanSessionParams {
  final int sessionId;
  final String? name;
  final SaveFormat format;

  const FinalizeScanSessionParams({
    required this.sessionId,
    this.name,
    this.format = SaveFormat.pdf,
  });
}
