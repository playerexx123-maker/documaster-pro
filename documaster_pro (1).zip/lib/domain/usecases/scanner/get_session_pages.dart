import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/scan_page.dart';
import '../../repositories/scanner_repository.dart';

class GetSessionPages implements UseCase<List<ScanPage>, GetSessionPagesParams> {
  final ScannerRepository _repository;

  GetSessionPages(this._repository);

  @override
  Future<Either<Failure, List<ScanPage>>> call(GetSessionPagesParams params) async {
    return await _repository.getSessionPages(params.sessionId);
  }
}

class GetSessionPagesParams {
  final int sessionId;

  const GetSessionPagesParams({required this.sessionId});
}
