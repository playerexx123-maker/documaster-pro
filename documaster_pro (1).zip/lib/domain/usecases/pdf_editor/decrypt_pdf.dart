import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class DecryptPdf implements UseCase<String, DecryptPdfParams> {
  final PdfEditorRepository _repository;

  DecryptPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(DecryptPdfParams params) async {
    return await _repository.decryptPdf(params.path, params.password);
  }
}

class DecryptPdfParams extends Equatable {
  final String path;
  final String password;

  const DecryptPdfParams({required this.path, required this.password});

  @override
  List<Object?> get props => [path, password];
}
