import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/pdf_annotation.dart';
import '../../repositories/pdf_editor_repository.dart';

class CompressPdf implements UseCase<String, CompressPdfParams> {
  final PdfEditorRepository _repository;

  CompressPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(CompressPdfParams params) async {
    return await _repository.compressPdf(params.path, params.level);
  }
}

class CompressPdfParams extends Equatable {
  final String path;
  final CompressionLevel level;

  const CompressPdfParams({
    required this.path,
    this.level = CompressionLevel.medium,
  });

  @override
  List<Object?> get props => [path, level];
}
