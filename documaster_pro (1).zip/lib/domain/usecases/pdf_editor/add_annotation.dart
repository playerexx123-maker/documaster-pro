import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/pdf_annotation.dart';
import '../../repositories/pdf_editor_repository.dart';

class AddAnnotation implements UseCase<PdfAnnotation, AddAnnotationParams> {
  final PdfEditorRepository _repository;

  AddAnnotation(this._repository);

  @override
  Future<Either<Failure, PdfAnnotation>> call(AddAnnotationParams params) async {
    return await _repository.addAnnotation(params.annotation);
  }
}

class AddAnnotationParams extends Equatable {
  final PdfAnnotation annotation;

  const AddAnnotationParams({required this.annotation});

  @override
  List<Object?> get props => [annotation];
}
