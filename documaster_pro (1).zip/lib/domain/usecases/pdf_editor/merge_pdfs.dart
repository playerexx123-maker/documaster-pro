import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class MergePdfs implements UseCase<String, MergePdfsParams> {
  final PdfEditorRepository _repository;

  MergePdfs(this._repository);

  @override
  Future<Either<Failure, String>> call(MergePdfsParams params) async {
    return await _repository.mergePdfs(params.paths);
  }
}

class MergePdfsParams extends Equatable {
  final List<String> paths;

  const MergePdfsParams({required this.paths});

  @override
  List<Object?> get props => [paths];
}
