import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/pdf_annotation.dart';
import '../../repositories/pdf_editor_repository.dart';

class GetAnnotations implements UseCase<List<PdfAnnotation>, GetAnnotationsParams> {
  final PdfEditorRepository _repository;

  GetAnnotations(this._repository);

  @override
  Future<Either<Failure, List<PdfAnnotation>>> call(GetAnnotationsParams params) async {
    return await _repository.getAnnotations(params.documentId);
  }
}

class GetAnnotationsParams extends Equatable {
  final int documentId;

  const GetAnnotationsParams({required this.documentId});

  @override
  List<Object?> get props => [documentId];
}
