import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class DeletePages implements UseCase<String, DeletePagesParams> {
  final PdfEditorRepository _repository;

  DeletePages(this._repository);

  @override
  Future<Either<Failure, String>> call(DeletePagesParams params) async {
    return await _repository.deletePages(params.path, params.pageNumbers);
  }
}

class DeletePagesParams extends Equatable {
  final String path;
  final List<int> pageNumbers;

  const DeletePagesParams({required this.path, required this.pageNumbers});

  @override
  List<Object?> get props => [path, pageNumbers];
}
