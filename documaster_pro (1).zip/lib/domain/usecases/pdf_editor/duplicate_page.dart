import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class DuplicatePage implements UseCase<String, DuplicatePageParams> {
  final PdfEditorRepository _repository;

  DuplicatePage(this._repository);

  @override
  Future<Either<Failure, String>> call(DuplicatePageParams params) async {
    return await _repository.duplicatePage(params.path, params.pageNumber);
  }
}

class DuplicatePageParams extends Equatable {
  final String path;
  final int pageNumber;

  const DuplicatePageParams({required this.path, required this.pageNumber});

  @override
  List<Object?> get props => [path, pageNumber];
}
