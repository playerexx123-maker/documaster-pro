import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/pdf_annotation.dart';
import '../../repositories/pdf_editor_repository.dart';

class AddWatermark implements UseCase<String, AddWatermarkParams> {
  final PdfEditorRepository _repository;

  AddWatermark(this._repository);

  @override
  Future<Either<Failure, String>> call(AddWatermarkParams params) async {
    return await _repository.addWatermark(params.path, params.options);
  }
}

class AddWatermarkParams extends Equatable {
  final String path;
  final WatermarkOptions options;

  const AddWatermarkParams({required this.path, required this.options});

  @override
  List<Object?> get props => [path, options];
}
