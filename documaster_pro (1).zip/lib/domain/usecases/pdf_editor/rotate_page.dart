import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/pdf_annotation.dart';
import '../../repositories/pdf_editor_repository.dart';

class RotatePage implements UseCase<String, RotatePageParams> {
  final PdfEditorRepository _repository;

  RotatePage(this._repository);

  @override
  Future<Either<Failure, String>> call(RotatePageParams params) async {
    return await _repository.rotatePage(
      params.path,
      params.pageNumber,
      params.rotation,
    );
  }
}

class RotatePageParams extends Equatable {
  final String path;
  final int pageNumber;
  final Rotation rotation;

  const RotatePageParams({
    required this.path,
    required this.pageNumber,
    required this.rotation,
  });

  @override
  List<Object?> get props => [path, pageNumber, rotation];
}
