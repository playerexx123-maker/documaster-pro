import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class InsertPage implements UseCase<String, InsertPageParams> {
  final PdfEditorRepository _repository;

  InsertPage(this._repository);

  @override
  Future<Either<Failure, String>> call(InsertPageParams params) async {
    final countResult = await _repository.getPageCount(params.targetPath);
    return countResult.fold(
      (failure) => Left(failure),
      (totalPages) async {
        final insertAfter = params.insertAfter.clamp(0, totalPages);

        final pagesBeforeResult = insertAfter > 0
            ? await _repository.deletePages(
                params.targetPath,
                List.generate(totalPages - insertAfter, (i) => insertAfter + 1 + i),
              )
            : null;

        final pagesAfterResult = insertAfter < totalPages
            ? await _repository.deletePages(
                params.targetPath,
                List.generate(insertAfter, (i) => i + 1),
              )
            : null;

        String? pagesBeforePath;
        String? pagesAfterPath;

        pagesBeforeResult?.fold((l) => null, (r) => pagesBeforePath = r);
        pagesAfterResult?.fold((l) => null, (r) => pagesAfterPath = r);

        final mergeOrder = <String>[];
        if (pagesBeforePath != null) mergeOrder.add(pagesBeforePath!);
        mergeOrder.add(params.sourcePath);
        if (pagesAfterPath != null) mergeOrder.add(pagesAfterPath!);

        return await _repository.mergePdfs(mergeOrder);
      },
    );
  }
}

class InsertPageParams extends Equatable {
  final String targetPath;
  final String sourcePath;
  final int insertAfter;

  const InsertPageParams({
    required this.targetPath,
    required this.sourcePath,
    this.insertAfter = 0,
  });

  @override
  List<Object?> get props => [targetPath, sourcePath, insertAfter];
}
