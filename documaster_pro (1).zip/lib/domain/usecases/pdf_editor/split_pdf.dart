import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class SplitPdf implements UseCase<List<String>, SplitPdfParams> {
  final PdfEditorRepository _repository;

  SplitPdf(this._repository);

  @override
  Future<Either<Failure, List<String>>> call(SplitPdfParams params) async {
    final results = <String>[];

    final countResult = await _repository.getPageCount(params.path);
    return countResult.fold(
      (failure) => Left(failure),
      (totalPages) async {
        try {
          for (int i = 0; i < params.ranges.length; i++) {
            final range = params.ranges[i];
            final start = range['start'] ?? 1;
            final end = range['end'] ?? totalPages;

            final pagesToKeep = <int>[];
            for (int p = start; p <= end && p <= totalPages; p++) {
              pagesToKeep.add(p);
            }

            if (pagesToKeep.isEmpty) continue;

            final splitResult = await _repository.deletePages(
              params.path,
              _getPagesToDelete(totalPages, pagesToKeep),
            );

            splitResult.fold(
              (failure) => Left(failure),
              (outputPath) => results.add(outputPath),
            );
          }

          if (results.isEmpty) {
            return Left(FileSystemFailure('No pages were extracted'));
          }

          return Right(results);
        } catch (e) {
          return Left(UnknownFailure('Failed to split PDF: $e'));
        }
      },
    );
  }

  List<int> _getPagesToDelete(int totalPages, List<int> pagesToKeep) {
    final keepSet = pagesToKeep.toSet();
    final deletePages = <int>[];
    for (int p = 1; p <= totalPages; p++) {
      if (!keepSet.contains(p)) {
        deletePages.add(p);
      }
    }
    return deletePages;
  }
}

class SplitPdfParams extends Equatable {
  final String path;
  final List<Map<String, int>> ranges;

  const SplitPdfParams({required this.path, required this.ranges});

  @override
  List<Object?> get props => [path, ranges];
}
