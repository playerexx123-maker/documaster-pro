import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/pdf_annotation.dart';
import '../../repositories/pdf_editor_repository.dart';

class AddPageNumbers implements UseCase<String, AddPageNumbersParams> {
  final PdfEditorRepository _repository;

  AddPageNumbers(this._repository);

  @override
  Future<Either<Failure, String>> call(AddPageNumbersParams params) async {
    return await _repository.addPageNumbers(params.path, params.options);
  }
}

class AddPageNumbersParams extends Equatable {
  final String path;
  final PageNumberOptions options;

  const AddPageNumbersParams({required this.path, required this.options});

  @override
  List<Object?> get props => [path, options];
}
