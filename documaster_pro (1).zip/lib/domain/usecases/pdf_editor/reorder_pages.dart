import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class ReorderPages implements UseCase<String, ReorderPagesParams> {
  final PdfEditorRepository _repository;

  ReorderPages(this._repository);

  @override
  Future<Either<Failure, String>> call(ReorderPagesParams params) async {
    return await _repository.reorderPages(params.path, params.newOrder);
  }
}

class ReorderPagesParams extends Equatable {
  final String path;
  final List<int> newOrder;

  const ReorderPagesParams({required this.path, required this.newOrder});

  @override
  List<Object?> get props => [path, newOrder];
}
