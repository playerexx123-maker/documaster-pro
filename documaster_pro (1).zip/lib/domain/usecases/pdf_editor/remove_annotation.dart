import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class RemoveAnnotation implements UseCase<void, RemoveAnnotationParams> {
  final PdfEditorRepository _repository;

  RemoveAnnotation(this._repository);

  @override
  Future<Either<Failure, void>> call(RemoveAnnotationParams params) async {
    return await _repository.removeAnnotation(params.id);
  }
}

class RemoveAnnotationParams extends Equatable {
  final int id;

  const RemoveAnnotationParams({required this.id});

  @override
  List<Object?> get props => [id];
}
