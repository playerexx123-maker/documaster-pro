import 'package:dartz/dartz.dart';
import 'package:equatable/equatable.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/pdf_editor_repository.dart';

class EncryptPdf implements UseCase<String, EncryptPdfParams> {
  final PdfEditorRepository _repository;

  EncryptPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(EncryptPdfParams params) async {
    return await _repository.encryptPdf(params.path, params.password);
  }
}

class EncryptPdfParams extends Equatable {
  final String path;
  final String password;

  const EncryptPdfParams({required this.path, required this.password});

  @override
  List<Object?> get props => [path, password];
}
