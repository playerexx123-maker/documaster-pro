import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/converter_repository.dart';

class WordToPdf implements UseCase<String, WordToPdfParams> {
  final ConverterRepository _repository;

  WordToPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(WordToPdfParams params) {
    return _repository.wordToPdf(params.docxPath);
  }
}

class WordToPdfParams {
  final String docxPath;

  const WordToPdfParams(this.docxPath);
}
