import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/conversion_job.dart';
import '../../repositories/converter_repository.dart';

class GetConversionStatus implements UseCase<ConversionJob, GetConversionStatusParams> {
  final ConverterRepository _repository;

  GetConversionStatus(this._repository);

  @override
  Future<Either<Failure, ConversionJob>> call(GetConversionStatusParams params) {
    return _repository.getConversionStatus(params.jobId);
  }
}

class GetConversionStatusParams {
  final String jobId;

  const GetConversionStatusParams(this.jobId);
}
