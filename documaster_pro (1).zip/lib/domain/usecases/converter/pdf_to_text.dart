import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/converter_repository.dart';

class PdfToText implements UseCase<String, PdfToTextParams> {
  final ConverterRepository _repository;

  PdfToText(this._repository);

  @override
  Future<Either<Failure, String>> call(PdfToTextParams params) {
    return _repository.pdfToText(params.pdfPath);
  }
}

class PdfToTextParams {
  final String pdfPath;

  const PdfToTextParams(this.pdfPath);
}
