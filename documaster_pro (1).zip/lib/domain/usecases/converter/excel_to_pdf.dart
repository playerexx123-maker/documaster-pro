import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/converter_repository.dart';

class ExcelToPdf implements UseCase<String, ExcelToPdfParams> {
  final ConverterRepository _repository;

  ExcelToPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(ExcelToPdfParams params) {
    return _repository.excelToPdf(params.xlsxPath);
  }
}

class ExcelToPdfParams {
  final String xlsxPath;

  const ExcelToPdfParams(this.xlsxPath);
}
