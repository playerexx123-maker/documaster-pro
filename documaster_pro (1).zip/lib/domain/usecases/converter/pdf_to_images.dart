import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/converter_repository.dart';

class PdfToImages implements UseCase<List<String>, PdfToImagesParams> {
  final ConverterRepository _repository;

  PdfToImages(this._repository);

  @override
  Future<Either<Failure, List<String>>> call(PdfToImagesParams params) {
    return _repository.pdfToImages(params.pdfPath, outputDir: params.outputDir);
  }
}

class PdfToImagesParams {
  final String pdfPath;
  final String? outputDir;

  const PdfToImagesParams({required this.pdfPath, this.outputDir});
}
