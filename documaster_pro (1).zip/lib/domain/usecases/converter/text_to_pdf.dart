import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/converter_repository.dart';

class TextToPdf implements UseCase<String, TextToPdfParams> {
  final ConverterRepository _repository;

  TextToPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(TextToPdfParams params) {
    return _repository.textToPdf(params.txtPath);
  }
}

class TextToPdfParams {
  final String txtPath;

  const TextToPdfParams(this.txtPath);
}
