import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../entities/conversion_job.dart';
import '../../repositories/converter_repository.dart';

class StartConversion implements UseCase<ConversionJob, StartConversionParams> {
  final ConverterRepository _repository;

  StartConversion(this._repository);

  @override
  Future<Either<Failure, ConversionJob>> call(StartConversionParams params) {
    return _repository.startConversion(params.sourcePath, params.targetFormat);
  }
}

class StartConversionParams {
  final String sourcePath;
  final String targetFormat;

  const StartConversionParams({
    required this.sourcePath,
    required this.targetFormat,
  });
}
