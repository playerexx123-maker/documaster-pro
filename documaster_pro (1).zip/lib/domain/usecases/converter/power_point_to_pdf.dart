import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/converter_repository.dart';

class PowerPointToPdf implements UseCase<String, PowerPointToPdfParams> {
  final ConverterRepository _repository;

  PowerPointToPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(PowerPointToPdfParams params) {
    return _repository.powerPointToPdf(params.pptxPath);
  }
}

class PowerPointToPdfParams {
  final String pptxPath;

  const PowerPointToPdfParams(this.pptxPath);
}
