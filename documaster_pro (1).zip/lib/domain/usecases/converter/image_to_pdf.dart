import 'package:dartz/dartz.dart';
import '../../../core/errors/failures.dart';
import '../../../core/usecases/usecase.dart';
import '../../repositories/converter_repository.dart';

class ImageToPdf implements UseCase<String, ImageToPdfParams> {
  final ConverterRepository _repository;

  ImageToPdf(this._repository);

  @override
  Future<Either<Failure, String>> call(ImageToPdfParams params) {
    return _repository.imageToPdf(params.imagePaths, outputName: params.outputName);
  }
}

class ImageToPdfParams {
  final List<String> imagePaths;
  final String? outputName;

  const ImageToPdfParams({required this.imagePaths, this.outputName});
}
