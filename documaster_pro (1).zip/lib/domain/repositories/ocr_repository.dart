import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/ocr_result.dart';

abstract class OcrRepository {
  Future<Either<Failure, OcrResult>> recognizeText(String imagePath, {String language = 'en'});
  Future<Either<Failure, OcrResult>> recognizeTextFromPdfPage(String pdfPath, int pageNumber, {String language = 'en'});
  Future<Either<Failure, List<OcrResult>>> recognizeDocument(int documentId, {String language = 'en'});
  Future<Either<Failure, List<OcrResult>>> getResultsForDocument(int documentId);
  Future<Either<Failure, String>> getRecognizedText(int documentId);
  Future<Either<Failure, String>> exportText(int documentId, ExportFormat format);
  Future<Either<Failure, bool>> isLanguageSupported(String languageCode);
}
