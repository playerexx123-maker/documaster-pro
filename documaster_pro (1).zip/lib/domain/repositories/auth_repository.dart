import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';

abstract class AuthRepository {
  Future<Either<Failure, bool>> isBiometricAvailable();
  Future<Either<Failure, bool>> authenticateWithBiometrics();
  Future<Either<Failure, bool>> setupPin(String pin);
  Future<Either<Failure, bool>> verifyPin(String pin);
  Future<Either<Failure, bool>> isPinSetup();
  Future<Either<Failure, void>> enableBiometric(bool enable);
  Future<Either<Failure, bool>> isBiometricEnabled();
  Future<Either<Failure, void>> setPin(String pin);
  Future<Either<Failure, void>> clearPin();
}
