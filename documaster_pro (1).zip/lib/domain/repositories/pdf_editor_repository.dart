import 'package:dartz/dartz.dart';
import 'dart:typed_data';
import '../../core/errors/failures.dart';
import '../entities/pdf_annotation.dart';

abstract class PdfEditorRepository {
  Future<Either<Failure, String>> mergePdfs(List<String> paths);
  Future<Either<Failure, String>> reorderPages(String path, List<int> newOrder);
  Future<Either<Failure, String>> rotatePage(String path, int pageNumber, Rotation rotation);
  Future<Either<Failure, String>> deletePages(String path, List<int> pageNumbers);
  Future<Either<Failure, String>> duplicatePage(String path, int pageNumber);
  Future<Either<Failure, String>> compressPdf(String path, CompressionLevel level);
  Future<Either<Failure, String>> encryptPdf(String path, String password);
  Future<Either<Failure, String>> decryptPdf(String path, String password);
  Future<Either<Failure, String>> addWatermark(String path, WatermarkOptions options);
  Future<Either<Failure, String>> addPageNumbers(String path, PageNumberOptions options);
  Future<Either<Failure, int>> getPageCount(String path);
  Future<Either<Failure, Uint8List>> renderPage(String path, int pageNumber, {int width = 800});

  Future<Either<Failure, List<PdfAnnotation>>> getAnnotations(int documentId);
  Future<Either<Failure, PdfAnnotation>> addAnnotation(PdfAnnotation annotation);
  Future<Either<Failure, void>> removeAnnotation(int id);
  Future<Either<Failure, String>> annotatePdf(String path, List<PdfAnnotation> annotations);
}
