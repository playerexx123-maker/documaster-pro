import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/cloud_file.dart';

abstract class CloudRepository {
  Future<Either<Failure, bool>> authenticate(String provider);
  Future<Either<Failure, void>> logout(String provider);
  Future<Either<Failure, List<CloudFile>>> listFiles(String provider, {String? folderId});
  Future<Either<Failure, void>> uploadFile(String provider, String localPath, {String? parentId});
  Future<Either<Failure, void>> downloadFile(String provider, String fileId, String localPath);
  Future<Either<Failure, void>> deleteFile(String provider, String fileId);
  Future<Either<Failure, List<CloudAccount>>> getConnectedAccounts();
  Future<Either<Failure, DateTime?>> getLastSyncTime(String provider);
}
