import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/folder.dart';

abstract class FolderRepository {
  Future<Either<Failure, List<Folder>>> getAllFolders();
  Future<Either<Failure, Folder?>> getFolderById(int id);
  Future<Either<Failure, List<Folder>>> getRootFolders();
  Future<Either<Failure, List<Folder>>> getSubFolders(int parentId);
  Future<Either<Failure, Folder>> createFolder(Folder folder);
  Future<Either<Failure, Folder>> updateFolder(Folder folder);
  Future<Either<Failure, void>> deleteFolder(int id);
  Future<Either<Failure, List<Folder>>> getFolderPath(int folderId);
}
