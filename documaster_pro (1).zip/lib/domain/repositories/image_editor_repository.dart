import 'package:dartz/dartz.dart';
import 'dart:math';
import 'dart:typed_data';
import '../../core/errors/failures.dart';

enum ImageFormat { jpeg, png, webp, bmp }

abstract class ImageEditorRepository {
  Future<Either<Failure, String>> crop(String imagePath, Rect cropRect);
  Future<Either<Failure, String>> resize(String imagePath, int width, int height);
  Future<Either<Failure, String>> rotate(String imagePath, double angle);
  Future<Either<Failure, String>> adjustBrightness(String imagePath, double value);
  Future<Either<Failure, String>> adjustContrast(String imagePath, double value);
  Future<Either<Failure, String>> sharpen(String imagePath, double amount);
  Future<Either<Failure, String>> convertFormat(String imagePath, ImageFormat format);
  Future<Either<Failure, String>> removeBackground(String imagePath);
  Future<Either<Failure, String>> compressImage(String imagePath, int quality);
}
