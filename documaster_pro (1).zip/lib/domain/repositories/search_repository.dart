import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/search_result.dart';

abstract class SearchRepository {
  Future<Either<Failure, List<SearchResult>>> globalSearch(String query);
  Future<Either<Failure, List<SearchResult>>> searchFileNames(String query);
  Future<Either<Failure, List<SearchResult>>> searchPdfContents(String query);
  Future<Either<Failure, List<SearchResult>>> searchOcrText(String query);
  Future<Either<Failure, List<SearchResult>>> searchTags(String query);
  Future<Either<Failure, void>> rebuildIndex();
  Future<Either<Failure, List<String>>> getRecentSearches();
  Future<Either<Failure, void>> addRecentSearch(String query);
}
