import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/document.dart';

abstract class DocumentRepository {
  Future<Either<Failure, List<Document>>> getAllDocuments();
  Future<Either<Failure, List<Document>>> getRecentDocuments({int limit = 20});
  Future<Either<Failure, List<Document>>> getFavoriteDocuments();
  Future<Either<Failure, Document?>> getDocumentById(int id);
  Future<Either<Failure, List<Document>>> getDocumentsInFolder(int folderId);
  Future<Either<Failure, List<Document>>> searchDocuments(String query);
  Future<Either<Failure, Document>> createDocument(Document document);
  Future<Either<Failure, Document>> updateDocument(Document document);
  Future<Either<Failure, void>> deleteDocument(int id);
  Future<Either<Failure, void>> toggleFavorite(int id);
  Future<Either<Failure, void>> updateAccessTime(int id);
  Future<Either<Failure, List<Document>>> getDocumentsByType(FileType type);
}
