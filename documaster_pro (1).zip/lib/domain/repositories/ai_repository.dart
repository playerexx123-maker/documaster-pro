import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';

abstract class AIRepository {
  Future<Either<Failure, String>> summarizePdf(String pdfPath);
  Future<Either<Failure, String>> translateDocument(String documentPath, String targetLanguage);
  Future<Either<Failure, String>> explainText(String text, {String? context});
  Future<Either<Failure, List<Map<String, dynamic>>>> extractTables(String pdfPath, int pageNumber);
  Future<Either<Failure, String>> generateTitle(String documentPath);
  Future<Either<Failure, List<String>>> generateTags(String documentPath);
  Future<Either<Failure, String>> chatWithPdf(String pdfPath, String question);
}
