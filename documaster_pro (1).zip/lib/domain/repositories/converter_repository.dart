import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/conversion_job.dart';

abstract class ConverterRepository {
  Future<Either<Failure, String>> imageToPdf(List<String> imagePaths, {String? outputName});
  Future<Either<Failure, List<String>>> pdfToImages(String pdfPath, {String? outputDir});
  Future<Either<Failure, String>> wordToPdf(String docxPath);
  Future<Either<Failure, String>> excelToPdf(String xlsxPath);
  Future<Either<Failure, String>> powerPointToPdf(String pptxPath);
  Future<Either<Failure, String>> textToPdf(String txtPath);
  Future<Either<Failure, String>> pdfToText(String pdfPath);
  Future<Either<Failure, ConversionJob>> startConversion(String sourcePath, String targetFormat);
  Future<Either<Failure, ConversionJob>> getConversionStatus(String jobId);
}
