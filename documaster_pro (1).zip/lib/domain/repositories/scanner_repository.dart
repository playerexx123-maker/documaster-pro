import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/document.dart';
import '../entities/scan_page.dart';

abstract class ScannerRepository {
  Future<Either<Failure, ScanSession>> startSession(String name);
  Future<Either<Failure, void>> addPage(int sessionId, String imagePath);
  Future<Either<Failure, String>> processPage(String imagePath, ScanFilter filter);
  Future<Either<Failure, String>> applyFilter(String imagePath, ScanFilter filter);
  Future<Either<Failure, Document>> finalizeSession(int sessionId, {String? name, SaveFormat format = SaveFormat.pdf});
  Future<Either<Failure, void>> cancelSession(int sessionId);
  Future<Either<Failure, List<ScanPage>>> getSessionPages(int sessionId);
}
