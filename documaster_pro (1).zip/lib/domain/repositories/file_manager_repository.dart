import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../entities/document.dart';

class FileItem {
  final String path;
  final String name;
  final FileType type;
  final int size;
  final DateTime modifiedAt;
  final bool isDirectory;

  FileItem({
    required this.path,
    required this.name,
    required this.type,
    required this.size,
    required this.modifiedAt,
    this.isDirectory = false,
  });
}

enum SortOption { name, date, size, type }

abstract class FileManagerRepository {
  Future<Either<Failure, List<FileItem>>> listDirectory(String path);
  Future<Either<Failure, void>> createFolder(String path, String name);
  Future<Either<Failure, void>> rename(String oldPath, String newName);
  Future<Either<Failure, void>> copy(String sourcePath, String destPath);
  Future<Either<Failure, void>> move(String sourcePath, String destPath);
  Future<Either<Failure, void>> delete(String path);
  Future<Either<Failure, void>> share(String path);
  Future<Either<Failure, List<FileItem>>> search(String query, {FileType? type});
  Future<Either<Failure, int>> getStorageUsage();
  Future<Either<Failure, void>> openFile(String path);
}
