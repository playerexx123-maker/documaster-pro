import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:adaptive_theme/adaptive_theme.dart';
import 'package:get_it/get_it.dart';
import 'config/routes.dart';
import 'config/theme.dart';
import 'presentation/blocs/home/home_cubit.dart';
import 'presentation/blocs/scanner/scanner_cubit.dart';
import 'presentation/blocs/ocr/ocr_cubit.dart';
import 'presentation/blocs/files/files_cubit.dart';
import 'presentation/blocs/editor/editor_cubit.dart';
import 'presentation/blocs/ai_assistant/ai_assistant_cubit.dart';
import 'presentation/blocs/settings/settings_cubit.dart';
import 'presentation/blocs/auth/auth_cubit.dart';
import 'presentation/blocs/search/search_cubit.dart';
import 'presentation/blocs/image_editor/image_editor_cubit.dart';

class DocuMasterApp extends StatelessWidget {
  const DocuMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AdaptiveTheme(
      light: AppTheme.lightTheme,
      dark: AppTheme.darkTheme,
      initial: AdaptiveThemeMode.system,
      builder: (theme, darkTheme) => MultiBlocProvider(
        providers: [
          BlocProvider<HomeCubit>(create: (_) => GetIt.I<HomeCubit>()),
          BlocProvider<ScannerCubit>(create: (_) => GetIt.I<ScannerCubit>()),
          BlocProvider<OcrCubit>(create: (_) => GetIt.I<OcrCubit>()),
          BlocProvider<FilesCubit>(create: (_) => GetIt.I<FilesCubit>()),
          BlocProvider<EditorCubit>(create: (_) => GetIt.I<EditorCubit>()),
          BlocProvider<AIAssistantCubit>(create: (_) => GetIt.I<AIAssistantCubit>()),
          BlocProvider<SettingsCubit>(create: (_) => GetIt.I<SettingsCubit>()),
          BlocProvider<AuthCubit>(create: (_) => GetIt.I<AuthCubit>()),
          BlocProvider<SearchCubit>(create: (_) => GetIt.I<SearchCubit>()),
          BlocProvider<ImageEditorCubit>(create: (_) => GetIt.I<ImageEditorCubit>()),
        ],
        child: MaterialApp.router(
          title: 'DocuMaster Pro',
          debugShowCheckedModeBanner: false,
          theme: theme,
          darkTheme: darkTheme,
          routerConfig: AppRouter.router,
        ),
      ),
    );
  }
}
