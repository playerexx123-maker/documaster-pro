import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import '../core/errors/exceptions.dart';

class ThumbnailService {
  static const int thumbnailWidth = 200;
  static const int thumbnailHeight = 280;

  Future<String> generateThumbnail(String filePath, String outputPath) async {
    try {
      final file = File(filePath);
      if (!await file.exists()) {
        throw FileSystemException('File not found: $filePath');
      }

      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) {
        throw FileSystemException('Failed to decode image for thumbnail');
      }

      final thumbnail = img.copyResize(
        image,
        width: thumbnailWidth,
        height: thumbnailHeight,
      );

      final thumbnailBytes = img.encodeJpg(thumbnail, quality: 85);
      await File(outputPath).writeAsBytes(thumbnailBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Thumbnail generation failed: $e');
    }
  }

  Future<Uint8List?> getThumbnailBytes(String thumbnailPath) async {
    try {
      final file = File(thumbnailPath);
      if (await file.exists()) {
        return await file.readAsBytes();
      }
      return null;
    } catch (e) {
      return null;
    }
  }
}
