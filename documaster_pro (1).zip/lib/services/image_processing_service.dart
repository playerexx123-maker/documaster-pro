import 'dart:io';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import '../core/errors/exceptions.dart';
import '../domain/entities/scan_page.dart';

class ImageProcessingService {
  Future<String> applyFilter(String imagePath, ScanFilter filter, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) {
        throw FileSystemException('Failed to decode image');
      }

      switch (filter) {
        case ScanFilter.grayscale:
          image = img.grayscale(image);
          break;
        case ScanFilter.bw:
          image = img.threshold(image, threshold: 128);
          break;
        case ScanFilter.autoEnhance:
          image = img.adjustColor(
            image,
            contrast: 1.2,
            saturation: 1.1,
          );
          break;
        case ScanFilter.shadowRemoval:
          image = img.adjustColor(
            image,
            brightness: 1.1,
            contrast: 1.3,
          );
          break;
        case ScanFilter.color:
        case ScanFilter.none:
        default:
          break;
      }

      final outputBytes = img.encodeJpg(image, quality: 90);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Image processing failed: $e');
    }
  }

  Future<String> cropImage(String imagePath, int x, int y, int w, int h, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      final cropped = img.copyCrop(image, x: x, y: y, width: w, height: h);
      final outputBytes = img.encodeJpg(cropped, quality: 95);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Image crop failed: $e');
    }
  }

  Future<String> resizeImage(String imagePath, int width, int height, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      final resized = img.copyResize(image, width: width, height: height);
      final outputBytes = img.encodeJpg(resized, quality: 90);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Image resize failed: $e');
    }
  }

  Future<String> rotateImage(String imagePath, double angle, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      final rotated = img.copyRotate(image, angle: angle);
      final outputBytes = img.encodeJpg(rotated, quality: 95);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Image rotation failed: $e');
    }
  }

  Future<String> adjustBrightness(String imagePath, double value, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      final adjusted = img.adjustColor(image, brightness: value);
      final outputBytes = img.encodeJpg(adjusted, quality: 90);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Brightness adjustment failed: $e');
    }
  }

  Future<String> adjustContrast(String imagePath, double value, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      final adjusted = img.adjustColor(image, contrast: value);
      final outputBytes = img.encodeJpg(adjusted, quality: 90);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Contrast adjustment failed: $e');
    }
  }

  Future<String> sharpenImage(String imagePath, double amount, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      final sharpened = img.convolution(image, filter: [0, -1, 0, -1, 5, -1, 0, -1, 0]);
      final outputBytes = img.encodeJpg(sharpened, quality: 90);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Sharpening failed: $e');
    }
  }

  Future<String> compressImage(String imagePath, int quality, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      final outputBytes = img.encodeJpg(image, quality: quality);
      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Image compression failed: $e');
    }
  }

  Future<String> convertFormat(String imagePath, String format, String outputPath) async {
    try {
      final file = File(imagePath);
      final bytes = await file.readAsBytes();
      img.Image? image = img.decodeImage(bytes);
      if (image == null) throw FileSystemException('Failed to decode image');

      late Uint8List outputBytes;
      switch (format.toLowerCase()) {
        case 'png':
          outputBytes = img.encodePng(image);
          break;
        case 'jpg':
        case 'jpeg':
          outputBytes = img.encodeJpg(image, quality: 95);
          break;
        case 'bmp':
          outputBytes = img.encodeBmp(image);
          break;
        default:
          outputBytes = img.encodeJpg(image, quality: 95);
      }

      await File(outputPath).writeAsBytes(outputBytes);
      return outputPath;
    } catch (e) {
      throw FileSystemException('Format conversion failed: $e');
    }
  }
}
