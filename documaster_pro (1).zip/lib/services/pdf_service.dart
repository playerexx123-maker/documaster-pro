import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../core/errors/exceptions.dart';
import '../domain/entities/pdf_annotation.dart';

class PdfService {
  Future<int> getPageCount(String path) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      final count = document.pages.count;
      document.dispose();
      return count;
    } catch (e) {
      throw PdfException('Failed to get page count: $e');
    }
  }

  Future<Uint8List> renderPage(String path, int pageNumber, {int width = 800}) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      final page = document.pages[pageNumber - 1];
      // Use Syncfusion PDF viewer rendering or custom implementation
      document.dispose();
      throw UnimplementedError('PDF rendering requires platform-specific implementation');
    } catch (e) {
      throw PdfException('Failed to render page: $e');
    }
  }

  Future<String> mergePdfs(List<String> paths, String outputPath) async {
    try {
      final mergedDoc = PdfDocument();
      for (final path in paths) {
        final doc = PdfDocument(inputBytes: await _readFileBytes(path));
        mergedDoc.importPage(doc, List.generate(doc.pages.count, (i) => i));
        doc.dispose();
      }
      final bytes = await mergedDoc.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      mergedDoc.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to merge PDFs: $e');
    }
  }

  Future<String> encryptPdf(String path, String password, String outputPath) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      final security = PdfSecurity();
      security.userPassword = password;
      security.ownerPassword = password;
      document.security = security;
      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to encrypt PDF: $e');
    }
  }

  Future<String> decryptPdf(String path, String password, String outputPath) async {
    try {
      final document = PdfDocument(
        inputBytes: await _readFileBytes(path),
        password: password,
      );
      document.security = PdfSecurity();
      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to decrypt PDF: $e');
    }
  }

  Future<String> addWatermark(
    String path,
    String text,
    String outputPath, {
    double fontSize = 48,
    Color color = Colors.grey,
    double opacity = 0.3,
    int pages = 0,
  }) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      final startPage = pages > 0 ? pages - 1 : 0;
      final endPage = pages > 0 ? pages - 1 : document.pages.count - 1;

      for (var i = startPage; i <= endPage && i < document.pages.count; i++) {
        final page = document.pages[i];
        final graphics = page.graphics;
        final pdfFont = PdfStandardFont(PdfFontFamily.helvetica, fontSize);
        final pdfColor = PdfColor(color.red, color.green, color.blue);
        final brush = PdfSolidBrush(pdfColor);
        final size = pdfFont.measureString(text);
        final pageSize = page.getClientSize();
        final x = (pageSize.width - size.width) / 2;
        final y = (pageSize.height - size.height) / 2;

        graphics.save();
        graphics.setTransparency(opacity);
        graphics.drawString(
          text,
          pdfFont,
          brush: brush,
          bounds: Rect.fromLTWH(x, y, size.width, size.height),
        );
        graphics.restore();
      }

      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to add watermark: $e');
    }
  }

  Future<String> compressPdf(String path, String outputPath, {int quality = 2}) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      // Set compression level based on quality parameter
      if (quality >= 3) {
        document.compressionLevel = PdfCompressionLevel.best;
      } else if (quality >= 2) {
        document.compressionLevel = PdfCompressionLevel.normal;
      } else {
        document.compressionLevel = PdfCompressionLevel.best;
      }
      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to compress PDF: $e');
    }
  }

  Future<String> rotatePage(String path, int pageNumber, int angle, String outputPath) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      if (pageNumber > 0 && pageNumber <= document.pages.count) {
        final page = document.pages[pageNumber - 1];
        // Syncfusion PDF rotation
        page.rotation = _angleToPdfRotation(angle);
      }
      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to rotate page: $e');
    }
  }

  Future<String> deletePages(String path, List<int> pageNumbers, String outputPath) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      // Sort in descending order to remove from end
      final sorted = pageNumbers.toSet().toList()..sort((a, b) => b.compareTo(a));
      for (final pageNum in sorted) {
        if (pageNum > 0 && pageNum <= document.pages.count) {
          document.pages.removeAt(pageNum - 1);
        }
      }
      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to delete pages: $e');
    }
  }

  Future<String> reorderPages(String path, List<int> newOrder, String outputPath) async {
    try {
      final sourceDoc = PdfDocument(inputBytes: await _readFileBytes(path));
      final resultDoc = PdfDocument();

      for (final pageNum in newOrder) {
        if (pageNum > 0 && pageNum <= sourceDoc.pages.count) {
          resultDoc.importPage(sourceDoc, [pageNum - 1]);
        }
      }

      final bytes = await resultDoc.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      sourceDoc.dispose();
      resultDoc.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to reorder pages: $e');
    }
  }

  Future<String> duplicatePage(String path, int pageNumber, String outputPath) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      if (pageNumber > 0 && pageNumber <= document.pages.count) {
        document.importPage(document, [pageNumber - 1]);
      }
      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to duplicate page: $e');
    }
  }

  Future<String> addPageNumbers(
    String path,
    String outputPath, {
    int startNumber = 1,
    String format = '{n}',
    double fontSize = 12,
    Color color = Colors.black,
    String position = 'bottom_center',
  }) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));
      final pdfFont = PdfStandardFont(PdfFontFamily.helvetica, fontSize);
      final pdfColor = PdfColor(color.red, color.green, color.blue);
      final brush = PdfSolidBrush(pdfColor);

      for (var i = 0; i < document.pages.count; i++) {
        final page = document.pages[i];
        final graphics = page.graphics;
        final pageNum = startNumber + i;
        final text = format.replaceAll('{n}', '$pageNum');
        final size = pdfFont.measureString(text);
        final pageSize = page.getClientSize();

        late final double x;
        late final double y;

        switch (position) {
          case 'top_left':
            x = 20;
            y = 20;
            break;
          case 'top_right':
            x = pageSize.width - size.width - 20;
            y = 20;
            break;
          case 'top_center':
            x = (pageSize.width - size.width) / 2;
            y = 20;
            break;
          case 'bottom_left':
            x = 20;
            y = pageSize.height - size.height - 20;
            break;
          case 'bottom_right':
            x = pageSize.width - size.width - 20;
            y = pageSize.height - size.height - 20;
            break;
          case 'bottom_center':
          default:
            x = (pageSize.width - size.width) / 2;
            y = pageSize.height - size.height - 20;
            break;
        }

        graphics.drawString(
          text,
          pdfFont,
          brush: brush,
          bounds: Rect.fromLTWH(x, y, size.width, size.height),
        );
      }

      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to add page numbers: $e');
    }
  }

  Future<String> annotatePdf(
    String path,
    List<PdfAnnotation> annotations,
    String outputPath,
  ) async {
    try {
      final document = PdfDocument(inputBytes: await _readFileBytes(path));

      for (final annotation in annotations) {
        if (annotation.pageNumber < 1 || annotation.pageNumber > document.pages.count) {
          continue;
        }

        final page = document.pages[annotation.pageNumber - 1];
        final graphics = page.graphics;

        switch (annotation.type) {
          case AnnotationType.draw:
            if (annotation.points != null && annotation.points!.isNotEmpty) {
              await _drawAnnotation(graphics, annotation);
            }
            break;
          case AnnotationType.textBox:
            if (annotation.content != null) {
              await _drawTextBox(page, annotation);
            }
            break;
          case AnnotationType.comment:
          case AnnotationType.stickyNote:
            if (annotation.content != null) {
              await _drawStickyNote(page, annotation);
            }
            break;
          case AnnotationType.highlight:
            if (annotation.rect != null) {
              await _drawHighlight(page, annotation);
            }
            break;
          case AnnotationType.underline:
            if (annotation.rect != null) {
              await _drawUnderline(page, annotation);
            }
            break;
          case AnnotationType.strikeout:
            if (annotation.rect != null) {
              await _drawStrikeout(page, annotation);
            }
            break;
          case AnnotationType.signature:
            if (annotation.points != null && annotation.points!.isNotEmpty) {
              await _drawSignature(page, annotation);
            }
            break;
        }
      }

      final bytes = await document.save();
      await _writeFileBytes(outputPath, Uint8List.fromList(bytes));
      document.dispose();
      return outputPath;
    } catch (e) {
      throw PdfException('Failed to annotate PDF: $e');
    }
  }

  // ─── Private Drawing Helpers ───

  Future<void> _drawAnnotation(
    PdfGraphics graphics,
    PdfAnnotation annotation,
  ) async {
    if (annotation.points == null || annotation.points!.isEmpty) return;

    final color = annotation.color ?? Colors.black;
    final pen = PdfPen(
      PdfColor(color.red, color.green, color.blue),
      width: annotation.points!.length > 1
          ? _estimateStrokeWidth(annotation.points!)
          : 2,
    );

    final points = annotation.points!;
    for (int i = 1; i < points.length; i++) {
      if (points[i - 1].x.isNaN || points[i].x.isNaN) continue;
      graphics.drawLine(
        pen,
        Offset(points[i - 1].x, points[i - 1].y),
        Offset(points[i].x, points[i].y),
      );
    }
  }

  Future<void> _drawTextBox(
    PdfPage page,
    PdfAnnotation annotation,
  ) async {
    final graphics = page.graphics;
    final rect = annotation.rect ?? Rect.fromLTWH(50, 50, 200, 50);
    final color = annotation.color ?? Colors.black;
    final font = PdfStandardFont(PdfFontFamily.helvetica, 12);
    final brush = PdfSolidBrush(PdfColor(color.red, color.green, color.blue));

    graphics.drawString(
      annotation.content ?? '',
      font,
      brush: brush,
      bounds: rect,
    );
  }

  Future<void> _drawStickyNote(
    PdfPage page,
    PdfAnnotation annotation,
  ) async {
    final graphics = page.graphics;
    final rect = annotation.rect ?? Rect.fromLTWH(50, 50, 150, 100);
    final color = annotation.color ?? Colors.yellow;

    // Draw note background
    final brush = PdfSolidBrush(PdfColor(color.red, color.green, color.blue));
    final borderPen = PdfPen(PdfColor(200, 180, 0));

    graphics.drawRectangle(pen: borderPen, brush: brush, bounds: rect);

    // Draw text
    final font = PdfStandardFont(PdfFontFamily.helvetica, 10);
    final textBrush = PdfSolidBrush(PdfColor(0, 0, 0));
    graphics.drawString(
      annotation.content ?? '',
      font,
      brush: textBrush,
      bounds: rect.deflate(4),
    );
  }

  Future<void> _drawHighlight(
    PdfPage page,
    PdfAnnotation annotation,
  ) async {
    final graphics = page.graphics;
    final rect = annotation.rect!;
    final color = annotation.color ?? Colors.yellow;

    final brush = PdfSolidBrush(
      PdfColor(color.red, color.green, color.blue, 128),
    );

    graphics.save();
    graphics.setTransparency(0.4);
    graphics.drawRectangle(brush: brush, bounds: rect);
    graphics.restore();
  }

  Future<void> _drawUnderline(
    PdfPage page,
    PdfAnnotation annotation,
  ) async {
    final graphics = page.graphics;
    final rect = annotation.rect!;
    final color = annotation.color ?? Colors.blue;

    final pen = PdfPen(PdfColor(color.red, color.green, color.blue), width: 1.5);
    final y = rect.bottom - 2;

    graphics.drawLine(pen, Offset(rect.left, y), Offset(rect.right, y));
  }

  Future<void> _drawStrikeout(
    PdfPage page,
    PdfAnnotation annotation,
  ) async {
    final graphics = page.graphics;
    final rect = annotation.rect!;
    final color = annotation.color ?? Colors.red;

    final pen = PdfPen(PdfColor(color.red, color.green, color.blue), width: 1.5);
    final y = rect.top + (rect.height / 2);

    graphics.drawLine(pen, Offset(rect.left, y), Offset(rect.right, y));
  }

  Future<void> _drawSignature(
    PdfPage page,
    PdfAnnotation annotation,
  ) async {
    final graphics = page.graphics;
    if (annotation.points == null || annotation.points!.isEmpty) return;

    final color = annotation.color ?? Colors.black;
    final pen = PdfPen(PdfColor(color.red, color.green, color.blue), width: 2);

    final points = annotation.points!;
    for (int i = 1; i < points.length; i++) {
      if (points[i - 1].x.isNaN || points[i].x.isNaN) continue;
      graphics.drawLine(
        pen,
        Offset(points[i - 1].x, points[i - 1].y),
        Offset(points[i].x, points[i].y),
      );
    }
  }

  double _estimateStrokeWidth(List<Point<double>> points) {
    if (points.length < 2) return 2;
    double totalDist = 0;
    for (int i = 1; i < points.length; i++) {
      totalDist += sqrt(
        pow(points[i].x - points[i - 1].x, 2) +
            pow(points[i].y - points[i - 1].y, 2),
      );
    }
    final avgDist = totalDist / (points.length - 1);
    return avgDist.clamp(1.0, 5.0);
  }

  // ─── File I/O ───

  Future<Uint8List> _readFileBytes(String path) async {
    final file = File(path);
    if (!await file.exists()) {
      throw PdfException('File not found: $path');
    }
    return await file.readAsBytes();
  }

  Future<void> _writeFileBytes(String path, Uint8List bytes) async {
    final file = File(path);
    final dir = file.parent;
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    await file.writeAsBytes(bytes);
  }

  // ─── Helpers ───

  PdfPageRotateAngle _angleToPdfRotation(int angle) {
    final normalized = ((angle % 360) + 360) % 360;
    switch (normalized) {
      case 90:
        return PdfPageRotateAngle.rotateAngle90;
      case 180:
        return PdfPageRotateAngle.rotateAngle180;
      case 270:
        return PdfPageRotateAngle.rotateAngle270;
      default:
        return PdfPageRotateAngle.rotateAngle0;
    }
  }
}
