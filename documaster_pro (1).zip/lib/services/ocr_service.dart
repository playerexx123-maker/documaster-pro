import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../core/errors/exceptions.dart';

class OcrService {
  late final TextRecognizer _textRecognizer;

  OcrService() {
    _textRecognizer = TextRecognizer(script: TextRecognitionScript.latin);
  }

  Future<String> recognizeText(String imagePath, {String language = 'en'}) async {
    try {
      final file = File(imagePath);
      if (!await file.exists()) {
        throw OcrException('Image file not found: $imagePath');
      }

      final inputImage = InputImage.fromFilePath(imagePath);
      final RecognizedText recognizedText = await _textRecognizer.processImage(inputImage);

      final StringBuffer buffer = StringBuffer();
      for (final block in recognizedText.blocks) {
        for (final line in block.lines) {
          buffer.writeln(line.text);
        }
      }

      return buffer.toString().trim();
    } catch (e) {
      throw OcrException('OCR failed: $e');
    }
  }

  Future<Map<String, dynamic>> recognizeTextDetailed(String imagePath, {String language = 'en'}) async {
    try {
      final inputImage = InputImage.fromFilePath(imagePath);
      final RecognizedText recognizedText = await _textRecognizer.processImage(inputImage);

      final List<Map<String, dynamic>> blocks = [];
      double totalConfidence = 0;
      int elementCount = 0;

      for (final block in recognizedText.blocks) {
        for (final line in block.lines) {
          for (final element in line.elements) {
            totalConfidence += element.confidence;
            elementCount++;
          }
        }
        blocks.add({
          'text': block.text,
          'cornerPoints': block.cornerPoints.map((p) => {'x': p.x, 'y': p.y}).toList(),
          'boundingBox': {
            'left': block.boundingBox.left,
            'top': block.boundingBox.top,
            'width': block.boundingBox.width,
            'height': block.boundingBox.height,
          },
        });
      }

      final avgConfidence = elementCount > 0 ? totalConfidence / elementCount : 0.0;

      return {
        'text': recognizedText.text,
        'blocks': blocks,
        'confidence': avgConfidence,
        'language': language,
      };
    } catch (e) {
      throw OcrException('OCR detailed recognition failed: $e');
    }
  }

  Future<bool> isLanguageSupported(String languageCode) async {
    // Google ML Kit supports Latin, Chinese, Devanagari, Japanese, Korean
    final supportedLanguages = ['en', 'ro', 'hu', 'de', 'it'];
    return supportedLanguages.contains(languageCode);
  }

  void close() {
    _textRecognizer.close();
  }
}
