class AppException implements Exception {
  final String message;
  final String? code;

  const AppException(this.message, {this.code});

  @override
  String toString() => 'AppException: \$message (code: \$code)';
}

class DatabaseException extends AppException {
  const DatabaseException(super.message, {super.code});
}

class FileSystemException extends AppException {
  const FileSystemException(super.message, {super.code});
}

class OcrException extends AppException {
  const OcrException(super.message, {super.code});
}

class PdfException extends AppException {
  const PdfException(super.message, {super.code});
}

class NetworkException extends AppException {
  const NetworkException(super.message, {super.code});
}

class AuthException extends AppException {
  const AuthException(super.message, {super.code});
}

class ConversionException extends AppException {
  const ConversionException(super.message, {super.code});
}

class ValidationException extends AppException {
  const ValidationException(super.message, {super.code});
}
