import 'dart:io';
import 'package:mime/mime.dart';
import '../../domain/entities/document.dart';

class FileUtils {
  FileUtils._();

  static FileType getFileType(String path) {
    final ext = path.toLowerCase().split('.').last;
    switch (ext) {
      case 'pdf': return FileType.pdf;
      case 'docx': case 'doc': return FileType.docx;
      case 'xlsx': case 'xls': return FileType.xlsx;
      case 'pptx': case 'ppt': return FileType.pptx;
      case 'txt': return FileType.txt;
      case 'md': return FileType.md;
      case 'csv': return FileType.csv;
      case 'json': return FileType.json;
      case 'xml': return FileType.xml;
      case 'html': case 'htm': return FileType.html;
      case 'jpg': case 'jpeg': case 'png': case 'gif': case 'bmp': case 'webp':
        return FileType.image;
      default: return FileType.unknown;
    }
  }

  static String getMimeType(String path) {
    return lookupMimeType(path) ?? 'application/octet-stream';
  }

  static String generateFileName(String prefix, String extension) {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    return '${prefix}_$timestamp.$extension';
  }

  static Future<String> getUniqueFilePath(String directory, String fileName) async {
    String path = '$directory/$fileName';
    int counter = 1;
    final nameWithoutExt = fileName.substring(0, fileName.lastIndexOf('.'));
    final ext = fileName.substring(fileName.lastIndexOf('.') + 1);

    while (await File(path).exists()) {
      path = '$directory/${nameWithoutExt}_($counter).$ext';
      counter++;
    }
    return path;
  }

  static Future<int> getFileSize(String path) async {
    final file = File(path);
    if (await file.exists()) {
      return await file.length();
    }
    return 0;
  }

  static Future<void> ensureDirectory(String path) async {
    final dir = Directory(path);
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
  }

  static Future<void> copyFile(String source, String destination) async {
    await File(source).copy(destination);
  }

  static Future<void> moveFile(String source, String destination) async {
    await File(source).rename(destination);
  }
}
