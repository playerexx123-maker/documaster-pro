import 'package:flutter/material.dart';
import '../../domain/entities/document.dart';
import '../../config/extensions.dart';

class FileIcon extends StatelessWidget {
  final FileType fileType;
  final double size;
  final bool showBackground;

  const FileIcon({
    super.key,
    required this.fileType,
    this.size = 40,
    this.showBackground = true,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: showBackground
          ? BoxDecoration(
              color: fileType.color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(size * 0.2),
            )
          : null,
      child: Icon(
        fileType.icon,
        size: size * 0.5,
        color: fileType.color,
      ),
    );
  }
}

class FileListItem extends StatelessWidget {
  final String name;
  final FileType fileType;
  final int fileSize;
  final DateTime modifiedAt;
  final VoidCallback? onTap;
  final VoidCallback? onMore;

  const FileListItem({
    super.key,
    required this.name,
    required this.fileType,
    required this.fileSize,
    required this.modifiedAt,
    this.onTap,
    this.onMore,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: FileIcon(fileType: fileType, size: 40),
      title: Text(
        name,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        '${fileSize.fileSize} · ${modifiedAt.timeAgo}',
        style: Theme.of(context).textTheme.bodySmall,
      ),
      trailing: onMore != null
          ? IconButton(
              icon: const Icon(Icons.more_vert),
              onPressed: onMore,
            )
          : null,
      onTap: onTap,
    );
  }
}
