import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/repositories/ai_repository.dart';
import '../../../domain/usecases/ai/summarize_pdf.dart';
import '../../../domain/usecases/ai/translate_document.dart';
import '../../../domain/usecases/ai/explain_text.dart';
import '../../../domain/usecases/ai/extract_tables.dart';
import '../../../domain/usecases/ai/generate_title.dart';
import '../../../domain/usecases/ai/generate_tags.dart';
import '../../../domain/usecases/ai/chat_with_pdf.dart';

part 'ai_assistant_state.dart';

class ChatMessage {
  final String content;
  final bool isUser;
  final DateTime timestamp;
  final MessageType type;

  ChatMessage({
    required this.content,
    required this.isUser,
    required this.timestamp,
    this.type = MessageType.text,
  });
}

enum MessageType { text, summary, translation, explanation, table, title, tags }

enum AIAction { none, summarizing, translating, explaining, extractingTables, generatingTitle, generatingTags, chatting }

class AIAssistantCubit extends Cubit<AIState> {
  final AIRepository _aiRepository;
  final SummarizePdfUseCase _summarizePdf;
  final TranslateDocumentUseCase _translateDocument;
  final ExplainTextUseCase _explainText;
  final ExtractTablesUseCase _extractTables;
  final GenerateTitleUseCase _generateTitle;
  final GenerateTagsUseCase _generateTags;
  final ChatWithPdfUseCase _chatWithPdf;

  AIAssistantCubit({
    required AIRepository aiRepository,
    required SummarizePdfUseCase summarizePdf,
    required TranslateDocumentUseCase translateDocument,
    required ExplainTextUseCase explainText,
    required ExtractTablesUseCase extractTables,
    required GenerateTitleUseCase generateTitle,
    required GenerateTagsUseCase generateTags,
    required ChatWithPdfUseCase chatWithPdf,
  })  : _aiRepository = aiRepository,
        _summarizePdf = summarizePdf,
        _translateDocument = translateDocument,
        _explainText = explainText,
        _extractTables = extractTables,
        _generateTitle = generateTitle,
        _generateTags = generateTags,
        _chatWithPdf = chatWithPdf,
        super(const AIState());

  void loadDocument(String path) {
    emit(state.copyWith(currentDocument: path));
  }

  void setCurrentDocument(String? path) {
    emit(state.copyWith(currentDocument: path));
  }

  Future<void> askQuestion(String question) async {
    if (state.currentDocument == null) {
      emit(state.copyWith(error: 'No document loaded'));
      return;
    }

    final userMessage = ChatMessage(
      content: question,
      isUser: true,
      timestamp: DateTime.now(),
    );
    final updatedMessages = List<ChatMessage>.from(state.messages)..add(userMessage);
    emit(state.copyWith(messages: updatedMessages, isProcessing: true, error: null));

    final result = await _chatWithPdf(ChatWithPdfParams(
      pdfPath: state.currentDocument!,
      question: question,
    ));
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (response) {
        final aiMessage = ChatMessage(
          content: response,
          isUser: false,
          timestamp: DateTime.now(),
          type: MessageType.text,
        );
        final newMessages = List<ChatMessage>.from(state.messages)..add(aiMessage);
        emit(state.copyWith(messages: newMessages, isProcessing: false));
      },
    );
  }

  Future<void> summarize() async {
    if (state.currentDocument == null) {
      emit(state.copyWith(error: 'No document loaded'));
      return;
    }
    emit(state.copyWith(isProcessing: true, currentAction: AIAction.summarizing, error: null));

    final result = await _summarizePdf(SummarizePdfParams(
      pdfPath: state.currentDocument!,
    ));
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (summary) {
        final message = ChatMessage(
          content: summary,
          isUser: false,
          timestamp: DateTime.now(),
          type: MessageType.summary,
        );
        final newMessages = List<ChatMessage>.from(state.messages)..add(message);
        emit(state.copyWith(
          messages: newMessages,
          isProcessing: false,
          currentAction: AIAction.none,
          lastResult: summary,
        ));
      },
    );
  }

  Future<void> translate(String targetLanguage) async {
    if (state.currentDocument == null) {
      emit(state.copyWith(error: 'No document loaded'));
      return;
    }
    emit(state.copyWith(isProcessing: true, currentAction: AIAction.translating, error: null));

    final result = await _translateDocument(TranslateDocumentParams(
      documentPath: state.currentDocument!,
      targetLanguage: targetLanguage,
    ));
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (translation) {
        final message = ChatMessage(
          content: translation,
          isUser: false,
          timestamp: DateTime.now(),
          type: MessageType.translation,
        );
        final newMessages = List<ChatMessage>.from(state.messages)..add(message);
        emit(state.copyWith(
          messages: newMessages,
          isProcessing: false,
          currentAction: AIAction.none,
          lastResult: translation,
        ));
      },
    );
  }

  Future<void> explainText(String text) async {
    if (text.isEmpty) {
      emit(state.copyWith(error: 'No text provided'));
      return;
    }
    emit(state.copyWith(isProcessing: true, currentAction: AIAction.explaining, error: null));

    final result = await _explainText(ExplainTextParams(
      text: text,
    ));
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (explanation) {
        final message = ChatMessage(
          content: explanation,
          isUser: false,
          timestamp: DateTime.now(),
          type: MessageType.explanation,
        );
        final newMessages = List<ChatMessage>.from(state.messages)..add(message);
        emit(state.copyWith(
          messages: newMessages,
          isProcessing: false,
          currentAction: AIAction.none,
          lastResult: explanation,
        ));
      },
    );
  }

  Future<void> extractTables(int pageNumber) async {
    if (state.currentDocument == null) {
      emit(state.copyWith(error: 'No document loaded'));
      return;
    }
    emit(state.copyWith(isProcessing: true, currentAction: AIAction.extractingTables, error: null));

    final result = await _extractTables(ExtractTablesParams(
      pdfPath: state.currentDocument!,
      pageNumber: pageNumber,
    ));
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (tables) {
        final tableStr = tables.isEmpty
            ? 'No tables found on page $pageNumber.'
            : tables.asMap().entries.map((e) {
                final headers = (e.value['headers'] as List?)?.join(' | ') ?? '';
                final rows = (e.value['rows'] as List?)?.map((r) => (r as List).join(' | ')).join('\n') ?? '';
                return '**Table ${e.key + 1}**\n$headers\n${"-" * headers.length}\n$rows';
              }).join('\n\n');
        final message = ChatMessage(
          content: tableStr,
          isUser: false,
          timestamp: DateTime.now(),
          type: MessageType.table,
        );
        final newMessages = List<ChatMessage>.from(state.messages)..add(message);
        emit(state.copyWith(
          messages: newMessages,
          isProcessing: false,
          currentAction: AIAction.none,
          lastResult: tableStr,
          extractedTables: tables,
        ));
      },
    );
  }

  Future<void> generateTitle() async {
    if (state.currentDocument == null) {
      emit(state.copyWith(error: 'No document loaded'));
      return;
    }
    emit(state.copyWith(isProcessing: true, currentAction: AIAction.generatingTitle, error: null));

    final result = await _generateTitle(GenerateTitleParams(
      documentPath: state.currentDocument!,
    ));
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (title) {
        final message = ChatMessage(
          content: '**Generated Title:** $title',
          isUser: false,
          timestamp: DateTime.now(),
          type: MessageType.title,
        );
        final newMessages = List<ChatMessage>.from(state.messages)..add(message);
        emit(state.copyWith(
          messages: newMessages,
          isProcessing: false,
          currentAction: AIAction.none,
          lastResult: title,
        ));
      },
    );
  }

  Future<void> generateTags() async {
    if (state.currentDocument == null) {
      emit(state.copyWith(error: 'No document loaded'));
      return;
    }
    emit(state.copyWith(isProcessing: true, currentAction: AIAction.generatingTags, error: null));

    final result = await _generateTags(GenerateTagsParams(
      documentPath: state.currentDocument!,
    ));
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (tags) {
        final tagsStr = tags.isEmpty
            ? 'No tags generated.'
            : tags.map((t) => '#$t').join('  ');
        final message = ChatMessage(
          content: '**Generated Tags:**\n$tagsStr',
          isUser: false,
          timestamp: DateTime.now(),
          type: MessageType.tags,
        );
        final newMessages = List<ChatMessage>.from(state.messages)..add(message);
        emit(state.copyWith(
          messages: newMessages,
          isProcessing: false,
          currentAction: AIAction.none,
          lastResult: tagsStr,
          generatedTags: tags,
        ));
      },
    );
  }

  void clearChat() {
    emit(state.copyWith(messages: [], error: null, lastResult: null));
  }

  void clearError() {
    emit(state.copyWith(error: null));
  }

  void clearResult() {
    emit(state.copyWith(lastResult: null, extractedTables: const [], generatedTags: const []));
  }
}
