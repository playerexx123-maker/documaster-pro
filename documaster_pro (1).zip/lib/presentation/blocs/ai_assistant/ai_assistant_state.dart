part of 'ai_assistant_cubit.dart';

class AIState extends Equatable {
  final List<ChatMessage> messages;
  final bool isProcessing;
  final String? currentDocument;
  final AIAction? currentAction;
  final String? error;
  final String? lastResult;
  final List<Map<String, dynamic>> extractedTables;
  final List<String> generatedTags;

  const AIState({
    this.messages = const [],
    this.isProcessing = false,
    this.currentDocument,
    this.currentAction,
    this.error,
    this.lastResult,
    this.extractedTables = const [],
    this.generatedTags = const [],
  });

  AIState copyWith({
    List<ChatMessage>? messages,
    bool? isProcessing,
    String? currentDocument,
    AIAction? currentAction,
    String? error,
    String? lastResult,
    List<Map<String, dynamic>>? extractedTables,
    List<String>? generatedTags,
  }) {
    return AIState(
      messages: messages ?? this.messages,
      isProcessing: isProcessing ?? this.isProcessing,
      currentDocument: currentDocument ?? this.currentDocument,
      currentAction: currentAction == null ? this.currentAction : currentAction,
      error: error,
      lastResult: lastResult ?? this.lastResult,
      extractedTables: extractedTables ?? this.extractedTables,
      generatedTags: generatedTags ?? this.generatedTags,
    );
  }

  @override
  List<Object?> get props => [
    messages,
    isProcessing,
    currentDocument,
    currentAction,
    error,
    lastResult,
    extractedTables,
    generatedTags,
  ];
}
