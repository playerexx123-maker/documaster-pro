import 'dart:ui';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/repositories/image_editor_repository.dart';
import '../../../domain/usecases/image_editor/crop_image.dart';
import '../../../domain/usecases/image_editor/resize_image.dart';
import '../../../domain/usecases/image_editor/rotate_image.dart';
import '../../../domain/usecases/image_editor/adjust_brightness.dart';
import '../../../domain/usecases/image_editor/adjust_contrast.dart';
import '../../../domain/usecases/image_editor/sharpen_image.dart';
import '../../../domain/usecases/image_editor/convert_image_format.dart';
import '../../../domain/usecases/image_editor/remove_background.dart';
import '../../../domain/usecases/image_editor/compress_image.dart';

part 'image_editor_state.dart';

class ImageEditorCubit extends Cubit<ImageEditorState> {
  final ImageEditorRepository _repository;
  final CropImageUseCase _cropImage;
  final ResizeImageUseCase _resizeImage;
  final RotateImageUseCase _rotateImage;
  final AdjustBrightnessUseCase _adjustBrightness;
  final AdjustContrastUseCase _adjustContrast;
  final SharpenImageUseCase _sharpenImage;
  final ConvertImageFormatUseCase _convertFormat;
  final RemoveBackgroundUseCase _removeBackground;
  final CompressImageUseCase _compressImage;

  ImageEditorCubit({
    required ImageEditorRepository repository,
    required CropImageUseCase cropImage,
    required ResizeImageUseCase resizeImage,
    required RotateImageUseCase rotateImage,
    required AdjustBrightnessUseCase adjustBrightness,
    required AdjustContrastUseCase adjustContrast,
    required SharpenImageUseCase sharpenImage,
    required ConvertImageFormatUseCase convertFormat,
    required RemoveBackgroundUseCase removeBackground,
    required CompressImageUseCase compressImage,
  })  : _repository = repository,
        _cropImage = cropImage,
        _resizeImage = resizeImage,
        _rotateImage = rotateImage,
        _adjustBrightness = adjustBrightness,
        _adjustContrast = adjustContrast,
        _sharpenImage = sharpenImage,
        _convertFormat = convertFormat,
        _removeBackground = removeBackground,
        _compressImage = compressImage,
        super(const ImageEditorState());

  void loadImage(String imagePath) {
    final newHistory = [imagePath];
    emit(state.copyWith(
      imagePath: imagePath,
      originalImagePath: imagePath,
      editedImagePath: imagePath,
      history: newHistory,
      historyIndex: 0,
      status: ImageEditorStatus.editing,
      error: null,
    ));
  }

  void selectTool(ImageEditorTool tool) {
    emit(state.copyWith(selectedTool: tool));
  }

  void setBrightness(double value) {
    emit(state.copyWith(brightnessValue: value));
  }

  void setContrast(double value) {
    emit(state.copyWith(contrastValue: value));
  }

  void setSharpenAmount(double amount) {
    emit(state.copyWith(sharpenAmount: amount));
  }

  void setRotateAngle(double angle) {
    emit(state.copyWith(rotateAngle: angle));
  }

  void setResizeDimensions(int width, int height) {
    emit(state.copyWith(resizeWidth: width, resizeHeight: height));
  }

  void setCompressQuality(int quality) {
    emit(state.copyWith(compressQuality: quality));
  }

  void setTargetFormat(ImageFormat format) {
    emit(state.copyWith(targetFormat: format));
  }

  Future<void> applyCrop(Rect cropRect) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _cropImage(CropImageParams(
      imagePath: state.imagePath!,
      cropRect: cropRect,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applyResize(int width, int height) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _resizeImage(ResizeImageParams(
      imagePath: state.imagePath!,
      width: width,
      height: height,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applyRotate(double angle) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _rotateImage(RotateImageParams(
      imagePath: state.imagePath!,
      angle: angle,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applyBrightness(double value) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _adjustBrightness(AdjustBrightnessParams(
      imagePath: state.imagePath!,
      value: value,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applyContrast(double value) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _adjustContrast(AdjustContrastParams(
      imagePath: state.imagePath!,
      value: value,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applySharpen(double amount) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _sharpenImage(SharpenImageParams(
      imagePath: state.imagePath!,
      amount: amount,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applyFormatConvert(ImageFormat format) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _convertFormat(ConvertImageFormatParams(
      imagePath: state.imagePath!,
      format: format,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applyRemoveBackground() async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _removeBackground(RemoveBackgroundParams(
      imagePath: state.imagePath!,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  Future<void> applyCompress(int quality) async {
    if (state.imagePath == null) return;
    emit(state.copyWith(isProcessing: true, status: ImageEditorStatus.processing));

    final result = await _compressImage(CompressImageParams(
      imagePath: state.imagePath!,
      quality: quality,
    ));

    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        status: ImageEditorStatus.error,
        error: failure.message,
      )),
      (newPath) => _addToHistory(newPath),
    );
  }

  void undo() {
    if (!state.canUndo) return;
    final newIndex = state.historyIndex - 1;
    emit(state.copyWith(
      historyIndex: newIndex,
      imagePath: state.history[newIndex],
      editedImagePath: state.history[newIndex],
    ));
  }

  void redo() {
    if (!state.canRedo) return;
    final newIndex = state.historyIndex + 1;
    emit(state.copyWith(
      historyIndex: newIndex,
      imagePath: state.history[newIndex],
      editedImagePath: state.history[newIndex],
    ));
  }

  void reset() {
    if (state.originalImagePath == null) return;
    final original = state.originalImagePath!;
    emit(state.copyWith(
      imagePath: original,
      editedImagePath: original,
      history: [original],
      historyIndex: 0,
      brightnessValue: 1.0,
      contrastValue: 1.0,
      sharpenAmount: 1.0,
      rotateAngle: 0.0,
      selectedTool: ImageEditorTool.none,
      status: ImageEditorStatus.editing,
      error: null,
    ));
  }

  void _addToHistory(String newPath) {
    // Truncate any redo history
    final newHistory = state.history.sublist(0, state.historyIndex + 1)..add(newPath);
    // Limit history to 20 items
    if (newHistory.length > 20) {
      newHistory.removeAt(0);
      emit(state.copyWith(
        history: newHistory,
        historyIndex: newHistory.length - 2,
        imagePath: newPath,
        editedImagePath: newPath,
        isProcessing: false,
        status: ImageEditorStatus.editing,
      ));
    } else {
      emit(state.copyWith(
        history: newHistory,
        historyIndex: newHistory.length - 1,
        imagePath: newPath,
        editedImagePath: newPath,
        isProcessing: false,
        status: ImageEditorStatus.editing,
      ));
    }
  }

  void clearError() {
    emit(state.copyWith(error: null));
  }
}
