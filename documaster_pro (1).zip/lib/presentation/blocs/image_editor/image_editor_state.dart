part of 'image_editor_cubit.dart';

enum ImageEditorTool {
  none,
  crop,
  resize,
  rotate,
  brightness,
  contrast,
  sharpen,
  formatConvert,
  removeBackground,
  compress,
}

enum ImageEditorStatus {
  initial,
  loading,
  editing,
  processing,
  success,
  error,
}

class ImageEditorState extends Equatable {
  final String? imagePath;
  final String? originalImagePath;
  final String? editedImagePath;
  final ImageEditorTool selectedTool;
  final ImageEditorStatus status;
  final List<String> history;
  final int historyIndex;
  final double brightnessValue;
  final double contrastValue;
  final double sharpenAmount;
  final double rotateAngle;
  final int resizeWidth;
  final int resizeHeight;
  final int compressQuality;
  final ImageFormat targetFormat;
  final bool isProcessing;
  final String? error;

  const ImageEditorState({
    this.imagePath,
    this.originalImagePath,
    this.editedImagePath,
    this.selectedTool = ImageEditorTool.none,
    this.status = ImageEditorStatus.initial,
    this.history = const [],
    this.historyIndex = -1,
    this.brightnessValue = 1.0,
    this.contrastValue = 1.0,
    this.sharpenAmount = 1.0,
    this.rotateAngle = 0.0,
    this.resizeWidth = 0,
    this.resizeHeight = 0,
    this.compressQuality = 85,
    this.targetFormat = ImageFormat.jpeg,
    this.isProcessing = false,
    this.error,
  });

  bool get canUndo => historyIndex > 0;
  bool get canRedo => historyIndex < history.length - 1;
  bool get hasImage => imagePath != null;
  bool get hasChanges => editedImagePath != null && editedImagePath != originalImagePath;

  ImageEditorState copyWith({
    String? imagePath,
    String? originalImagePath,
    String? editedImagePath,
    ImageEditorTool? selectedTool,
    ImageEditorStatus? status,
    List<String>? history,
    int? historyIndex,
    double? brightnessValue,
    double? contrastValue,
    double? sharpenAmount,
    double? rotateAngle,
    int? resizeWidth,
    int? resizeHeight,
    int? compressQuality,
    ImageFormat? targetFormat,
    bool? isProcessing,
    String? error,
  }) {
    return ImageEditorState(
      imagePath: imagePath ?? this.imagePath,
      originalImagePath: originalImagePath ?? this.originalImagePath,
      editedImagePath: editedImagePath ?? this.editedImagePath,
      selectedTool: selectedTool ?? this.selectedTool,
      status: status ?? this.status,
      history: history ?? this.history,
      historyIndex: historyIndex ?? this.historyIndex,
      brightnessValue: brightnessValue ?? this.brightnessValue,
      contrastValue: contrastValue ?? this.contrastValue,
      sharpenAmount: sharpenAmount ?? this.sharpenAmount,
      rotateAngle: rotateAngle ?? this.rotateAngle,
      resizeWidth: resizeWidth ?? this.resizeWidth,
      resizeHeight: resizeHeight ?? this.resizeHeight,
      compressQuality: compressQuality ?? this.compressQuality,
      targetFormat: targetFormat ?? this.targetFormat,
      isProcessing: isProcessing ?? this.isProcessing,
      error: error,
    );
  }

  @override
  List<Object?> get props => [
    imagePath,
    originalImagePath,
    editedImagePath,
    selectedTool,
    status,
    history,
    historyIndex,
    brightnessValue,
    contrastValue,
    sharpenAmount,
    rotateAngle,
    resizeWidth,
    resizeHeight,
    compressQuality,
    targetFormat,
    isProcessing,
    error,
  ];
}
