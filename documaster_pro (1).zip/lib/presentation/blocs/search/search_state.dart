part of 'search_cubit.dart';

enum SearchFilter { all, files, pdf, ocr, tags }

class SearchState extends Equatable {
  final List<SearchResult> results;
  final List<String> recentSearches;
  final String? currentQuery;
  final SearchFilter filter;
  final bool isLoading;
  final bool hasSearched;
  final String? error;

  const SearchState({
    this.results = const [],
    this.recentSearches = const [],
    this.currentQuery,
    this.filter = SearchFilter.all,
    this.isLoading = false,
    this.hasSearched = false,
    this.error,
  });

  SearchState copyWith({
    List<SearchResult>? results,
    List<String>? recentSearches,
    String? currentQuery,
    SearchFilter? filter,
    bool? isLoading,
    bool? hasSearched,
    String? error,
    bool clearError = false,
  }) {
    return SearchState(
      results: results ?? this.results,
      recentSearches: recentSearches ?? this.recentSearches,
      currentQuery: currentQuery ?? this.currentQuery,
      filter: filter ?? this.filter,
      isLoading: isLoading ?? this.isLoading,
      hasSearched: hasSearched ?? this.hasSearched,
      error: clearError ? null : (error ?? this.error),
    );
  }

  @override
  List<Object?> get props => [
        results,
        recentSearches,
        currentQuery,
        filter,
        isLoading,
        hasSearched,
        error,
      ];
}
