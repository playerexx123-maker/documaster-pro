import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/entities/search_result.dart';
import '../../../domain/usecases/search/global_search.dart';
import '../../../domain/usecases/search/search_by_file_name.dart';
import '../../../domain/usecases/search/search_pdf_contents.dart';
import '../../../domain/usecases/search/search_ocr_text.dart';
import '../../../domain/usecases/search/search_by_tags.dart';
import '../../../domain/usecases/search/get_recent_searches.dart';
import '../../../domain/usecases/search/add_recent_search.dart';
import '../../../domain/usecases/search/rebuild_search_index.dart';
import '../../../core/usecases/usecase.dart';

part 'search_state.dart';

class SearchCubit extends Cubit<SearchState> {
  final GlobalSearch _globalSearch;
  final SearchByFileName _searchByFileName;
  final SearchPdfContents _searchPdfContents;
  final SearchOcrText _searchOcrText;
  final SearchByTags _searchByTags;
  final GetRecentSearches _getRecentSearches;
  final AddRecentSearch _addRecentSearch;
  final RebuildSearchIndex _rebuildSearchIndex;

  SearchCubit({
    required GlobalSearch globalSearch,
    required SearchByFileName searchByFileName,
    required SearchPdfContents searchPdfContents,
    required SearchOcrText searchOcrText,
    required SearchByTags searchByTags,
    required GetRecentSearches getRecentSearches,
    required AddRecentSearch addRecentSearch,
    required RebuildSearchIndex rebuildSearchIndex,
  })  : _globalSearch = globalSearch,
        _searchByFileName = searchByFileName,
        _searchPdfContents = searchPdfContents,
        _searchOcrText = searchOcrText,
        _searchByTags = searchByTags,
        _getRecentSearches = getRecentSearches,
        _addRecentSearch = addRecentSearch,
        _rebuildSearchIndex = rebuildSearchIndex,
        super(const SearchState());

  Future<void> loadRecentSearches() async {
    final result = await _getRecentSearches(const NoParams());
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (searches) => emit(state.copyWith(recentSearches: searches, clearError: true)),
    );
  }

  Future<void> search(String query, {SearchFilter? filter}) async {
    if (query.trim().isEmpty) {
      emit(state.copyWith(
        results: const [],
        currentQuery: null,
        hasSearched: false,
        filter: filter ?? state.filter,
        clearError: true,
      ));
      return;
    }

    emit(state.copyWith(
      isLoading: true,
      currentQuery: query,
      filter: filter ?? state.filter,
      hasSearched: true,
      clearError: true,
    ));

    // Save to recent searches
    await _addRecentSearch(AddRecentSearchParams(query));

    final searchFilter = filter ?? state.filter;
    switch (searchFilter) {
      case SearchFilter.all:
        final result = await _globalSearch(GlobalSearchParams(query));
        result.fold(
          (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
          (results) => emit(state.copyWith(
            isLoading: false,
            results: results,
            clearError: true,
          )),
        );
        break;
      case SearchFilter.files:
        final result = await _searchByFileName(SearchByFileNameParams(query));
        result.fold(
          (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
          (results) => emit(state.copyWith(
            isLoading: false,
            results: results,
            clearError: true,
          )),
        );
        break;
      case SearchFilter.pdf:
        final result = await _searchPdfContents(SearchPdfContentsParams(query));
        result.fold(
          (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
          (results) => emit(state.copyWith(
            isLoading: false,
            results: results,
            clearError: true,
          )),
        );
        break;
      case SearchFilter.ocr:
        final result = await _searchOcrText(SearchOcrTextParams(query));
        result.fold(
          (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
          (results) => emit(state.copyWith(
            isLoading: false,
            results: results,
            clearError: true,
          )),
        );
        break;
      case SearchFilter.tags:
        final result = await _searchByTags(SearchByTagsParams(query));
        result.fold(
          (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
          (results) => emit(state.copyWith(
            isLoading: false,
            results: results,
            clearError: true,
          )),
        );
        break;
    }

    // Refresh recent searches after adding
    await loadRecentSearches();
  }

  Future<void> searchWithFilter(SearchFilter filter) async {
    if (state.currentQuery != null && state.currentQuery!.isNotEmpty) {
      await search(state.currentQuery!, filter: filter);
    } else {
      emit(state.copyWith(filter: filter));
    }
  }

  Future<void> clearSearch() async {
    emit(state.copyWith(
      results: const [],
      currentQuery: null,
      hasSearched: false,
      clearError: true,
    ));
  }

  Future<void> removeRecentSearch(String query) async {
    // Note: This would need a dedicated use case; for now we just reload
    await loadRecentSearches();
  }

  Future<void> rebuildIndex() async {
    emit(state.copyWith(isLoading: true, clearError: true));
    final result = await _rebuildSearchIndex(const NoParams());
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (_) => emit(state.copyWith(isLoading: false, clearError: true)),
    );
  }

  void setFilter(SearchFilter filter) {
    emit(state.copyWith(filter: filter));
  }

  void clearError() {
    emit(state.copyWith(clearError: true));
  }
}
