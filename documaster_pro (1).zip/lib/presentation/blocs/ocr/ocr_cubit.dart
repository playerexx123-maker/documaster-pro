import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../core/usecases/usecase.dart';
import '../../../domain/entities/ocr_result.dart';
import '../../../domain/usecases/ocr/recognize_text.dart';
import '../../../domain/usecases/ocr/recognize_document_text.dart';
import '../../../domain/usecases/ocr/get_document_text.dart';
import '../../../domain/usecases/ocr/export_ocr_text.dart';
import '../../../domain/usecases/ocr/get_supported_languages.dart';

part 'ocr_state.dart';

class OcrCubit extends Cubit<OcrState> {
  final RecognizeText _recognizeText;
  final RecognizeDocumentText _recognizeDocumentText;
  final GetDocumentText _getDocumentText;
  final ExportOcrText _exportOcrText;
  final GetSupportedLanguages _getSupportedLanguages;

  OcrCubit({
    required RecognizeText recognizeText,
    required RecognizeDocumentText recognizeDocumentText,
    required GetDocumentText getDocumentText,
    required ExportOcrText exportOcrText,
    required GetSupportedLanguages getSupportedLanguages,
  })  : _recognizeText = recognizeText,
        _recognizeDocumentText = recognizeDocumentText,
        _getDocumentText = getDocumentText,
        _exportOcrText = exportOcrText,
        _getSupportedLanguages = getSupportedLanguages,
        super(const OcrState());

  Future<void> recognizeImage(String imagePath, {String language = 'en'}) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _recognizeText(RecognizeTextParams(
      imagePath: imagePath,
      language: language,
    ));
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (ocrResult) => emit(state.copyWith(
        isProcessing: false,
        currentResult: ocrResult,
        results: [ocrResult],
      )),
    );
  }

  Future<void> recognizeDocument(int documentId, {String language = 'en'}) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _recognizeDocumentText(RecognizeDocumentTextParams(
      documentId: documentId,
      language: language,
    ));
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (ocrResults) => emit(state.copyWith(
        isProcessing: false,
        results: ocrResults,
        currentResult: ocrResults.isNotEmpty ? ocrResults.first : null,
      )),
    );
  }

  Future<void> getRecognizedText(int documentId) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _getDocumentText(GetDocumentTextParams(documentId: documentId));
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (text) => emit(state.copyWith(
        isProcessing: false,
        fullText: text,
      )),
    );
  }

  Future<void> exportText(int documentId, ExportFormat format) async {
    emit(state.copyWith(isProcessing: true, error: null, exportPath: null));
    final result = await _exportOcrText(ExportOcrTextParams(
      documentId: documentId,
      format: format,
    ));
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (filePath) => emit(state.copyWith(
        isProcessing: false,
        exportPath: filePath,
      )),
    );
  }

  Future<void> loadSupportedLanguages() async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _getSupportedLanguages(const NoParams());
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (languages) => emit(state.copyWith(
        isProcessing: false,
        supportedLanguages: languages,
      )),
    );
  }

  void setLanguage(String language) {
    emit(state.copyWith(selectedLanguage: language));
  }

  void clearResults() {
    emit(state.copyWith(
      results: [],
      currentResult: null,
      fullText: null,
      exportPath: null,
      error: null,
    ));
  }

  void clearError() {
    emit(state.copyWith(error: null));
  }
}
