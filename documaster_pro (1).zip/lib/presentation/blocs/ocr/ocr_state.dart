part of 'ocr_cubit.dart';

class OcrState extends Equatable {
  final List<OcrResult> results;
  final OcrResult? currentResult;
  final String? fullText;
  final String? exportPath;
  final String selectedLanguage;
  final List<LanguageInfo> supportedLanguages;
  final bool isProcessing;
  final String? error;

  const OcrState({
    this.results = const [],
    this.currentResult,
    this.fullText,
    this.exportPath,
    this.selectedLanguage = 'en',
    this.supportedLanguages = const [],
    this.isProcessing = false,
    this.error,
  });

  OcrState copyWith({
    List<OcrResult>? results,
    OcrResult? currentResult,
    String? fullText,
    String? exportPath,
    String? selectedLanguage,
    List<LanguageInfo>? supportedLanguages,
    bool? isProcessing,
    String? error,
  }) {
    return OcrState(
      results: results ?? this.results,
      currentResult: currentResult ?? this.currentResult,
      fullText: fullText ?? this.fullText,
      exportPath: exportPath ?? this.exportPath,
      selectedLanguage: selectedLanguage ?? this.selectedLanguage,
      supportedLanguages: supportedLanguages ?? this.supportedLanguages,
      isProcessing: isProcessing ?? this.isProcessing,
      error: error,
    );
  }

  @override
  List<Object?> get props => [
    results,
    currentResult,
    fullText,
    exportPath,
    selectedLanguage,
    supportedLanguages,
    isProcessing,
    error,
  ];
}
