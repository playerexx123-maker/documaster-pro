part of 'editor_cubit.dart';

enum EditorTool { highlight, underline, strikeout, pen, eraser, text, comment, signature }

class EditorState extends Equatable {
  final String? documentPath;
  final int? documentId;
  final int currentPage;
  final int totalPages;
  final Map<int, Uint8List> pageThumbnails;
  final List<PdfAnnotation> annotations;
  final EditorTool? selectedTool;
  final Color selectedColor;
  final double strokeWidth;
  final String? textContent;
  final List<Point<double>> drawingPoints;
  final bool isLoading;
  final bool isProcessing;
  final String? error;
  final String? lastOperationResult;
  final bool showAnnotationPanel;
  final bool showToolsPanel;
  final bool showPageManager;

  const EditorState({
    this.documentPath,
    this.documentId,
    this.currentPage = 1,
    this.totalPages = 0,
    this.pageThumbnails = const {},
    this.annotations = const [],
    this.selectedTool,
    this.selectedColor = Colors.yellow,
    this.strokeWidth = 2.0,
    this.textContent,
    this.drawingPoints = const [],
    this.isLoading = false,
    this.isProcessing = false,
    this.error,
    this.lastOperationResult,
    this.showAnnotationPanel = false,
    this.showToolsPanel = false,
    this.showPageManager = false,
  });

  EditorState copyWith({
    String? documentPath,
    int? documentId,
    int? currentPage,
    int? totalPages,
    Map<int, Uint8List>? pageThumbnails,
    List<PdfAnnotation>? annotations,
    EditorTool? selectedTool,
    Color? selectedColor,
    double? strokeWidth,
    String? textContent,
    List<Point<double>>? drawingPoints,
    bool? isLoading,
    bool? isProcessing,
    String? error,
    String? lastOperationResult,
    bool? showAnnotationPanel,
    bool? showToolsPanel,
    bool? showPageManager,
  }) {
    return EditorState(
      documentPath: documentPath ?? this.documentPath,
      documentId: documentId ?? this.documentId,
      currentPage: currentPage ?? this.currentPage,
      totalPages: totalPages ?? this.totalPages,
      pageThumbnails: pageThumbnails ?? this.pageThumbnails,
      annotations: annotations ?? this.annotations,
      selectedTool: selectedTool == null ? this.selectedTool : selectedTool,
      selectedColor: selectedColor ?? this.selectedColor,
      strokeWidth: strokeWidth ?? this.strokeWidth,
      textContent: textContent ?? this.textContent,
      drawingPoints: drawingPoints ?? this.drawingPoints,
      isLoading: isLoading ?? this.isLoading,
      isProcessing: isProcessing ?? this.isProcessing,
      error: error,
      lastOperationResult: lastOperationResult,
      showAnnotationPanel: showAnnotationPanel ?? this.showAnnotationPanel,
      showToolsPanel: showToolsPanel ?? this.showToolsPanel,
      showPageManager: showPageManager ?? this.showPageManager,
    );
  }

  @override
  List<Object?> get props => [
    documentPath,
    documentId,
    currentPage,
    totalPages,
    pageThumbnails,
    annotations,
    selectedTool,
    selectedColor,
    strokeWidth,
    textContent,
    drawingPoints,
    isLoading,
    isProcessing,
    error,
    lastOperationResult,
    showAnnotationPanel,
    showToolsPanel,
    showPageManager,
  ];
}
