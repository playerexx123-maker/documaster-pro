import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/entities/pdf_annotation.dart';
import '../../../domain/repositories/pdf_editor_repository.dart';

part 'editor_state.dart';

class EditorCubit extends Cubit<EditorState> {
  final PdfEditorRepository _pdfEditorRepository;

  EditorCubit(this._pdfEditorRepository) : super(const EditorState());

  // ─── Document Loading ───

  Future<void> loadDocument(String path, {int? documentId}) async {
    emit(state.copyWith(isLoading: true, error: null));
    final countResult = await _pdfEditorRepository.getPageCount(path);
    countResult.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (count) async {
        List<PdfAnnotation> annotations = [];
        if (documentId != null && documentId > 0) {
          final annotationsResult = await _pdfEditorRepository.getAnnotations(documentId);
          annotationsResult.fold((l) {}, (a) => annotations = a);
        }

        emit(state.copyWith(
          isLoading: false,
          documentPath: path,
          documentId: documentId,
          totalPages: count,
          annotations: annotations,
          currentPage: 1,
        ));
      },
    );
  }

  void reloadDocument() {
    if (state.documentPath != null) {
      loadDocument(state.documentPath!, documentId: state.documentId);
    }
  }

  // ─── Page Navigation ───

  void goToPage(int page) {
    if (page >= 1 && page <= state.totalPages) {
      emit(state.copyWith(currentPage: page));
    }
  }

  void nextPage() {
    if (state.currentPage < state.totalPages) {
      emit(state.copyWith(currentPage: state.currentPage + 1));
    }
  }

  void previousPage() {
    if (state.currentPage > 1) {
      emit(state.copyWith(currentPage: state.currentPage - 1));
    }
  }

  // ─── Page Rendering ───

  Future<void> renderPage(int pageNumber, {int width = 800}) async {
    if (state.documentPath == null) return;
    final result = await _pdfEditorRepository.renderPage(
      state.documentPath!,
      pageNumber,
      width: width,
    );
    result.fold(
      (failure) {},
      (bytes) {
        final thumbnails = Map<int, Uint8List>.from(state.pageThumbnails);
        thumbnails[pageNumber] = bytes;
        emit(state.copyWith(pageThumbnails: thumbnails));
      },
    );
  }

  Future<void> renderThumbnail(int pageNumber) async {
    await renderPage(pageNumber, width: 200);
  }

  Future<void> renderAllThumbnails() async {
    for (int i = 1; i <= state.totalPages; i++) {
      await renderThumbnail(i);
    }
  }

  // ─── Annotation Management ───

  Future<void> loadAnnotations(int documentId) async {
    final result = await _pdfEditorRepository.getAnnotations(documentId);
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (annotations) => emit(state.copyWith(
        annotations: annotations,
        documentId: documentId,
      )),
    );
  }

  Future<void> addAnnotation(PdfAnnotation annotation) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.addAnnotation(annotation);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (newAnnotation) {
        final updated = List<PdfAnnotation>.from(state.annotations)..add(newAnnotation);
        emit(state.copyWith(annotations: updated, isProcessing: false));
      },
    );
  }

  Future<void> removeAnnotation(int id) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.removeAnnotation(id);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (_) {
        final updated = state.annotations.where((a) => a.id != id).toList();
        emit(state.copyWith(annotations: updated, isProcessing: false));
      },
    );
  }

  Future<void> annotatePdf() async {
    if (state.documentPath == null || state.annotations.isEmpty) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.annotatePdf(
      state.documentPath!,
      state.annotations,
    );
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'Annotations saved to PDF',
        ));
      },
    );
  }

  void updateDrawingPoints(List<Point<double>> points) {
    emit(state.copyWith(drawingPoints: points));
  }

  void addDrawingPoint(Point<double> point) {
    final updated = List<Point<double>>.from(state.drawingPoints)..add(point);
    emit(state.copyWith(drawingPoints: updated));
  }

  void clearDrawingPoints() {
    emit(state.copyWith(drawingPoints: const []));
  }

  // ─── Tool Selection ───

  void selectTool(EditorTool? tool) {
    emit(state.copyWith(selectedTool: tool));
  }

  void setSelectedColor(Color color) {
    emit(state.copyWith(selectedColor: color));
  }

  void setStrokeWidth(double width) {
    emit(state.copyWith(strokeWidth: width));
  }

  void setTextContent(String text) {
    emit(state.copyWith(textContent: text));
  }

  // ─── PDF Operations ───

  Future<void> mergePdfs(List<String> paths) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.mergePdfs(paths);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) => emit(state.copyWith(
        isProcessing: false,
        documentPath: outputPath,
        lastOperationResult: 'PDFs merged successfully',
      )),
    );
  }

  Future<void> splitPdf(String path, List<Map<String, int>> ranges) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final countResult = await _pdfEditorRepository.getPageCount(path);
    countResult.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (totalPages) async {
        final results = <String>[];
        for (final range in ranges) {
          final start = range['start'] ?? 1;
          final end = range['end'] ?? totalPages;
          final pagesToKeep = List<int>.generate(
            (end - start + 1).clamp(1, totalPages),
            (i) => start + i,
          );
          final pagesToDelete = <int>[];
          for (int p = 1; p <= totalPages; p++) {
            if (!pagesToKeep.contains(p)) pagesToDelete.add(p);
          }
          if (pagesToDelete.isNotEmpty) {
            final result = await _pdfEditorRepository.deletePages(path, pagesToDelete);
            result.fold((l) {}, (r) => results.add(r));
          }
        }
        emit(state.copyWith(
          isProcessing: false,
          lastOperationResult: 'PDF split into ${results.length} parts',
        ));
      },
    );
  }

  Future<void> reorderPages(String path, List<int> newOrder) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.reorderPages(path, newOrder);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) => emit(state.copyWith(
        isProcessing: false,
        documentPath: outputPath,
        lastOperationResult: 'Pages reordered successfully',
      )),
    );
  }

  Future<void> rotatePage(int pageNumber, Rotation rotation) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.rotatePage(
      state.documentPath!,
      pageNumber,
      rotation,
    );
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'Page rotated successfully',
        ));
      },
    );
  }

  Future<void> deletePages(List<int> pageNumbers) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.deletePages(state.documentPath!, pageNumbers);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: '${pageNumbers.length} page(s) deleted',
        ));
      },
    );
  }

  Future<void> duplicatePage(int pageNumber) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.duplicatePage(state.documentPath!, pageNumber);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'Page duplicated successfully',
        ));
      },
    );
  }

  Future<void> compressPdf(CompressionLevel level) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.compressPdf(state.documentPath!, level);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'PDF compressed successfully',
        ));
      },
    );
  }

  Future<void> encryptPdf(String password) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.encryptPdf(state.documentPath!, password);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'PDF encrypted successfully',
        ));
      },
    );
  }

  Future<void> decryptPdf(String password) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.decryptPdf(state.documentPath!, password);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'PDF decrypted successfully',
        ));
      },
    );
  }

  Future<void> addWatermark(WatermarkOptions options) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.addWatermark(state.documentPath!, options);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'Watermark added successfully',
        ));
      },
    );
  }

  Future<void> addPageNumbers(PageNumberOptions options) async {
    if (state.documentPath == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _pdfEditorRepository.addPageNumbers(state.documentPath!, options);
    result.fold(
      (failure) => emit(state.copyWith(isProcessing: false, error: failure.message)),
      (outputPath) {
        emit(state.copyWith(
          isProcessing: false,
          documentPath: outputPath,
          lastOperationResult: 'Page numbers added successfully',
        ));
      },
    );
  }

  // ─── Utility ───

  void clearError() {
    emit(state.copyWith(error: null));
  }

  void clearLastOperationResult() {
    emit(state.copyWith(lastOperationResult: null));
  }

  void setShowAnnotationPanel(bool show) {
    emit(state.copyWith(showAnnotationPanel: show));
  }

  void setShowToolsPanel(bool show) {
    emit(state.copyWith(showToolsPanel: show));
  }

  void setShowPageManager(bool show) {
    emit(state.copyWith(showPageManager: show));
  }
}
