import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/entities/app_settings.dart';

part 'settings_state.dart';

class SettingsCubit extends Cubit<SettingsState> {
  SettingsCubit() : super(SettingsState(settings: AppSettings()));

  /// Loads settings from persistent storage.
  /// This should be called during app initialization.
  Future<void> loadSettings() async {
    emit(state.copyWith(isLoading: true, error: null));
    try {
      // In a production app, this would read from shared_preferences
      // and SQLite app_settings table. For now, we use defaults.
      await Future.delayed(const Duration(milliseconds: 200));
      emit(state.copyWith(isLoading: false));
    } catch (e) {
      emit(state.copyWith(
        isLoading: false,
        error: 'Failed to load settings: $e',
      ));
    }
  }

  /// Updates the theme mode (light, dark, or system).
  void updateThemeMode(ThemeMode mode) {
    emit(state.copyWith(
      settings: state.settings.copyWith(themeMode: mode),
    ));
  }

  /// Toggles biometric authentication enablement.
  void updateBiometricEnabled(bool enabled) {
    emit(state.copyWith(
      settings: state.settings.copyWith(biometricEnabled: enabled),
    ));
  }

  /// Toggles PIN protection enablement.
  void updatePinEnabled(bool enabled) {
    emit(state.copyWith(
      settings: state.settings.copyWith(pinEnabled: enabled),
    ));
  }

  /// Updates the OCR language preference.
  void updateOcrLanguage(String language) {
    emit(state.copyWith(
      settings: state.settings.copyWith(defaultOcrLanguage: language),
    ));
  }

  /// Toggles auto-enhance for scans.
  void updateAutoEnhance(bool enabled) {
    emit(state.copyWith(
      settings: state.settings.copyWith(autoEnhanceScans: enabled),
    ));
  }

  /// Toggles cloud sync enablement.
  void updateCloudSync(bool enabled) {
    emit(state.copyWith(
      settings: state.settings.copyWith(cloudSyncEnabled: enabled),
    ));
  }

  /// Updates the default cloud provider.
  void updateCloudProvider(String? provider) {
    emit(state.copyWith(
      settings: state.settings.copyWith(defaultCloudProvider: provider),
    ));
  }

  /// Updates the default save location.
  void updateSaveLocation(String location) {
    emit(state.copyWith(
      settings: state.settings.copyWith(defaultSaveLocation: location),
    ));
  }

  /// Updates the default PDF quality.
  void updatePdfQuality(String quality) {
    emit(state.copyWith(
      settings: state.settings.copyWith(defaultPdfQuality: quality),
    ));
  }

  /// Toggles keeping original scans.
  void updateKeepOriginalScans(bool keep) {
    emit(state.copyWith(
      settings: state.settings.copyWith(keepOriginalScans: keep),
    ));
  }

  /// Resets all settings to their default values.
  void resetToDefaults() {
    emit(state.copyWith(settings: const AppSettings()));
  }

  /// Clears any error message.
  void clearError() {
    emit(state.copyWith(error: null));
  }

  /// Validates PIN length according to app rules.
  bool isValidPinLength(String pin) {
    return pin.length >= 4 && pin.length <= 6;
  }

  /// Checks if PIN contains only digits.
  bool isValidPinFormat(String pin) {
    return RegExp(r'^\d+$').hasMatch(pin);
  }
}
