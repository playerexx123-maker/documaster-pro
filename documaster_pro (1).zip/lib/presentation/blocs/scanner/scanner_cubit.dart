import 'package:camera/camera.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/entities/scan_page.dart';
import '../../../domain/entities/document.dart';
import '../../../domain/repositories/scanner_repository.dart';

part 'scanner_state.dart';

class ScannerCubit extends Cubit<ScannerState> {
  final ScannerRepository _scannerRepository;
  List<CameraDescription> _cameras = [];
  CameraController? _cameraController;

  ScannerCubit(this._scannerRepository) : super(const ScannerState());

  List<CameraDescription> get cameras => _cameras;
  CameraController? get cameraController => _cameraController;

  Future<void> initializeCameras() async {
    try {
      _cameras = await availableCameras();
      if (_cameras.isNotEmpty) {
        await _initializeController(_cameras[0]);
      }
      emit(state.copyWith(
        isCameraInitialized: _cameraController?.value.isInitialized ?? false,
      ));
    } catch (e) {
      emit(state.copyWith(error: 'Failed to initialize camera: $e'));
    }
  }

  Future<void> _initializeController(CameraDescription camera) async {
    _cameraController?.dispose();
    _cameraController = CameraController(
      camera,
      ResolutionPreset.ultraHigh,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );
    await _cameraController!.initialize();
    await _cameraController!.setFlashMode(state.flashMode);
  }

  Future<void> switchCamera() async {
    if (_cameras.length < 2) return;
    final currentIndex = _cameras.indexWhere(
      (c) => c.lensDirection == _cameraController?.description.lensDirection,
    );
    final nextIndex = (currentIndex + 1) % _cameras.length;
    await _initializeController(_cameras[nextIndex]);
    emit(state.copyWith(
      isCameraInitialized: _cameraController!.value.isInitialized,
    ));
  }

  void toggleFlash() {
    final newMode = state.flashMode == FlashMode.off ? FlashMode.auto : FlashMode.off;
    emit(state.copyWith(flashMode: newMode));
    _cameraController?.setFlashMode(newMode);
  }

  void setFlashMode(FlashMode mode) {
    emit(state.copyWith(flashMode: mode));
    _cameraController?.setFlashMode(mode);
  }

  void setFilter(ScanFilter filter) {
    emit(state.copyWith(currentFilter: filter));
  }

  void setCurrentPage(int index) {
    emit(state.copyWith(currentPageIndex: index));
  }

  void setMultiPageMode(bool isMultiPage) {
    emit(state.copyWith(isMultiPageMode: isMultiPage));
  }

  void setShowPreview(bool show) {
    emit(state.copyWith(showPreview: show));
  }

  Future<void> startSession(String name) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _scannerRepository.startSession(name);
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (session) => emit(state.copyWith(
        isProcessing: false,
        session: session,
        pages: session.pages,
      )),
    );
  }

  Future<void> addPage(String imagePath) async {
    if (state.session == null) return;
    emit(state.copyWith(isProcessing: true, error: null));

    // First process the image with the current filter
    final processResult = await _scannerRepository.processPage(
      imagePath,
      state.currentFilter,
    );

    String processedPath = imagePath;
    processResult.fold(
      (failure) {
        // Use original image if processing fails
        processedPath = imagePath;
      },
      (path) {
        processedPath = path;
      },
    );

    // Add page to session with processed path
    final result = await _scannerRepository.addPage(
      state.session!.id!,
      processedPath,
    );
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (_) async {
        final pagesResult = await _scannerRepository.getSessionPages(
          state.session!.id!,
        );
        pagesResult.fold(
          (failure) => emit(state.copyWith(isProcessing: false)),
          (pages) => emit(state.copyWith(
            isProcessing: false,
            pages: pages,
            showPreview: true,
          )),
        );
      },
    );
  }

  Future<void> applyCurrentFilter(String imagePath) async {
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _scannerRepository.applyFilter(
      imagePath,
      state.currentFilter,
    );
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (processedPath) => emit(state.copyWith(
        isProcessing: false,
        lastProcessedPath: processedPath,
      )),
    );
  }

  Future<void> finalizeSession({String? name, SaveFormat format = SaveFormat.pdf}) async {
    if (state.session == null) return;
    emit(state.copyWith(isProcessing: true, error: null));
    final result = await _scannerRepository.finalizeSession(
      state.session!.id!,
      name: name,
      format: format,
    );
    result.fold(
      (failure) => emit(state.copyWith(
        isProcessing: false,
        error: failure.message,
      )),
      (document) => emit(state.copyWith(
        isProcessing: false,
        finalizedDocument: document,
      )),
    );
  }

  Future<void> cancelSession() async {
    if (state.session == null) return;
    await _scannerRepository.cancelSession(state.session!.id!);
    _cameraController?.dispose();
    emit(const ScannerState());
  }

  void removePage(int index) {
    final updatedPages = List<ScanPage>.from(state.pages)..removeAt(index);
    final newIndex = state.currentPageIndex >= updatedPages.length
        ? updatedPages.length - 1
        : state.currentPageIndex;
    emit(state.copyWith(pages: updatedPages, currentPageIndex: newIndex));
  }

  void reorderPages(int oldIndex, int newIndex) {
    final updatedPages = List<ScanPage>.from(state.pages);
    final page = updatedPages.removeAt(oldIndex);
    updatedPages.insert(newIndex > oldIndex ? newIndex - 1 : newIndex, page);
    emit(state.copyWith(pages: updatedPages));
  }

  void clearError() {
    emit(state.copyWith(error: null));
  }

  void reset() {
    _cameraController?.dispose();
    _cameraController = null;
    emit(const ScannerState());
  }

  @override
  Future<void> close() {
    _cameraController?.dispose();
    return super.close();
  }
}
