part of 'scanner_cubit.dart';

class ScannerState extends Equatable {
  final ScanSession? session;
  final List<ScanPage> pages;
  final ScanFilter currentFilter;
  final bool isProcessing;
  final int currentPageIndex;
  final Document? finalizedDocument;
  final FlashMode flashMode;
  final bool isCameraInitialized;
  final bool isMultiPageMode;
  final bool showPreview;
  final String? lastProcessedPath;
  final String? error;

  const ScannerState({
    this.session,
    this.pages = const [],
    this.currentFilter = ScanFilter.color,
    this.isProcessing = false,
    this.currentPageIndex = 0,
    this.finalizedDocument,
    this.flashMode = FlashMode.off,
    this.isCameraInitialized = false,
    this.isMultiPageMode = true,
    this.showPreview = false,
    this.lastProcessedPath,
    this.error,
  });

  ScannerState copyWith({
    ScanSession? session,
    List<ScanPage>? pages,
    ScanFilter? currentFilter,
    bool? isProcessing,
    int? currentPageIndex,
    Document? finalizedDocument,
    FlashMode? flashMode,
    bool? isCameraInitialized,
    bool? isMultiPageMode,
    bool? showPreview,
    String? lastProcessedPath,
    String? error,
  }) {
    return ScannerState(
      session: session ?? this.session,
      pages: pages ?? this.pages,
      currentFilter: currentFilter ?? this.currentFilter,
      isProcessing: isProcessing ?? this.isProcessing,
      currentPageIndex: currentPageIndex ?? this.currentPageIndex,
      finalizedDocument: finalizedDocument ?? this.finalizedDocument,
      flashMode: flashMode ?? this.flashMode,
      isCameraInitialized: isCameraInitialized ?? this.isCameraInitialized,
      isMultiPageMode: isMultiPageMode ?? this.isMultiPageMode,
      showPreview: showPreview ?? this.showPreview,
      lastProcessedPath: lastProcessedPath ?? this.lastProcessedPath,
      error: error,
    );
  }

  @override
  List<Object?> get props => [
    session,
    pages,
    currentFilter,
    isProcessing,
    currentPageIndex,
    finalizedDocument,
    flashMode,
    isCameraInitialized,
    isMultiPageMode,
    showPreview,
    lastProcessedPath,
    error,
  ];
}
