part of 'files_cubit.dart';

enum ViewMode { list, grid }

class FilesState extends Equatable {
  final List<Folder> folders;
  final List<Document> documents;
  final List<Folder> currentPath;
  final int? currentFolderId;
  final ViewMode viewMode;
  final SortOption sortOption;
  final bool isLoading;
  final String? error;
  final int storageUsage;
  final bool isSearching;

  const FilesState({
    this.folders = const [],
    this.documents = const [],
    this.currentPath = const [],
    this.currentFolderId,
    this.viewMode = ViewMode.list,
    this.sortOption = SortOption.name,
    this.isLoading = false,
    this.error,
    this.storageUsage = 0,
    this.isSearching = false,
  });

  FilesState copyWith({
    List<Folder>? folders,
    List<Document>? documents,
    List<Folder>? currentPath,
    int? currentFolderId,
    ViewMode? viewMode,
    SortOption? sortOption,
    bool? isLoading,
    String? error,
    int? storageUsage,
    bool? isSearching,
    bool clearError = false,
  }) {
    return FilesState(
      folders: folders ?? this.folders,
      documents: documents ?? this.documents,
      currentPath: currentPath ?? this.currentPath,
      currentFolderId: currentFolderId ?? this.currentFolderId,
      viewMode: viewMode ?? this.viewMode,
      sortOption: sortOption ?? this.sortOption,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : (error ?? this.error),
      storageUsage: storageUsage ?? this.storageUsage,
      isSearching: isSearching ?? this.isSearching,
    );
  }

  @override
  List<Object?> get props => [
        folders, documents, currentPath, currentFolderId,
        viewMode, sortOption, isLoading, error,
        storageUsage, isSearching,
      ];
}
