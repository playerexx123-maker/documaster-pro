import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/entities/folder.dart';
import '../../../domain/entities/document.dart';
import '../../../domain/repositories/folder_repository.dart';
import '../../../domain/repositories/file_manager_repository.dart';
import '../../../domain/repositories/document_repository.dart';

part 'files_state.dart';

class FilesCubit extends Cubit<FilesState> {
  final FolderRepository _folderRepository;
  final FileManagerRepository _fileManagerRepository;
  final DocumentRepository _documentRepository;

  FilesCubit(
    this._folderRepository,
    this._fileManagerRepository,
    this._documentRepository,
  ) : super(const FilesState());

  Future<void> loadFiles({int? folderId}) async {
    emit(state.copyWith(isLoading: true, error: null, clearError: true));

    List<Folder> folders = [];
    List<Document> documents = [];
    List<Folder> path = [];

    if (folderId != null) {
      final folderResult = await _folderRepository.getSubFolders(folderId);
      final docResult = await _documentRepository.getDocumentsInFolder(folderId);
      final pathResult = await _folderRepository.getFolderPath(folderId);

      folderResult.fold(
        (failure) {
          emit(state.copyWith(isLoading: false, error: failure.message));
          return;
        },
        (f) => folders = f,
      );
      docResult.fold((l) {}, (d) => documents = d);
      pathResult.fold((l) {}, (p) => path = p);
    } else {
      final folderResult = await _folderRepository.getRootFolders();
      final docResult = await _documentRepository.getAllDocuments();
      folderResult.fold(
        (failure) {
          emit(state.copyWith(isLoading: false, error: failure.message));
          return;
        },
        (f) => folders = f,
      );
      docResult.fold((l) {}, (d) => documents = d);
    }

    // Apply sorting
    documents = _sortDocuments(documents);
    folders = _sortFolders(folders);

    emit(state.copyWith(
      isLoading: false,
      folders: folders,
      documents: documents,
      currentPath: path,
      currentFolderId: folderId,
      clearError: true,
    ));
  }

  Future<void> createFolder(String name) async {
    emit(state.copyWith(isLoading: true, clearError: true));
    final folder = Folder(
      name: name,
      parentId: state.currentFolderId,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    final result = await _folderRepository.createFolder(folder);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (_) => loadFiles(folderId: state.currentFolderId),
    );
  }

  Future<void> deleteDocument(int id) async {
    emit(state.copyWith(isLoading: true, clearError: true));
    final result = await _documentRepository.deleteDocument(id);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (_) => loadFiles(folderId: state.currentFolderId),
    );
  }

  Future<void> toggleFavorite(int id) async {
    final result = await _documentRepository.toggleFavorite(id);
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (_) => loadFiles(folderId: state.currentFolderId),
    );
  }

  Future<void> renameDocument(int id, String newName) async {
    emit(state.copyWith(isLoading: true, clearError: true));
    final docResult = await _documentRepository.getDocumentById(id);
    await docResult.fold(
      (failure) async {
        emit(state.copyWith(isLoading: false, error: failure.message));
      },
      (doc) async {
        if (doc != null) {
          final result = await _documentRepository.updateDocument(doc.copyWith(name: newName));
          result.fold(
            (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
            (_) => loadFiles(folderId: state.currentFolderId),
          );
        }
      },
    );
  }

  Future<void> search(String query) async {
    if (query.isEmpty) {
      emit(state.copyWith(isSearching: false, clearError: true));
      await loadFiles(folderId: state.currentFolderId);
      return;
    }
    emit(state.copyWith(isLoading: true, isSearching: true, clearError: true));
    final result = await _documentRepository.searchDocuments(query);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (docs) => emit(state.copyWith(
        isLoading: false,
        documents: _sortDocuments(docs),
        folders: [],
        clearError: true,
      )),
    );
  }

  Future<void> getStorageUsage() async {
    final result = await _fileManagerRepository.getStorageUsage();
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (usage) => emit(state.copyWith(storageUsage: usage, clearError: true)),
    );
  }

  Future<void> openFile(String path) async {
    final result = await _fileManagerRepository.openFile(path);
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (_) {},
    );
  }

  Future<void> shareFile(String path) async {
    final result = await _fileManagerRepository.share(path);
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (_) {},
    );
  }

  void setViewMode(ViewMode mode) {
    emit(state.copyWith(viewMode: mode));
  }

  void toggleViewMode() {
    final newMode = state.viewMode == ViewMode.list ? ViewMode.grid : ViewMode.list;
    emit(state.copyWith(viewMode: newMode));
  }

  void setSortOption(SortOption option) {
    emit(state.copyWith(sortOption: option));
    loadFiles(folderId: state.currentFolderId);
  }

  void clearError() {
    emit(state.copyWith(clearError: true));
  }

  void navigateUp() {
    if (state.currentPath.isNotEmpty && state.currentPath.length > 1) {
      final parentFolder = state.currentPath[state.currentPath.length - 2];
      loadFiles(folderId: parentFolder.id);
    } else {
      loadFiles(folderId: null);
    }
  }

  List<Document> _sortDocuments(List<Document> docs) {
    final sorted = List<Document>.from(docs);
    switch (state.sortOption) {
      case SortOption.name:
        sorted.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
      case SortOption.date:
        sorted.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        break;
      case SortOption.size:
        sorted.sort((a, b) => b.fileSize.compareTo(a.fileSize));
        break;
      case SortOption.type:
        sorted.sort((a, b) => a.fileType.name.compareTo(b.fileType.name));
        break;
    }
    return sorted;
  }

  List<Folder> _sortFolders(List<Folder> folders) {
    final sorted = List<Folder>.from(folders);
    switch (state.sortOption) {
      case SortOption.name:
        sorted.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
      case SortOption.date:
        sorted.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
        break;
      default:
        sorted.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
        break;
    }
    return sorted;
  }
}
