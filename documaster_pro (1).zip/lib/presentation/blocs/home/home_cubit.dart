import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/entities/document.dart';
import '../../../domain/repositories/document_repository.dart';

part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  final DocumentRepository _documentRepository;

  HomeCubit(this._documentRepository) : super(const HomeState());

  Future<void> loadHomeData() async {
    emit(state.copyWith(isLoading: true, error: null));

    final recentResult = await _documentRepository.getRecentDocuments(limit: 10);
    final favoriteResult = await _documentRepository.getFavoriteDocuments();

    recentResult.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (recentFiles) {
        favoriteResult.fold(
          (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
          (favorites) {
            final recentScans = recentFiles.where((d) => 
              d.fileType == FileType.pdf && d.tags.contains('scan')
            ).toList();

            emit(state.copyWith(
              isLoading: false,
              recentFiles: recentFiles,
              recentScans: recentScans,
              favorites: favorites,
            ));
          },
        );
      },
    );
  }

  Future<void> toggleFavorite(int docId) async {
    final result = await _documentRepository.toggleFavorite(docId);
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (_) => loadHomeData(),
    );
  }

  Future<void> search(String query) async {
    if (query.isEmpty) {
      await loadHomeData();
      return;
    }
    emit(state.copyWith(isLoading: true, error: null));
    final result = await _documentRepository.searchDocuments(query);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (results) => emit(state.copyWith(
        isLoading: false,
        searchResults: results,
      )),
    );
  }

  void clearSearch() {
    emit(state.copyWith(searchResults: [], error: null));
    loadHomeData();
  }
}
