part of 'home_cubit.dart';

class HomeState extends Equatable {
  final List<Document> recentFiles;
  final List<Document> recentScans;
  final List<Document> favorites;
  final List<Document> searchResults;
  final StorageInfo? storageInfo;
  final bool isLoading;
  final String? error;

  const HomeState({
    this.recentFiles = const [],
    this.recentScans = const [],
    this.favorites = const [],
    this.searchResults = const [],
    this.storageInfo,
    this.isLoading = false,
    this.error,
  });

  HomeState copyWith({
    List<Document>? recentFiles,
    List<Document>? recentScans,
    List<Document>? favorites,
    List<Document>? searchResults,
    StorageInfo? storageInfo,
    bool? isLoading,
    String? error,
  }) {
    return HomeState(
      recentFiles: recentFiles ?? this.recentFiles,
      recentScans: recentScans ?? this.recentScans,
      favorites: favorites ?? this.favorites,
      searchResults: searchResults ?? this.searchResults,
      storageInfo: storageInfo ?? this.storageInfo,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }

  @override
  List<Object?> get props => [
    recentFiles, recentScans, favorites, searchResults,
    storageInfo, isLoading, error,
  ];
}

class StorageInfo extends Equatable {
  final int totalStorage;
  final int usedStorage;
  final int freeStorage;
  final List<StorageBreakdown> breakdown;

  const StorageInfo({
    required this.totalStorage,
    required this.usedStorage,
    required this.freeStorage,
    required this.breakdown,
  });

  double get usedPercentage => totalStorage > 0 ? usedStorage / totalStorage : 0;

  @override
  List<Object?> get props => [totalStorage, usedStorage, freeStorage, breakdown];
}

class StorageBreakdown extends Equatable {
  final String category;
  final int size;
  final int colorValue;

  const StorageBreakdown({
    required this.category,
    required this.size,
    required this.colorValue,
  });

  @override
  List<Object?> get props => [category, size, colorValue];
}
