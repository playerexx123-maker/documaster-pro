import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../domain/repositories/auth_repository.dart';

part 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  final AuthRepository _authRepository;

  AuthCubit(this._authRepository) : super(const AuthState());

  /// Checks the overall authentication status including biometric availability,
  /// biometric enabled status, and PIN setup status.
  Future<void> checkAuthStatus() async {
    emit(state.copyWith(isLoading: true));

    final biometricAvailable = await _authRepository.isBiometricAvailable();
    final biometricEnabled = await _authRepository.isBiometricEnabled();
    final pinSetup = await _authRepository.isPinSetup();

    bool bioAvailable = false;
    bool bioEnabled = false;
    bool hasPin = false;

    biometricAvailable.fold((l) {}, (r) => bioAvailable = r);
    biometricEnabled.fold((l) {}, (r) => bioEnabled = r);
    pinSetup.fold((l) {}, (r) => hasPin = r);

    emit(state.copyWith(
      isLoading: false,
      isBiometricAvailable: bioAvailable,
      isBiometricEnabled: bioEnabled,
      isPinSetup: hasPin,
    ));
  }

  /// Authenticates the user using biometrics (fingerprint or face recognition).
  Future<void> authenticateWithBiometrics() async {
    emit(state.copyWith(isLoading: true, error: null));
    final result = await _authRepository.authenticateWithBiometrics();
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (success) => emit(state.copyWith(isLoading: false, isAuthenticated: success)),
    );
  }

  /// Verifies the entered PIN against the stored hash.
  Future<void> verifyPin(String pin) async {
    emit(state.copyWith(isLoading: true, error: null));
    final result = await _authRepository.verifyPin(pin);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (success) => emit(state.copyWith(isLoading: false, isAuthenticated: success)),
    );
  }

  /// Sets up a new PIN for app protection.
  Future<void> setupPin(String pin) async {
    emit(state.copyWith(isLoading: true, error: null));
    final result = await _authRepository.setupPin(pin);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (success) => emit(state.copyWith(isLoading: false, isPinSetup: success)),
    );
  }

  /// Enables or disables biometric authentication.
  Future<void> enableBiometric(bool enable) async {
    emit(state.copyWith(isLoading: true, error: null));
    final result = await _authRepository.enableBiometric(enable);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (_) {
        emit(state.copyWith(isLoading: false, isBiometricEnabled: enable));
      },
    );
  }

  /// Changes the existing PIN (requires old PIN verification first).
  Future<void> changePin(String newPin) async {
    emit(state.copyWith(isLoading: true, error: null));
    final result = await _authRepository.setPin(newPin);
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (_) => emit(state.copyWith(isLoading: false, isPinSetup: true)),
    );
  }

  /// Clears the stored PIN, effectively disabling PIN protection.
  Future<void> clearPin() async {
    emit(state.copyWith(isLoading: true, error: null));
    final result = await _authRepository.clearPin();
    result.fold(
      (failure) => emit(state.copyWith(isLoading: false, error: failure.message)),
      (_) => emit(state.copyWith(isLoading: false, isPinSetup: false)),
    );
  }

  /// Checks only if biometric authentication is available on this device.
  Future<void> checkBiometricAvailability() async {
    final result = await _authRepository.isBiometricAvailable();
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (available) => emit(state.copyWith(isBiometricAvailable: available)),
    );
  }

  /// Checks only if a PIN has already been set up.
  Future<void> checkPinSetup() async {
    final result = await _authRepository.isPinSetup();
    result.fold(
      (failure) => emit(state.copyWith(error: failure.message)),
      (setup) => emit(state.copyWith(isPinSetup: setup)),
    );
  }

  /// Resets the authentication state to default values.
  void reset() {
    emit(const AuthState());
  }

  /// Clears any error message from the state.
  void clearError() {
    emit(state.copyWith(error: null));
  }
}
