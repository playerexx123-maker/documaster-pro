part of 'auth_cubit.dart';

/// Represents the authentication state of the application.
///
/// Tracks whether the user is authenticated, biometric availability,
/// PIN setup status, and loading/error states.
class AuthState extends Equatable {
  final bool isAuthenticated;
  final bool isBiometricAvailable;
  final bool isBiometricEnabled;
  final bool isPinSetup;
  final bool isLoading;
  final String? error;

  const AuthState({
    this.isAuthenticated = false,
    this.isBiometricAvailable = false,
    this.isBiometricEnabled = false,
    this.isPinSetup = false,
    this.isLoading = false,
    this.error,
  });

  AuthState copyWith({
    bool? isAuthenticated,
    bool? isBiometricAvailable,
    bool? isBiometricEnabled,
    bool? isPinSetup,
    bool? isLoading,
    String? error,
  }) {
    return AuthState(
      isAuthenticated: isAuthenticated ?? this.isAuthenticated,
      isBiometricAvailable: isBiometricAvailable ?? this.isBiometricAvailable,
      isBiometricEnabled: isBiometricEnabled ?? this.isBiometricEnabled,
      isPinSetup: isPinSetup ?? this.isPinSetup,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }

  /// Returns true if any authentication method is configured (PIN or biometric).
  bool get hasAnyAuthMethod => isPinSetup || isBiometricEnabled;

  @override
  List<Object?> get props => [
    isAuthenticated,
    isBiometricAvailable,
    isBiometricEnabled,
    isPinSetup,
    isLoading,
    error,
  ];
}
