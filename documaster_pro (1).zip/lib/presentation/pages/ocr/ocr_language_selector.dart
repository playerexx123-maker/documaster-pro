import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../blocs/ocr/ocr_cubit.dart';

class OcrLanguageSelector extends StatefulWidget {
  final String selectedLanguage;

  const OcrLanguageSelector({
    super.key,
    required this.selectedLanguage,
  });

  @override
  State<OcrLanguageSelector> createState() => _OcrLanguageSelectorState();
}

class _OcrLanguageSelectorState extends State<OcrLanguageSelector> {
  late String _selected;
  final Map<String, _LanguageOption> _languages = const {
    'en': _LanguageOption(
      code: 'en',
      name: 'English',
      nativeName: 'English',
      flag: 'GB',
    ),
    'ro': _LanguageOption(
      code: 'ro',
      name: 'Romanian',
      nativeName: 'Romana',
      flag: 'RO',
    ),
    'hu': _LanguageOption(
      code: 'hu',
      name: 'Hungarian',
      nativeName: 'Magyar',
      flag: 'HU',
    ),
    'de': _LanguageOption(
      code: 'de',
      name: 'German',
      nativeName: 'Deutsch',
      flag: 'DE',
    ),
    'it': _LanguageOption(
      code: 'it',
      name: 'Italian',
      nativeName: 'Italiano',
      flag: 'IT',
    ),
  };

  @override
  void initState() {
    super.initState();
    _selected = widget.selectedLanguage;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<OcrCubit>().loadSupportedLanguages();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.6,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Drag handle
          Container(
            margin: const EdgeInsets.only(top: 8),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.4),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Select OCR Language',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () => Navigator.of(context).pop(_selected),
                  child: const Text('Done'),
                ),
              ],
            ),
          ),

          const Divider(height: 1),

          // Info banner
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.5),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.info_outline,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'OCR uses Google ML Kit with Latin script recognition. '
                    'Select the primary language of your document for best results.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Language list
          Flexible(
            child: BlocBuilder<OcrCubit, OcrState>(
              builder: (context, state) {
                return ListView.builder(
                  shrinkWrap: true,
                  itemCount: _languages.length,
                  itemBuilder: (context, index) {
                    final entry = _languages.entries.elementAt(index);
                    final lang = entry.value;
                    final isSelected = _selected == lang.code;
                    final isSupported = state.supportedLanguages.isEmpty ||
                        state.supportedLanguages.any((l) => l.code == lang.code && l.isSupported);

                    return RadioListTile<String>(
                      value: lang.code,
                      groupValue: _selected,
                      onChanged: isSupported
                          ? (value) {
                              setState(() {
                                _selected = value!;
                              });
                            }
                          : null,
                      title: Row(
                        children: [
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? Theme.of(context).colorScheme.primaryContainer
                                  : Theme.of(context).colorScheme.surfaceContainerHighest,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Center(
                              child: Text(
                                lang.flag,
                                style: const TextStyle(fontSize: 18),
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  lang.name,
                                  style: TextStyle(
                                    fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                    color: isSupported
                                        ? null
                                        : Theme.of(context).colorScheme.onSurfaceVariant,
                                  ),
                                ),
                                Text(
                                  lang.nativeName,
                                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          if (!isSupported)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.errorContainer,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                'Unsupported',
                                style: TextStyle(
                                  fontSize: 10,
                                  color: Theme.of(context).colorScheme.onErrorContainer,
                                ),
                              ),
                            ),
                        ],
                      ),
                      activeColor: Theme.of(context).colorScheme.primary,
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _LanguageOption {
  final String code;
  final String name;
  final String nativeName;
  final String flag;

  const _LanguageOption({
    required this.code,
    required this.name,
    required this.nativeName,
    required this.flag,
  });
}
