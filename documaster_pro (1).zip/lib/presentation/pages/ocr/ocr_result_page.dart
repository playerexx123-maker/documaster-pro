import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:share_plus/share_plus.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/loading_indicator.dart' as widgets;
import '../../../domain/entities/ocr_result.dart';
import '../../../domain/repositories/ocr_repository.dart';
import '../../../domain/usecases/ocr/export_ocr_text.dart';
import '../../../domain/usecases/ocr/get_document_text.dart';
import '../../../domain/usecases/ocr/get_supported_languages.dart';
import '../../../domain/usecases/ocr/recognize_document_text.dart';
import '../../../domain/usecases/ocr/recognize_text.dart';
import '../../blocs/ocr/ocr_cubit.dart';
import 'ocr_language_selector.dart';

class OcrResultPage extends StatelessWidget {
  final int? documentId;
  final String? imagePath;
  final String documentName;

  const OcrResultPage({
    super.key,
    this.documentId,
    this.imagePath,
    this.documentName = 'OCR Result',
  });

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) {
        final repo = GetIt.I<OcrRepository>();
        return OcrCubit(
          recognizeText: RecognizeText(repo),
          recognizeDocumentText: RecognizeDocumentText(repo),
          getDocumentText: GetDocumentText(repo),
          exportOcrText: ExportOcrText(repo),
          getSupportedLanguages: GetSupportedLanguages(repo),
        );
      },
      child: _OcrResultView(
        documentId: documentId,
        imagePath: imagePath,
        documentName: documentName,
      ),
    );
  }
}

class _OcrResultView extends StatefulWidget {
  final int? documentId;
  final String? imagePath;
  final String documentName;

  const _OcrResultView({
    this.documentId,
    this.imagePath,
    required this.documentName,
  });

  @override
  State<_OcrResultView> createState() => _OcrResultViewState();
}

class _OcrResultViewState extends State<_OcrResultView> {
  String _selectedLanguage = 'en';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadOcrResult();
    });
  }

  void _loadOcrResult() {
    final cubit = context.read<OcrCubit>();
    if (widget.documentId != null) {
      cubit.getRecognizedText(widget.documentId!);
    } else if (widget.imagePath != null) {
      cubit.recognizeImage(widget.imagePath!, language: _selectedLanguage);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: widget.documentName,
        showBackButton: true,
        actions: [
          BlocBuilder<OcrCubit, OcrState>(
            builder: (context, state) {
              if (state.fullText != null && state.fullText!.isNotEmpty) {
                return Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      onPressed: () => _showExportOptions(context),
                      icon: const Icon(Icons.share),
                      tooltip: 'Export',
                    ),
                    IconButton(
                      onPressed: () => _showLanguageSelector(context),
                      icon: const Icon(Icons.language),
                      tooltip: 'Language',
                    ),
                  ],
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
      body: BlocConsumer<OcrCubit, OcrState>(
        listenWhen: (previous, current) =>
            current.error != null && previous.error != current.error ||
            current.exportPath != null && previous.exportPath != current.exportPath,
        listener: (context, state) {
          if (state.error != null) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.error!)),
            );
            context.read<OcrCubit>().clearError();
          }
          if (state.exportPath != null) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Exported to: ${state.exportPath}')),
            );
          }
        },
        builder: (context, state) {
          if (state.isProcessing) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  widgets.LoadingIndicator(),
                  SizedBox(height: 16),
                  Text('Recognizing text...'),
                ],
              ),
            );
          }

          if (state.fullText == null || state.fullText!.isEmpty) {
            return _buildEmptyState(context, state);
          }

          return _buildResultView(context, state);
        },
      ),
      floatingActionButton: BlocBuilder<OcrCubit, OcrState>(
        builder: (context, state) {
          if (state.fullText != null && state.fullText!.isNotEmpty) {
            return FloatingActionButton.extended(
              onPressed: () => _copyToClipboard(context, state.fullText!),
              icon: const Icon(Icons.copy),
              label: const Text('Copy'),
            );
          }
          return const SizedBox.shrink();
        },
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context, OcrState state) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.text_fields,
            size: 72,
            color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.4),
          ),
          const SizedBox(height: 16),
          Text(
            'No Text Recognized',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 48),
            child: Text(
              'Try scanning again with better lighting or a different angle',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          const SizedBox(height: 24),
          if (widget.documentId != null)
            FilledButton.icon(
              onPressed: () {
                context.read<OcrCubit>().recognizeDocument(
                  widget.documentId!,
                  language: _selectedLanguage,
                );
              },
              icon: const Icon(Icons.refresh),
              label: const Text('Retry OCR'),
            ),
        ],
      ),
    );
  }

  Widget _buildResultView(BuildContext context, OcrState state) {
    return Column(
      children: [
        // Stats bar
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.5),
          ),
          child: Row(
            children: [
              Icon(
                Icons.check_circle,
                size: 16,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(width: 8),
              Text(
                '${state.fullText!.length} characters',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(width: 16),
              Icon(
                Icons.language,
                size: 16,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(width: 8),
              Text(
                _getLanguageName(_selectedLanguage),
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const Spacer(),
              if (state.currentResult?.confidence != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: _getConfidenceColor(state.currentResult!.confidence!),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${(state.currentResult!.confidence! * 100).toStringAsFixed(0)}%',
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
            ],
          ),
        ),

        // Text content
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
              ),
            ),
            child: SingleChildScrollView(
              child: SelectableText(
                state.fullText!,
                style: TextStyle(
                  fontSize: 15,
                  height: 1.6,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ),
          ),
        ),

        // Quick action buttons
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _ActionButton(
                icon: Icons.copy,
                label: 'Copy',
                onTap: () => _copyToClipboard(context, state.fullText!),
              ),
              _ActionButton(
                icon: Icons.share,
                label: 'Share',
                onTap: () => _shareText(state.fullText!),
              ),
              _ActionButton(
                icon: Icons.save_alt,
                label: 'Export',
                onTap: () => _showExportOptions(context),
              ),
              if (widget.documentId != null)
                _ActionButton(
                  icon: Icons.refresh,
                  label: 'Re-run',
                  onTap: () {
                    context.read<OcrCubit>().recognizeDocument(
                      widget.documentId!,
                      language: _selectedLanguage,
                    );
                  },
                ),
            ],
          ),
        ),
      ],
    );
  }

  void _showExportOptions(BuildContext context) {
    if (widget.documentId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Export requires a saved document')),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Export Text',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: const Icon(Icons.text_snippet),
                title: const Text('Export as TXT'),
                subtitle: const Text('Plain text file'),
                onTap: () {
                  Navigator.of(context).pop();
                  context.read<OcrCubit>().exportText(
                    widget.documentId!,
                    ExportFormat.txt,
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.picture_as_pdf),
                title: const Text('Export as PDF'),
                subtitle: const Text('PDF with text content'),
                onTap: () {
                  Navigator.of(context).pop();
                  context.read<OcrCubit>().exportText(
                    widget.documentId!,
                    ExportFormat.pdf,
                  );
                },
              ),
              ListTile(
                leading: const Icon(Icons.description),
                title: const Text('Export as DOCX'),
                subtitle: const Text('Word document'),
                onTap: () {
                  Navigator.of(context).pop();
                  context.read<OcrCubit>().exportText(
                    widget.documentId!,
                    ExportFormat.docx,
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showLanguageSelector(BuildContext context) async {
    final selectedLang = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (context) => OcrLanguageSelector(
        selectedLanguage: _selectedLanguage,
      ),
    );

    if (selectedLang != null && selectedLang != _selectedLanguage) {
      setState(() {
        _selectedLanguage = selectedLang;
      });
      context.read<OcrCubit>().setLanguage(selectedLang);

      // Re-run OCR with new language
      if (widget.documentId != null) {
        context.read<OcrCubit>().recognizeDocument(
          widget.documentId!,
          language: _selectedLanguage,
        );
      } else if (widget.imagePath != null) {
        context.read<OcrCubit>().recognizeImage(
          widget.imagePath!,
          language: _selectedLanguage,
        );
      }
    }
  }

  void _copyToClipboard(BuildContext context, String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Text copied to clipboard'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _shareText(String text) {
    Share.share(text, subject: 'OCR Result');
  }

  String _getLanguageName(String code) {
    final names = {
      'en': 'English',
      'ro': 'Romanian',
      'hu': 'Hungarian',
      'de': 'German',
      'it': 'Italian',
    };
    return names[code] ?? code;
  }

  Color _getConfidenceColor(double confidence) {
    if (confidence >= 0.9) return Colors.green;
    if (confidence >= 0.7) return Colors.orange;
    return Colors.red;
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ActionButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 22, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
