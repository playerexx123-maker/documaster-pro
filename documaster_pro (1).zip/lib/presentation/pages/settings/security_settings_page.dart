import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../config/constants.dart';
import '../../blocs/auth/auth_cubit.dart';
import '../auth/pin_entry_page.dart';

class SecuritySettingsPage extends StatelessWidget {
  final bool initialSetupPin;

  const SecuritySettingsPage({super.key, this.initialSetupPin = false});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Security',
        showBackButton: true,
      ),
      body: BlocConsumer<AuthCubit, AuthState>(
        listener: (context, state) {
          if (state.error != null) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.error!)),
            );
            context.read<AuthCubit>().clearError();
          }
        },
        builder: (context, state) {
          if (state.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          return ListView(
            children: [
              _buildSectionHeader(context, 'Biometric Authentication'),
              Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(
                        state.isBiometricAvailable ? Icons.fingerprint : Icons.fingerprint_outlined,
                        color: state.isBiometricAvailable
                            ? Theme.of(context).colorScheme.primary
                            : Theme.of(context).colorScheme.outline,
                      ),
                      title: const Text('Biometric Login'),
                      subtitle: Text(
                        state.isBiometricAvailable
                            ? 'Use fingerprint or face recognition to unlock'
                            : 'Biometric authentication not available on this device',
                      ),
                      trailing: Switch(
                        value: state.isBiometricEnabled,
                        onChanged: state.isBiometricAvailable
                            ? (value) => _onBiometricToggle(context, value, state)
                            : null,
                      ),
                    ),
                    if (state.isBiometricAvailable)
                      Padding(
                        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 12),
                        child: Text(
                          'When enabled, you can use fingerprint or face recognition to quickly unlock the app.',
                          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              _buildSectionHeader(context, 'PIN Protection'),
              Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Column(
                  children: [
                    if (!state.isPinSetup) ...[
                      ListTile(
                        leading: Icon(
                          Icons.pin_outlined,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        title: const Text('Set Up PIN'),
                        subtitle: const Text(
                          'Create a ${AppConstants.minPinLength}-${AppConstants.maxPinLength} digit PIN to protect your documents',
                        ),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => _navigateToPinSetup(context),
                      ),
                    ] else ...[
                      ListTile(
                        leading: Icon(
                          Icons.verified_user,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        title: const Text('PIN is Configured'),
                        subtitle: const Text('Your app is protected with a PIN'),
                        trailing: TextButton(
                          onPressed: () => _showChangePinDialog(context),
                          child: const Text('CHANGE'),
                        ),
                      ),
                      const Divider(height: 1, indent: 16, endIndent: 16),
                      ListTile(
                        leading: const Icon(Icons.edit),
                        title: const Text('Change PIN'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => _showChangePinDialog(context),
                      ),
                      const Divider(height: 1, indent: 16, endIndent: 16),
                      ListTile(
                        leading: Icon(
                          Icons.delete_outline,
                          color: Theme.of(context).colorScheme.error,
                        ),
                        title: Text(
                          'Remove PIN',
                          style: TextStyle(color: Theme.of(context).colorScheme.error),
                        ),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => _showRemovePinConfirmation(context),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 8),
              _buildSectionHeader(context, 'Security Information'),
              Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildInfoRow(
                        context,
                        Icons.shield_outlined,
                        'AES-256 Encryption',
                        'All sensitive data is encrypted using AES-256',
                      ),
                      const SizedBox(height: 12),
                      _buildInfoRow(
                        context,
                        Icons.storage_outlined,
                        'Secure Storage',
                        'PINs and tokens are stored in encrypted secure storage',
                      ),
                      const SizedBox(height: 12),
                      _buildInfoRow(
                        context,
                        Icons.hash,
                        'SHA-256 Hashing',
                        'PINs are hashed using SHA-256 before storage',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 32),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildInfoRow(BuildContext context, IconData icon, String title, String subtitle) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 20,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _onBiometricToggle(BuildContext context, bool value, AuthState state) async {
    if (value) {
      // First authenticate before enabling
      final result = await context.read<AuthCubit>().authenticateWithBiometrics();
      // The authenticateWithBiometrics method updates the state internally
    } else {
      context.read<AuthCubit>().enableBiometric(false);
    }
  }

  void _navigateToPinSetup(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PinEntryPage(
          mode: PinEntryMode.setup,
          onPinSet: (pin) {
            context.read<AuthCubit>().setupPin(pin);
            Navigator.pop(context);
          },
        ),
      ),
    );
  }

  void _showChangePinDialog(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PinEntryPage(
          mode: PinEntryMode.change,
          onPinSet: (newPin) {
            context.read<AuthCubit>().changePin(newPin);
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('PIN changed successfully')),
            );
          },
        ),
      ),
    );
  }

  void _showRemovePinConfirmation(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Remove PIN?'),
        content: const Text(
          'This will remove PIN protection from the app. Your documents will still be accessible without authentication. Are you sure?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () {
              context.read<AuthCubit>().clearPin();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('PIN protection removed')),
              );
            },
            child: const Text('REMOVE'),
          ),
        ],
      ),
    );
  }
}
