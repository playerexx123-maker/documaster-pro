import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../config/constants.dart';
import '../../blocs/settings/settings_cubit.dart';

class OcrSettingsPage extends StatelessWidget {
  const OcrSettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'OCR Settings',
        showBackButton: true,
      ),
      body: BlocBuilder<SettingsCubit, SettingsState>(
        builder: (context, state) {
          return ListView(
            children: [
              _buildSectionHeader(context, 'Language'),
              Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Column(
                  children: [
                    for (final entry in AppConstants.ocrLanguageNames.entries) ...[
                      RadioListTile<String>(
                        title: Text(entry.value),
                        secondary: _buildLanguageFlag(entry.key),
                        value: entry.key,
                        groupValue: state.settings.defaultOcrLanguage,
                        onChanged: (value) {
                          if (value != null) {
                            context.read<SettingsCubit>().updateOcrLanguage(value);
                          }
                        },
                      ),
                      if (entry.key != AppConstants.ocrLanguageNames.keys.last)
                        const Divider(height: 1, indent: 72),
                    ],
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Select the primary language for text recognition. The OCR engine will use this language to improve recognition accuracy.',
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ),
              _buildSectionHeader(context, 'Recognition Settings'),
              SwitchListTile(
                secondary: const Icon(Icons.text_fields),
                title: const Text('Auto-Detect Text Blocks'),
                subtitle: const Text('Automatically identify text regions'),
                value: true,
                onChanged: (value) {},
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              SwitchListTile(
                secondary: const Icon(Icons.translate),
                title: const Text('Multi-Language Support'),
                subtitle: const Text('Detect text in multiple languages'),
                value: false,
                onChanged: (value) {},
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.trending_up),
                title: const Text('Recognition Accuracy'),
                subtitle: const Text('High accuracy (slower)'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showAccuracyDialog(context),
              ),
              _buildSectionHeader(context, 'Output'),
              ListTile(
                leading: const Icon(Icons.format_align_left),
                title: const Text('Output Format'),
                subtitle: const Text('Plain text'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showOutputFormatDialog(context),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              SwitchListTile(
                secondary: const Icon(Icons.space_bar),
                title: const Text('Preserve Formatting'),
                subtitle: const Text('Keep original text layout and spacing'),
                value: true,
                onChanged: (value) {},
              ),
              const SizedBox(height: 32),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildLanguageFlag(String code) {
    final flags = {
      'en': '\u{1F1EC}\u{1F1E7}',
      'ro': '\u{1F1F7}\u{1F1F4}',
      'hu': '\u{1F1ED}\u{1F1FA}',
      'de': '\u{1F1E9}\u{1F1EA}',
      'it': '\u{1F1EE}\u{1F1F9}',
    };
    return Text(
      flags[code] ?? '\ud83c\udf10',
      style: const TextStyle(fontSize: 24),
    );
  }

  void _showAccuracyDialog(BuildContext context) {
    final modes = ['Fast (lower accuracy)', 'Balanced', 'High accuracy (slower)'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Recognition Accuracy'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: modes.map((m) => RadioListTile<String>(
            title: Text(m),
            value: m,
            groupValue: 'High accuracy (slower)',
            onChanged: (value) => Navigator.pop(context),
          )).toList(),
        ),
      ),
    );
  }

  void _showOutputFormatDialog(BuildContext context) {
    final formats = ['Plain text', 'Formatted text', 'PDF with text layer', 'DOCX'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Output Format'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: formats.map((f) => RadioListTile<String>(
            title: Text(f),
            value: f,
            groupValue: 'Plain text',
            onChanged: (value) => Navigator.pop(context),
          )).toList(),
        ),
      ),
    );
  }
}
