import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../blocs/settings/settings_cubit.dart';

class CloudSettingsPage extends StatelessWidget {
  const CloudSettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Cloud Sync',
        showBackButton: true,
      ),
      body: BlocBuilder<SettingsCubit, SettingsState>(
        builder: (context, state) {
          return ListView(
            children: [
              _buildSectionHeader(context, 'Cloud Sync'),
              SwitchListTile(
                secondary: const Icon(Icons.cloud_sync),
                title: const Text('Enable Cloud Sync'),
                subtitle: const Text('Automatically sync documents to cloud'),
                value: state.settings.cloudSyncEnabled,
                onChanged: (value) {
                  context.read<SettingsCubit>().updateCloudSync(value);
                },
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Card(
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Row(
                      children: [
                        Icon(Icons.info_outline, size: 20),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Cloud sync keeps your documents backed up and accessible across all your devices.',
                            style: TextStyle(fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              _buildSectionHeader(context, 'Cloud Providers'),
              _buildProviderTile(
                context,
                provider: 'Google Drive',
                icon: Icons.cloud,
                iconColor: const Color(0xFF4285F4),
                isConnected: state.settings.defaultCloudProvider == 'google_drive',
                onConnect: () => _showConnectDialog(context, 'Google Drive'),
                onDisconnect: () => _showDisconnectDialog(context, 'Google Drive'),
                storageInfo: '15 GB free storage',
              ),
              _buildProviderTile(
                context,
                provider: 'Dropbox',
                icon: Icons.cloud_queue,
                iconColor: const Color(0xFF0061FF),
                isConnected: state.settings.defaultCloudProvider == 'dropbox',
                onConnect: () => _showConnectDialog(context, 'Dropbox'),
                onDisconnect: () => _showDisconnectDialog(context, 'Dropbox'),
                storageInfo: '2 GB free storage',
              ),
              _buildProviderTile(
                context,
                provider: 'OneDrive',
                icon: Icons.cloud_circle,
                iconColor: const Color(0xFF0078D4),
                isConnected: state.settings.defaultCloudProvider == 'onedrive',
                onConnect: () => _showConnectDialog(context, 'OneDrive'),
                onDisconnect: () => _showDisconnectDialog(context, 'OneDrive'),
                storageInfo: '5 GB free storage',
              ),
              _buildSectionHeader(context, 'Sync Settings'),
              ListTile(
                leading: const Icon(Icons.sync),
                title: const Text('Last Sync'),
                subtitle: const Text('Never'),
                trailing: TextButton.icon(
                  onPressed: () => _showSyncNowDialog(context),
                  icon: const Icon(Icons.sync, size: 18),
                  label: const Text('SYNC NOW'),
                ),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.schedule),
                title: const Text('Auto Sync Frequency'),
                subtitle: const Text('Every 30 minutes'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showSyncFrequencyDialog(context),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.wifi),
                title: const Text('Sync on Wi-Fi Only'),
                subtitle: const Text('Prevent mobile data usage'),
                trailing: Switch(
                  value: true,
                  onChanged: (value) {},
                ),
              ),
              const SizedBox(height: 32),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildProviderTile(
    BuildContext context, {
    required String provider,
    required IconData icon,
    required Color iconColor,
    required bool isConnected,
    required VoidCallback onConnect,
    required VoidCallback onDisconnect,
    required String storageInfo,
  }) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ListTile(
              leading: CircleAvatar(
                backgroundColor: iconColor.withOpacity(0.1),
                child: Icon(icon, color: iconColor),
              ),
              title: Text(provider),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(storageInfo),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: isConnected
                          ? Colors.green.withOpacity(0.1)
                          : Theme.of(context).colorScheme.surfaceVariant,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      isConnected ? 'Connected' : 'Not Connected',
                      style: TextStyle(
                        fontSize: 12,
                        color: isConnected
                            ? Colors.green
                            : Theme.of(context).colorScheme.onSurfaceVariant,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              trailing: isConnected
                  ? TextButton(
                      onPressed: onDisconnect,
                      child: const Text('DISCONNECT'),
                    )
                  : ElevatedButton(
                      onPressed: onConnect,
                      child: const Text('CONNECT'),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showConnectDialog(BuildContext context, String provider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Connect $provider'),
        content: Text(
          'You will be redirected to $provider to authorize access. DocuMaster Pro will be able to upload and download documents from your cloud storage.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CANCEL'),
          ),
          ElevatedButton(
            onPressed: () {
              final providerKey = provider.toLowerCase().replaceAll(' ', '_');
              context.read<SettingsCubit>().updateCloudProvider(providerKey);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Connected to $provider')),
              );
            },
            child: const Text('CONNECT'),
          ),
        ],
      ),
    );
  }

  void _showDisconnectDialog(BuildContext context, String provider) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Disconnect $provider?'),
        content: const Text(
          'Your documents will no longer sync to this cloud provider. Previously synced files will remain in the cloud.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CANCEL'),
          ),
          TextButton(
            onPressed: () {
              context.read<SettingsCubit>().updateCloudProvider(null);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Cloud provider disconnected')),
              );
            },
            child: const Text('DISCONNECT'),
          ),
        ],
      ),
    );
  }

  void _showSyncNowDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => const AlertDialog(
        title: Text('Sync in Progress'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Syncing your documents to the cloud...'),
          ],
        ),
      ),
    );

    Future.delayed(const Duration(seconds: 2), () {
      if (context.mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Sync completed')),
        );
      }
    });
  }

  void _showSyncFrequencyDialog(BuildContext context) {
    final frequencies = ['15 minutes', '30 minutes', '1 hour', 'Manual only'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Auto Sync Frequency'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: frequencies.map((freq) => RadioListTile<String>(
            title: Text(freq),
            value: freq,
            groupValue: '30 minutes',
            onChanged: (value) => Navigator.pop(context),
          )).toList(),
        ),
      ),
    );
  }
}
