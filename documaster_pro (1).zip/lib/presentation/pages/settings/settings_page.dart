import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:adaptive_theme/adaptive_theme.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/bottom_nav.dart';
import '../../blocs/settings/settings_cubit.dart';
import '../../blocs/auth/auth_cubit.dart';
import 'security_settings_page.dart';
import 'cloud_settings_page.dart';
import 'scanner_settings_page.dart';
import 'ocr_settings_page.dart';
import 'about_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DocuMasterAppBar(title: 'Settings'),
      body: BlocBuilder<SettingsCubit, SettingsState>(
        builder: (context, state) {
          return ListView(
            children: [
              _buildSectionHeader(context, 'Appearance'),
              ListTile(
                leading: const Icon(Icons.brightness_medium),
                title: const Text('Theme'),
                subtitle: Text(_themeModeLabel(state.settings.themeMode)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showThemeSelector(context, state.settings.themeMode),
              ),
              _buildSectionHeader(context, 'Security'),
              BlocBuilder<AuthCubit, AuthState>(
                builder: (context, authState) {
                  return Column(
                    children: [
                      SwitchListTile(
                        secondary: const Icon(Icons.fingerprint),
                        title: const Text('Biometric Login'),
                        subtitle: Text(authState.isBiometricAvailable
                            ? 'Use fingerprint or face recognition'
                            : 'Not available on this device'),
                        value: authState.isBiometricEnabled && authState.isBiometricAvailable,
                        onChanged: authState.isBiometricAvailable
                            ? (value) => context.read<AuthCubit>().enableBiometric(value)
                            : null,
                      ),
                      SwitchListTile(
                        secondary: const Icon(Icons.pin),
                        title: const Text('PIN Protection'),
                        subtitle: Text(authState.isPinSetup
                            ? 'PIN is configured'
                            : 'Require PIN to open app'),
                        value: authState.isPinSetup,
                        onChanged: (value) {
                          if (value) {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const SecuritySettingsPage(initialSetupPin: true),
                              ),
                            );
                          } else {
                            context.read<AuthCubit>().clearPin();
                          }
                        },
                      ),
                      ListTile(
                        leading: const Icon(Icons.security),
                        title: const Text('Security Settings'),
                        subtitle: const Text('Manage biometric and PIN'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const SecuritySettingsPage(),
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
              _buildSectionHeader(context, 'Scanner'),
              ListTile(
                leading: const Icon(Icons.tune),
                title: const Text('Scanner Settings'),
                subtitle: Text('Quality: ${state.settings.defaultPdfQuality}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ScannerSettingsPage(),
                  ),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.language),
                title: const Text('OCR Language'),
                subtitle: Text(_ocrLanguageName(state.settings.defaultOcrLanguage)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const OcrSettingsPage(),
                  ),
                ),
              ),
              _buildSectionHeader(context, 'Cloud Sync'),
              SwitchListTile(
                secondary: const Icon(Icons.cloud_sync),
                title: const Text('Enable Cloud Sync'),
                subtitle: const Text('Sync documents across devices'),
                value: state.settings.cloudSyncEnabled,
                onChanged: (value) => context.read<SettingsCubit>().updateCloudSync(value),
              ),
              ListTile(
                leading: const Icon(Icons.cloud),
                title: const Text('Cloud Providers'),
                subtitle: Text(state.settings.defaultCloudProvider != null
                    ? 'Connected to ${state.settings.defaultCloudProvider}'
                    : 'No cloud provider connected'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const CloudSettingsPage(),
                  ),
                ),
              ),
              _buildSectionHeader(context, 'About'),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('About DocuMaster Pro'),
                subtitle: const Text('Version 1.0.0'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const AboutPage(),
                  ),
                ),
              ),
            ],
          );
        },
      ),
      bottomNavigationBar: const AppBottomNav(currentIndex: 5),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  String _themeModeLabel(ThemeMode mode) {
    switch (mode) {
      case ThemeMode.light:
        return 'Light';
      case ThemeMode.dark:
        return 'Dark';
      case ThemeMode.system:
        return 'System';
    }
  }

  String _ocrLanguageName(String code) {
    const names = {
      'en': 'English',
      'ro': 'Romanian',
      'hu': 'Hungarian',
      'de': 'German',
      'it': 'Italian',
    };
    return names[code] ?? code;
  }

  void _showThemeSelector(BuildContext context, ThemeMode currentMode) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Select Theme'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<ThemeMode>(
              title: const Text('System'),
              subtitle: const Text('Follow system setting'),
              value: ThemeMode.system,
              groupValue: currentMode,
              onChanged: (value) {
                if (value != null) {
                  context.read<SettingsCubit>().updateThemeMode(value);
                  AdaptiveTheme.of(context).setThemeMode(
                    value == ThemeMode.dark
                        ? AdaptiveThemeMode.dark
                        : value == ThemeMode.light
                            ? AdaptiveThemeMode.light
                            : AdaptiveThemeMode.system,
                  );
                }
                Navigator.pop(context);
              },
            ),
            RadioListTile<ThemeMode>(
              title: const Text('Light'),
              value: ThemeMode.light,
              groupValue: currentMode,
              onChanged: (value) {
                if (value != null) {
                  context.read<SettingsCubit>().updateThemeMode(value);
                  AdaptiveTheme.of(context).setLight();
                }
                Navigator.pop(context);
              },
            ),
            RadioListTile<ThemeMode>(
              title: const Text('Dark'),
              value: ThemeMode.dark,
              groupValue: currentMode,
              onChanged: (value) {
                if (value != null) {
                  context.read<SettingsCubit>().updateThemeMode(value);
                  AdaptiveTheme.of(context).setDark();
                }
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
