import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../blocs/settings/settings_cubit.dart';

class ScannerSettingsPage extends StatelessWidget {
  const ScannerSettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Scanner Settings',
        showBackButton: true,
      ),
      body: BlocBuilder<SettingsCubit, SettingsState>(
        builder: (context, state) {
          return ListView(
            children: [
              _buildSectionHeader(context, 'Image Enhancement'),
              SwitchListTile(
                secondary: const Icon(Icons.auto_fix_high),
                title: const Text('Auto-Enhance Scans'),
                subtitle: const Text('Automatically improve scan quality'),
                value: state.settings.autoEnhanceScans,
                onChanged: (value) {
                  context.read<SettingsCubit>().updateAutoEnhance(value);
                },
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              SwitchListTile(
                secondary: const Icon(Icons.save),
                title: const Text('Keep Original Scans'),
                subtitle: const Text('Save unprocessed version alongside enhanced'),
                value: state.settings.keepOriginalScans,
                onChanged: (value) {
                  context.read<SettingsCubit>().updateKeepOriginalScans(value);
                },
              ),
              _buildSectionHeader(context, 'PDF Quality'),
              ListTile(
                leading: const Icon(Icons.picture_as_pdf),
                title: const Text('Default PDF Quality'),
                subtitle: Text(_qualityLabel(state.settings.defaultPdfQuality)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showPdfQualityDialog(context, state.settings.defaultPdfQuality),
              ),
              _buildSectionHeader(context, 'Default Filters'),
              ListTile(
                leading: const Icon(Icons.filter_b_and_w),
                title: const Text('Color Mode'),
                subtitle: const Text('Select default scan color mode'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showColorModeDialog(context),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.crop),
                title: const Text('Auto-Crop'),
                subtitle: const Text('Automatically detect document edges'),
                trailing: Switch(
                  value: true,
                  onChanged: (value) {},
                ),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.straighten),
                title: const Text('Auto-Straighten'),
                subtitle: const Text('Correct document skew automatically'),
                trailing: Switch(
                  value: true,
                  onChanged: (value) {},
                ),
              ),
              _buildSectionHeader(context, 'Advanced'),
              ListTile(
                leading: const Icon(Icons.high_quality),
                title: const Text('Scan Resolution'),
                subtitle: const Text('High (recommended)'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showResolutionDialog(context),
              ),
              const Divider(height: 1, indent: 16, endIndent: 16),
              ListTile(
                leading: const Icon(Icons.compress),
                title: const Text('Compression Level'),
                subtitle: const Text('Balanced'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showCompressionDialog(context),
              ),
              const SizedBox(height: 32),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  String _qualityLabel(String quality) {
    switch (quality) {
      case 'low':
        return 'Low - Smaller file size';
      case 'medium':
        return 'Medium - Balanced';
      case 'high':
        return 'High - Best quality';
      default:
        return 'Medium - Balanced';
    }
  }

  void _showPdfQualityDialog(BuildContext context, String currentQuality) {
    final qualities = [
      _QualityOption('low', 'Low', 'Smaller file size, faster processing', Icons.speed),
      _QualityOption('medium', 'Medium', 'Balanced quality and size', Icons.balance),
      _QualityOption('high', 'High', 'Best quality, larger files', Icons.high_quality),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('PDF Quality'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: qualities.map((q) => RadioListTile<String>(
            title: Text(q.name),
            subtitle: Text(q.description),
            secondary: Icon(q.icon),
            value: q.value,
            groupValue: currentQuality,
            onChanged: (value) {
              if (value != null) {
                context.read<SettingsCubit>().updatePdfQuality(value);
              }
              Navigator.pop(context);
            },
          )).toList(),
        ),
      ),
    );
  }

  void _showColorModeDialog(BuildContext context) {
    final modes = [
      _ColorMode('color', 'Color', 'Full color scanning'),
      _ColorMode('grayscale', 'Grayscale', 'Black and white with shades'),
      _ColorMode('bw', 'Black & White', 'Pure black and white'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Color Mode'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: modes.map((m) => ListTile(
            title: Text(m.name),
            subtitle: Text(m.description),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.pop(context),
          )).toList(),
        ),
      ),
    );
  }

  void _showResolutionDialog(BuildContext context) {
    final resolutions = ['Standard', 'High', 'Ultra HD'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Scan Resolution'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: resolutions.map((r) => RadioListTile<String>(
            title: Text(r),
            value: r,
            groupValue: 'High',
            onChanged: (value) => Navigator.pop(context),
          )).toList(),
        ),
      ),
    );
  }

  void _showCompressionDialog(BuildContext context) {
    final levels = ['Low (larger files)', 'Balanced', 'High (smaller files)'];
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Compression Level'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: levels.map((l) => RadioListTile<String>(
            title: Text(l),
            value: l,
            groupValue: 'Balanced',
            onChanged: (value) => Navigator.pop(context),
          )).toList(),
        ),
      ),
    );
  }
}

class _QualityOption {
  final String value;
  final String name;
  final String description;
  final IconData icon;

  _QualityOption(this.value, this.name, this.description, this.icon);
}

class _ColorMode {
  final String value;
  final String name;
  final String description;

  _ColorMode(this.value, this.name, this.description);
}
