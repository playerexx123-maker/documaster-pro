import 'package:flutter/material.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../config/constants.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'About',
        showBackButton: true,
      ),
      body: ListView(
        children: [
          const SizedBox(height: 32),
          Center(
            child: Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primaryContainer,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(
                Icons.document_scanner,
                size: 48,
                color: Theme.of(context).colorScheme.onPrimaryContainer,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Center(
            child: Text(
              AppConstants.appName,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 4),
          Center(
            child: Text(
              'Version ${AppConstants.appVersion}',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          const SizedBox(height: 8),
          Center(
            child: Text(
              'Build 2024.12.15',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          const SizedBox(height: 32),
          _buildSectionHeader(context, 'Legal'),
          ListTile(
            leading: const Icon(Icons.privacy_tip_outlined),
            title: const Text('Privacy Policy'),
            subtitle: const Text('How we handle your data'),
            trailing: const Icon(Icons.open_in_new, size: 18),
            onTap: () => _showPrivacyPolicy(context),
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),
          ListTile(
            leading: const Icon(Icons.gavel_outlined),
            title: const Text('Terms of Service'),
            subtitle: const Text('Usage terms and conditions'),
            trailing: const Icon(Icons.open_in_new, size: 18),
            onTap: () => _showTermsOfService(context),
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),
          ListTile(
            leading: const Icon(Icons.license_outlined),
            title: const Text('Open Source Licenses'),
            subtitle: const Text('Third-party libraries used'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showLicenses(context),
          ),
          _buildSectionHeader(context, 'About'),
          ListTile(
            leading: const Icon(Icons.description_outlined),
            title: const Text('What\'s New'),
            subtitle: const Text('Latest features and improvements'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showWhatsNew(context),
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),
          ListTile(
            leading: const Icon(Icons.support_outlined),
            title: const Text('Support'),
            subtitle: const Text('Get help and contact us'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showSupport(context),
          ),
          const Divider(height: 1, indent: 16, endIndent: 16),
          ListTile(
            leading: const Icon(Icons.star_outline),
            title: const Text('Rate the App'),
            subtitle: const Text('Share your feedback'),
            trailing: const Icon(Icons.open_in_new, size: 18),
            onTap: () {},
          ),
          const SizedBox(height: 32),
          Center(
            child: Text(
              '\u00a9 2024 DocuMaster Pro. All rights reserved.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  void _showPrivacyPolicy(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Privacy Policy'),
        content: const SingleChildScrollView(
          child: Text(
            'DocuMaster Pro respects your privacy.\n\n'
            'Data Collection:\n'
            '- We do not collect any personal data from your documents.\n'
            '- All document processing happens locally on your device.\n'
            '- Cloud sync data is stored on your chosen cloud provider.\n\n'
            'Data Storage:\n'
            '- Documents are stored locally on your device.\n'
            '- If cloud sync is enabled, documents are stored on your chosen cloud provider.\n'
            '- PIN and biometric data never leave your device.\n\n'
            'Third-Party Services:\n'
            '- Google Drive, Dropbox, and OneDrive integrations use their respective APIs.\n'
            '- OCR processing is performed locally using on-device ML.\n\n'
            'For questions, contact support@documaster.pro',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CLOSE'),
          ),
        ],
      ),
    );
  }

  void _showTermsOfService(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Terms of Service'),
        content: const SingleChildScrollView(
          child: Text(
            'DocuMaster Pro - Terms of Service\n\n'
            'By using this app, you agree to these terms.\n\n'
            '1. Usage License\n'
            'You are granted a limited, non-exclusive license to use the app for personal or business purposes.\n\n'
            '2. Data Responsibility\n'
            'You are responsible for the content you scan, store, and share using the app.\n\n'
            '3. Prohibited Uses\n'
            'You may not use the app for any unlawful purpose or to infringe on others\' rights.\n\n'
            '4. Disclaimer\n'
            'The app is provided "as is" without warranties of any kind.\n\n'
            '5. Limitation of Liability\n'
            'We shall not be liable for any indirect, incidental, or consequential damages.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CLOSE'),
          ),
        ],
      ),
    );
  }

  void _showLicenses(BuildContext context) {
    final licenses = [
      _License('Flutter', 'BSD 3-Clause', 'Google'),
      _License('Dart', 'BSD 3-Clause', 'Google'),
      _License('sqflite', 'BSD 2-Clause', 'Alex Tekartik'),
      _License('go_router', 'BSD 3-Clause', 'Flutter Team'),
      _License('bloc', 'MIT', 'Felix Angelov'),
      _License('flutter_bloc', 'MIT', 'Felix Angelov'),
      _License('dartz', 'BSD 3-Clause', 'Sandro Maglione'),
      _License('equatable', 'MIT', 'Felix Angelov'),
      _License('local_auth', 'BSD 3-Clause', 'Flutter Team'),
      _License('flutter_secure_storage', 'BSD 3-Clause', 'German Saprykin'),
      _License('google_sign_in', 'BSD 3-Clause', 'Flutter Team'),
      _License('encrypt', 'Apache 2.0', 'Leo Cavalcante'),
      _License('crypto', 'BSD 3-Clause', 'Dart Team'),
      _License('adaptive_theme', 'BSD 3-Clause', 'Birju Vachhani'),
      _License('google_fonts', 'Apache 2.0', 'Flutter Team'),
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Open Source Licenses'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: licenses.length,
            itemBuilder: (context, index) {
              final l = licenses[index];
              return ListTile(
                dense: true,
                title: Text(l.name, style: const TextStyle(fontWeight: FontWeight.w500)),
                subtitle: Text('${l.license} \u00b7 ${l.author}'),
              );
            },
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CLOSE'),
          ),
        ],
      ),
    );
  }

  void _showWhatsNew(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('What\'s New'),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Version 1.0.0',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              SizedBox(height: 12),
              Text('\u2022 Document scanning with auto-enhancement'),
              Text('\u2022 OCR text recognition in 5 languages'),
              Text('\u2022 PDF creation and editing'),
              Text('\u2022 Cloud sync with Google Drive, Dropbox, OneDrive'),
              Text('\u2022 Biometric and PIN app protection'),
              Text('\u2022 AI-powered document assistant'),
              Text('\u2022 Folder management and organization'),
              Text('\u2022 Dark mode support'),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('GOT IT'),
          ),
        ],
      ),
    );
  }

  void _showSupport(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Support'),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ListTile(
              leading: Icon(Icons.email),
              title: Text('Email'),
              subtitle: Text('support@documaster.pro'),
            ),
            ListTile(
              leading: Icon(Icons.language),
              title: Text('Website'),
              subtitle: Text('www.documaster.pro'),
            ),
            ListTile(
              leading: Icon(Icons.help_outline),
              title: Text('FAQ'),
              subtitle: Text('www.documaster.pro/faq'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CLOSE'),
          ),
        ],
      ),
    );
  }
}

class _License {
  final String name;
  final String license;
  final String author;

  _License(this.name, this.license, this.author);
}
