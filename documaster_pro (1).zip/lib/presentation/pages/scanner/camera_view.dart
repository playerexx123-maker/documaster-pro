import 'dart:io';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../domain/entities/scan_page.dart';
import '../../blocs/scanner/scanner_cubit.dart';
import 'scan_preview_page.dart';

class CameraView extends StatefulWidget {
  const CameraView({super.key});

  @override
  State<CameraView> createState() => _CameraViewState();
}

class _CameraViewState extends State<CameraView> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCamera();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final cubit = context.read<ScannerCubit>();
    if (cubit.cameraController == null || !cubit.cameraController!.value.isInitialized) {
      return;
    }
    if (state == AppLifecycleState.inactive) {
      cubit.cameraController?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      cubit.initializeCameras();
    }
  }

  Future<void> _initializeCamera() async {
    await context.read<ScannerCubit>().initializeCameras();
  }

  Future<void> _takePicture() async {
    final cubit = context.read<ScannerCubit>();
    final controller = cubit.cameraController;
    if (controller == null || !controller.value.isInitialized || controller.value.isTakingPicture) {
      return;
    }

    try {
      final XFile photo = await controller.takePicture();
      await cubit.addPage(photo.path);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Capture error: $e')),
        );
      }
    }
  }

  void _onFilterSelected(ScanFilter filter) {
    context.read<ScannerCubit>().setFilter(filter);
  }

  void _finishCapture() {
    final cubit = context.read<ScannerCubit>();
    if (cubit.state.pages.isNotEmpty) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => const ScanPreviewPage(),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No pages captured yet')),
      );
    }
  }

  void _showFilterOptions() {
    final cubit = context.read<ScannerCubit>();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.black87,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Select Filter',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16),
              ...ScanFilter.values.map((filter) => ListTile(
                leading: Icon(
                  _getFilterIcon(filter),
                  color: cubit.state.currentFilter == filter ? Colors.blue : Colors.white70,
                ),
                title: Text(
                  _getFilterName(filter),
                  style: TextStyle(
                    color: cubit.state.currentFilter == filter ? Colors.blue : Colors.white,
                    fontWeight: cubit.state.currentFilter == filter ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
                trailing: cubit.state.currentFilter == filter
                    ? const Icon(Icons.check_circle, color: Colors.blue)
                    : null,
                onTap: () {
                  _onFilterSelected(filter);
                  Navigator.of(context).pop();
                },
              )),
            ],
          ),
        ),
      ),
    );
  }

  IconData _getFilterIcon(ScanFilter filter) {
    switch (filter) {
      case ScanFilter.color:
        return Icons.color_lens;
      case ScanFilter.grayscale:
        return Icons.gradient;
      case ScanFilter.bw:
        return Icons.contrast;
      case ScanFilter.autoEnhance:
        return Icons.auto_fix_high;
      case ScanFilter.shadowRemoval:
        return Icons.wb_sunny;
      case ScanFilter.none:
        return Icons.no_photography;
    }
  }

  String _getFilterName(ScanFilter filter) {
    switch (filter) {
      case ScanFilter.color:
        return 'Color';
      case ScanFilter.grayscale:
        return 'Grayscale';
      case ScanFilter.bw:
        return 'Black & White';
      case ScanFilter.autoEnhance:
        return 'Auto Enhance';
      case ScanFilter.shadowRemoval:
        return 'Shadow Removal';
      case ScanFilter.none:
        return 'Original';
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ScannerCubit, ScannerState>(
      listenWhen: (previous, current) =>
          current.error != null && previous.error != current.error,
      listener: (context, state) {
        if (state.error != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.error!)),
          );
          context.read<ScannerCubit>().clearError();
        }
      },
      builder: (context, state) {
        final cubit = context.read<ScannerCubit>();
        final isInitialized = state.isCameraInitialized &&
            cubit.cameraController != null &&
            cubit.cameraController!.value.isInitialized;

        return Scaffold(
          backgroundColor: Colors.black,
          body: Stack(
            fit: StackFit.expand,
            children: [
              // Camera preview
              if (isInitialized)
                CameraPreview(cubit.cameraController!)
              else
                const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: Colors.white),
                      SizedBox(height: 16),
                      Text(
                        'Initializing camera...',
                        style: TextStyle(color: Colors.white70),
                      ),
                    ],
                  ),
                ),

              // Edge detection scan frame overlay
              if (isInitialized)
                CustomPaint(
                  size: MediaQuery.of(context).size,
                  painter: _ScanFramePainter(),
                ),

              // Top controls bar
              Positioned(
                top: MediaQuery.of(context).padding.top + 8,
                left: 8,
                right: 8,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _CircleIconButton(
                      icon: Icons.close,
                      onPressed: () {
                        if (state.pages.isNotEmpty) {
                          _showExitConfirmDialog();
                        } else {
                          context.pop();
                        }
                      },
                    ),
                    if (state.pages.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          '${state.pages.length} page${state.pages.length > 1 ? 's' : ''}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _CircleIconButton(
                          icon: state.flashMode == FlashMode.off
                              ? Icons.flash_off
                              : state.flashMode == FlashMode.auto
                                  ? Icons.flash_auto
                                  : Icons.flash_on,
                          onPressed: () => cubit.toggleFlash(),
                        ),
                        const SizedBox(width: 8),
                        if (cubit.cameras.length > 1)
                          _CircleIconButton(
                            icon: Icons.flip_camera_ios,
                            onPressed: () => cubit.switchCamera(),
                          ),
                      ],
                    ),
                  ],
                ),
              ),

              // Bottom controls
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.7),
                      ],
                    ),
                  ),
                  child: SafeArea(
                    top: false,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Filter selector row
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: ScanFilter.values.map((filter) {
                              final isSelected = state.currentFilter == filter;
                              return Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 4),
                                child: _FilterChip(
                                  label: _getFilterShortName(filter),
                                  isSelected: isSelected,
                                  onTap: () => _onFilterSelected(filter),
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                        const SizedBox(height: 20),
                        // Capture controls
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            // Gallery button
                            _CircleIconButton(
                              icon: Icons.photo_library,
                              size: 48,
                              iconSize: 24,
                              onPressed: () {
                                // TODO: Import from gallery
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Gallery import coming soon')),
                                );
                              },
                            ),
                            // Capture button
                            GestureDetector(
                              onTap: _takePicture,
                              child: Container(
                                width: 80,
                                height: 80,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: state.isProcessing ? Colors.orange : Colors.white,
                                    width: 4,
                                  ),
                                  color: state.isProcessing
                                      ? Colors.orange.withOpacity(0.3)
                                      : Colors.transparent,
                                ),
                                child: state.isProcessing
                                    ? const Center(
                                        child: SizedBox(
                                          width: 40,
                                          height: 40,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 3,
                                          ),
                                        ),
                                      )
                                    : Container(
                                        margin: const EdgeInsets.all(6),
                                        decoration: const BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.white,
                                        ),
                                      ),
                              ),
                            ),
                            // Done button
                            _CircleIconButton(
                              icon: Icons.check,
                              size: 48,
                              iconSize: 24,
                              iconColor: state.pages.isNotEmpty ? Colors.green : Colors.white54,
                              onPressed: state.pages.isNotEmpty ? _finishCapture : null,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Thumbnail strip of captured pages
              if (state.pages.isNotEmpty && isInitialized)
                Positioned(
                  bottom: 180,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 64,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: state.pages.length,
                      itemBuilder: (context, index) {
                        final page = state.pages[index];
                        final imagePath = page.processedPath ?? page.imagePath;
                        return GestureDetector(
                          onTap: () => cubit.setCurrentPage(index),
                          child: Container(
                            width: 48,
                            height: 64,
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: index == state.currentPageIndex
                                    ? Colors.blue
                                    : Colors.white,
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(2),
                              child: Image.file(
                                File(imagePath),
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  color: Colors.grey,
                                  child: const Icon(Icons.broken_image, size: 20),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  void _showExitConfirmDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Discard Scan?'),
        content: const Text('You have captured pages. Are you sure you want to discard them?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.read<ScannerCubit>().cancelSession();
              context.pop();
            },
            child: const Text('Discard', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  String _getFilterShortName(ScanFilter filter) {
    switch (filter) {
      case ScanFilter.color:
        return 'Color';
      case ScanFilter.grayscale:
        return 'Gray';
      case ScanFilter.bw:
        return 'B&W';
      case ScanFilter.autoEnhance:
        return 'Auto';
      case ScanFilter.shadowRemoval:
        return 'Shadow';
      case ScanFilter.none:
        return 'None';
    }
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback? onTap;

  const _FilterChip({
    required this.label,
    this.isSelected = false,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? Colors.white : Colors.black54,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? Colors.white : Colors.white30,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.black : Colors.white,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            fontSize: 12,
          ),
        ),
      ),
    );
  }
}

class _CircleIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onPressed;
  final double size;
  final double iconSize;
  final Color iconColor;

  const _CircleIconButton({
    required this.icon,
    this.onPressed,
    this.size = 40,
    this.iconSize = 20,
    this.iconColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Colors.black54,
        shape: BoxShape.circle,
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(icon, color: onPressed == null ? Colors.white38 : iconColor),
        iconSize: iconSize,
        padding: EdgeInsets.zero,
      ),
    );
  }
}

class _ScanFramePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.6)
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke;

    final cornerLength = 35.0;
    final rect = Rect.fromCenter(
      center: Offset(size.width / 2, size.height / 2 - 40),
      width: size.width * 0.82,
      height: size.height * 0.52,
    );

    // Draw corner brackets
    // Top-left
    canvas.drawLine(rect.topLeft, rect.topLeft.translate(cornerLength, 0), paint);
    canvas.drawLine(rect.topLeft, rect.topLeft.translate(0, cornerLength), paint);
    // Top-right
    canvas.drawLine(rect.topRight, rect.topRight.translate(-cornerLength, 0), paint);
    canvas.drawLine(rect.topRight, rect.topRight.translate(0, cornerLength), paint);
    // Bottom-left
    canvas.drawLine(rect.bottomLeft, rect.bottomLeft.translate(cornerLength, 0), paint);
    canvas.drawLine(rect.bottomLeft, rect.bottomLeft.translate(0, -cornerLength), paint);
    // Bottom-right
    canvas.drawLine(rect.bottomRight, rect.bottomRight.translate(-cornerLength, 0), paint);
    canvas.drawLine(rect.bottomRight, rect.bottomRight.translate(0, -cornerLength), paint);

    // Draw semi-transparent overlay outside the scan area
    final overlayPaint = Paint()
      ..color = Colors.black.withOpacity(0.3)
      ..style = PaintingStyle.fill;

    final fullRect = Rect.fromLTWH(0, 0, size.width, size.height);

    // Use path to fill everything except the scan frame
    final path = Path()
      ..addRect(fullRect)
      ..addRect(rect);
    canvas.drawPath(
      path,
      overlayPaint..blendMode = BlendMode.srcOver,
    );

    // Redraw just the scan frame area with transparent fill
    canvas.drawRect(
      rect,
      Paint()
        ..color = Colors.transparent
        ..blendMode = BlendMode.clear,
    );

    // Redraw corners on top
    canvas.drawLine(rect.topLeft, rect.topLeft.translate(cornerLength, 0), paint);
    canvas.drawLine(rect.topLeft, rect.topLeft.translate(0, cornerLength), paint);
    canvas.drawLine(rect.topRight, rect.topRight.translate(-cornerLength, 0), paint);
    canvas.drawLine(rect.topRight, rect.topRight.translate(0, cornerLength), paint);
    canvas.drawLine(rect.bottomLeft, rect.bottomLeft.translate(cornerLength, 0), paint);
    canvas.drawLine(rect.bottomLeft, rect.bottomLeft.translate(0, -cornerLength), paint);
    canvas.drawLine(rect.bottomRight, rect.bottomRight.translate(-cornerLength, 0), paint);
    canvas.drawLine(rect.bottomRight, rect.bottomRight.translate(0, -cornerLength), paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
