import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';
import '../../../domain/repositories/scanner_repository.dart';
import '../../blocs/scanner/scanner_cubit.dart';
import 'camera_view.dart';

class CameraPage extends StatelessWidget {
  const CameraPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ScannerCubit(
        GetIt.I<ScannerRepository>(),
      ),
      child: const CameraView(),
    );
  }
}
