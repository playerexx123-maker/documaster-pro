import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../domain/entities/document.dart';
import '../../../domain/entities/scan_page.dart';
import '../../blocs/scanner/scanner_cubit.dart';
import '../ocr/ocr_result_page.dart';

class ScanPreviewPage extends StatefulWidget {
  const ScanPreviewPage({super.key});

  @override
  State<ScanPreviewPage> createState() => _ScanPreviewPageState();
}

class _ScanPreviewPageState extends State<ScanPreviewPage> {
  final TextEditingController _nameController = TextEditingController();
  SaveFormat _selectedFormat = SaveFormat.pdf;
  bool _showOcrOption = true;

  @override
  void initState() {
    super.initState();
    final session = context.read<ScannerCubit>().state.session;
    if (session != null) {
      _nameController.text = session.name;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Preview & Edit',
        showBackButton: true,
        onBackPressed: () {
          context.read<ScannerCubit>().setShowPreview(false);
          context.pop();
        },
        actions: [
          TextButton.icon(
            onPressed: _onSaveDocument,
            icon: const Icon(Icons.save),
            label: const Text('SAVE'),
          ),
        ],
      ),
      body: BlocConsumer<ScannerCubit, ScannerState>(
        listenWhen: (previous, current) =>
            current.error != null && previous.error != current.error ||
            current.finalizedDocument != null && previous.finalizedDocument != current.finalizedDocument,
        listener: (context, state) {
          if (state.error != null) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.error!)),
            );
            context.read<ScannerCubit>().clearError();
          }
          if (state.finalizedDocument != null) {
            _onDocumentSaved(state.finalizedDocument!);
          }
        },
        builder: (context, state) {
          if (state.isProcessing) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Processing document...'),
                ],
              ),
            );
          }

          return Column(
            children: [
              // Page carousel
              Expanded(
                flex: 3,
                child: _buildPageCarousel(context, state),
              ),

              // Page thumbnails with reorder
              _buildThumbnailStrip(context, state),

              // Document settings
              Expanded(
                flex: 2,
                child: _buildSettingsPanel(context, state),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildPageCarousel(BuildContext context, ScannerState state) {
    if (state.pages.isEmpty) {
      return const Center(child: Text('No pages'));
    }

    return PageView.builder(
      controller: PageController(
        initialPage: state.currentPageIndex,
        viewportFraction: 0.9,
      ),
      onPageChanged: (index) {
        context.read<ScannerCubit>().setCurrentPage(index);
      },
      itemCount: state.pages.length,
      itemBuilder: (context, index) {
        final page = state.pages[index];
        final imagePath = page.processedPath ?? page.imagePath;
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
          child: Stack(
            fit: StackFit.expand,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.file(
                  File(imagePath),
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Container(
                    color: Colors.grey[300],
                    child: const Center(child: Icon(Icons.broken_image, size: 64)),
                  ),
                ),
              ),
              // Page number badge
              Positioned(
                top: 8,
                left: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.black54,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Text(
                    '${index + 1} / ${state.pages.length}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              // Delete button
              Positioned(
                top: 8,
                right: 8,
                child: InkWell(
                  onTap: () => _confirmDeletePage(index),
                  child: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: const BoxDecoration(
                      color: Colors.red,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.delete, color: Colors.white, size: 18),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildThumbnailStrip(BuildContext context, ScannerState state) {
    if (state.pages.isEmpty) return const SizedBox.shrink();

    return Container(
      height: 80,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.3),
      ),
      child: ReorderableListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: state.pages.length,
        buildDefaultDragHandles: false,
        proxyDecorator: (child, index, animation) {
          return AnimatedBuilder(
            animation: animation,
            builder: (context, child) {
              return Material(
                elevation: 6,
                color: Colors.transparent,
                child: child,
              );
            },
            child: child,
          );
        },
        onReorder: (oldIndex, newIndex) {
          context.read<ScannerCubit>().reorderPages(oldIndex, newIndex);
        },
        itemBuilder: (context, index) {
          final page = state.pages[index];
          final imagePath = page.processedPath ?? page.imagePath;
          final isSelected = index == state.currentPageIndex;

          return GestureDetector(
            key: ValueKey('thumb_$index'),
            onTap: () {
              context.read<ScannerCubit>().setCurrentPage(index);
            },
            child: Container(
              width: 56,
              height: 72,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                border: Border.all(
                  color: isSelected
                      ? Theme.of(context).colorScheme.primary
                      : Colors.transparent,
                  width: 2,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Image.file(
                      File(imagePath),
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.grey,
                      ),
                    ),
                  ),
                  // Drag handle
                  Positioned(
                    right: 2,
                    bottom: 2,
                    child: ReorderableDragStartListener(
                      index: index,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: const Icon(
                          Icons.drag_handle,
                          color: Colors.white,
                          size: 14,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSettingsPanel(BuildContext context, ScannerState state) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Document name
          TextField(
            controller: _nameController,
            decoration: InputDecoration(
              labelText: 'Document Name',
              hintText: 'Enter document name',
              prefixIcon: const Icon(Icons.edit_document),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Save format
          Text(
            'Save Format',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          SegmentedButton<SaveFormat>(
            segments: const [
              ButtonSegment(
                value: SaveFormat.pdf,
                label: Text('PDF'),
                icon: Icon(Icons.picture_as_pdf),
              ),
              ButtonSegment(
                value: SaveFormat.images,
                label: Text('Images'),
                icon: Icon(Icons.image),
              ),
            ],
            selected: {_selectedFormat},
            onSelectionChanged: (selected) {
              setState(() {
                _selectedFormat = selected.first;
              });
            },
          ),
          const SizedBox(height: 16),

          // OCR toggle
          SwitchListTile(
            value: _showOcrOption,
            onChanged: (value) {
              setState(() {
                _showOcrOption = value;
              });
            },
            title: const Text('Run OCR on save'),
            subtitle: const Text('Extract text from scanned pages'),
            secondary: const Icon(Icons.text_fields),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(
                color: Theme.of(context).colorScheme.outlineVariant,
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Action buttons
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: state.isProcessing ? null : _onSaveDocument,
                  icon: state.isProcessing
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.save),
                  label: Text(state.isProcessing ? 'Saving...' : 'Save Document'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _onAddMorePages(context),
                  icon: const Icon(Icons.add_photo_alternate),
                  label: const Text('Add More Pages'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _onCancel(context),
                  icon: const Icon(Icons.cancel, color: Colors.red),
                  label: const Text('Discard', style: TextStyle(color: Colors.red)),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    foregroundColor: Colors.red,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _onAddMorePages(BuildContext context) {
    context.read<ScannerCubit>().setShowPreview(false);
    context.pop();
  }

  void _onCancel(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Discard Scan?'),
        content: const Text('All captured pages will be lost. Are you sure?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Keep'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.read<ScannerCubit>().cancelSession();
              context.go('/scanner');
            },
            child: const Text('Discard', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _onSaveDocument() {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a document name')),
      );
      return;
    }
    context.read<ScannerCubit>().finalizeSession(
      name: name,
      format: _selectedFormat,
    );
  }

  void _onDocumentSaved(Document document) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 8),
            Text('Document Saved'),
          ],
        ),
        content: Text('"${document.name}" has been saved successfully.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.go('/scanner');
            },
            child: const Text('Done'),
          ),
          if (_showOcrOption && document.ocrText != null)
            FilledButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => OcrResultPage(
                      documentId: document.id!,
                      documentName: document.name,
                    ),
                  ),
                );
              },
              child: const Text('View OCR'),
            ),
        ],
      ),
    );
  }

  void _confirmDeletePage(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Page?'),
        content: Text('Remove page ${index + 1} from the scan?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              context.read<ScannerCubit>().removePage(index);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}
