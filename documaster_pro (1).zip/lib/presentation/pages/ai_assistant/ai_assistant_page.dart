import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/bottom_nav.dart';
import '../../blocs/ai_assistant/ai_assistant_cubit.dart';
import 'chat_page.dart';
import 'summarize_page.dart';
import 'translate_page.dart';
import 'explain_page.dart';

class AiAssistantPage extends StatelessWidget {
  const AiAssistantPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DocuMasterAppBar(title: 'AI Assistant'),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildHeader(context),
          const SizedBox(height: 16),
          _buildAiCard(
            context,
            Icons.summarize,
            'Summarize',
            'Get a quick summary of any document',
            Colors.blue,
            () => _navigateTo(context, const SummarizePage()),
          ),
          _buildAiCard(
            context,
            Icons.translate,
            'Translate',
            'Translate documents to supported languages',
            Colors.green,
            () => _navigateTo(context, const TranslatePage()),
          ),
          _buildAiCard(
            context,
            Icons.help_outline,
            'Explain',
            'Get explanations for complex text',
            Colors.orange,
            () => _navigateTo(context, const ExplainPage()),
          ),
          _buildAiCard(
            context,
            Icons.table_chart,
            'Extract Tables',
            'Extract tables from PDF documents',
            Colors.purple,
            () => _showExtractTables(context),
          ),
          _buildAiCard(
            context,
            Icons.title,
            'Generate Title',
            'Auto-generate document titles',
            Colors.teal,
            () => _showGenerateTitle(context),
          ),
          _buildAiCard(
            context,
            Icons.label,
            'Generate Tags',
            'Auto-generate document tags',
            Colors.cyan,
            () => _showGenerateTags(context),
          ),
          _buildAiCard(
            context,
            Icons.chat_bubble_outline,
            'Chat with PDF',
            'Ask questions about your documents',
            Colors.indigo,
            () => _navigateTo(context, const ChatPage()),
          ),
        ],
      ),
      bottomNavigationBar: const AppBottomNav(currentIndex: 4),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Theme.of(context).colorScheme.primary,
            Theme.of(context).colorScheme.tertiary,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.auto_awesome,
                color: Theme.of(context).colorScheme.onPrimary,
                size: 32,
              ),
              const SizedBox(width: 12),
              Text(
                'AI Assistant',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onPrimary,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Powered by AI to help you understand, translate, and interact with your documents.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onPrimary.withOpacity(0.9),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAiCard(
    BuildContext context,
    IconData icon,
    String title,
    String subtitle,
    Color color,
    VoidCallback onTap,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Padding(
            padding: EdgeInsets.all(8),
            child: Icon(Icons.arrow_forward_ios, size: 14),
          ),
        ),
        onTap: onTap,
      ),
    );
  }

  void _navigateTo(BuildContext context, Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => page),
    );
  }

  void _showExtractTables(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Extract Tables'),
        content: const Text('Navigate to the Chat with PDF feature to extract tables from your documents.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              _navigateTo(context, const ChatPage());
            },
            child: const Text('Go to Chat'),
          ),
        ],
      ),
    );
  }

  void _showGenerateTitle(BuildContext context) {
    final cubit = context.read<AIAssistantCubit>();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Generate Title'),
        content: BlocBuilder<AIAssistantCubit, AIState>(
          bloc: cubit,
          builder: (context, state) {
            if (state.currentDocument == null) {
              return const Text('Please load a document first in the Chat with PDF section.');
            }
            if (state.isProcessing && state.currentAction == AIAction.generatingTitle) {
              return const Row(
                children: [
                  SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 16),
                  Text('Generating title...'),
                ],
              );
            }
            if (state.lastResult != null && state.currentAction == AIAction.none) {
              return Text('Generated: ${state.lastResult}');
            }
            return const Text('Generate an AI-powered title for your document.');
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
          FilledButton(
            onPressed: () {
              cubit.generateTitle();
            },
            child: const Text('Generate'),
          ),
        ],
      ),
    );
  }

  void _showGenerateTags(BuildContext context) {
    final cubit = context.read<AIAssistantCubit>();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Generate Tags'),
        content: BlocBuilder<AIAssistantCubit, AIState>(
          bloc: cubit,
          builder: (context, state) {
            if (state.currentDocument == null) {
              return const Text('Please load a document first in the Chat with PDF section.');
            }
            if (state.isProcessing && state.currentAction == AIAction.generatingTags) {
              return const Row(
                children: [
                  SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 16),
                  Text('Generating tags...'),
                ],
              );
            }
            if (state.generatedTags.isNotEmpty) {
              return Wrap(
                spacing: 8,
                runSpacing: 8,
                children: state.generatedTags.map((tag) {
                  return Chip(
                    label: Text(tag),
                    backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                  );
                }).toList(),
              );
            }
            return const Text('Generate AI-powered tags for your document.');
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close'),
          ),
          FilledButton(
            onPressed: () {
              cubit.generateTags();
            },
            child: const Text('Generate'),
          ),
        ],
      ),
    );
  }
}
