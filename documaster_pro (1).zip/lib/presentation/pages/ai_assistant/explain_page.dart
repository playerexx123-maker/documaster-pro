import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../blocs/ai_assistant/ai_assistant_cubit.dart';

class ExplainPage extends StatefulWidget {
  const ExplainPage({super.key});

  @override
  State<ExplainPage> createState() => _ExplainPageState();
}

class _ExplainPageState extends State<ExplainPage> {
  final TextEditingController _textController = TextEditingController();
  final TextEditingController _contextController = TextEditingController();
  String? _lastExplanation;

  @override
  void dispose() {
    _textController.dispose();
    _contextController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Explain Text',
        showBackButton: true,
        actions: [
          if (_lastExplanation != null)
            IconButton(
              icon: const Icon(Icons.copy),
              tooltip: 'Copy',
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Explanation copied to clipboard')),
                );
              },
            ),
        ],
      ),
      body: BlocConsumer<AIAssistantCubit, AIState>(
        listenWhen: (previous, current) =>
            previous.currentAction != current.currentAction ||
            previous.lastResult != current.lastResult,
        listener: (context, state) {
          if (state.currentAction == AIAction.none && state.lastResult != null) {
            setState(() {
              _lastExplanation = state.lastResult;
            });
          }
        },
        builder: (context, state) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Info card
                _buildInfoCard(context),
                const SizedBox(height: 16),

                // Text to explain
                _buildTextInputArea(),
                const SizedBox(height: 16),

                // Optional context
                _buildContextInputArea(),
                const SizedBox(height: 16),

                // Explain button
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: state.isProcessing
                        ? null
                        : () => _explain(context),
                    icon: state.isProcessing && state.currentAction == AIAction.explaining
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.help_outline),
                    label: Text(state.isProcessing && state.currentAction == AIAction.explaining
                        ? 'Analyzing...'
                        : 'Get Explanation'),
                  ),
                ),
                const SizedBox(height: 24),

                // Result
                if (_lastExplanation != null && !state.isProcessing)
                  _buildExplanationResult(context, _lastExplanation!),

                // Quick explain presets
                const Divider(height: 48),
                _buildQuickExplainSection(context),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildInfoCard(BuildContext context) {
    return Card(
      elevation: 0,
      color: Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Theme.of(context).colorScheme.secondaryContainer,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(
              Icons.lightbulb_outline,
              color: Theme.of(context).colorScheme.secondary,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                'Paste complex text and AI will provide a clear, easy-to-understand explanation.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextInputArea() {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.text_fields, size: 18),
                const SizedBox(width: 8),
                Text(
                  'Text to Explain',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _textController,
              maxLines: 6,
              decoration: InputDecoration(
                hintText: 'Paste the text you want explained...',
                filled: true,
                fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContextInputArea() {
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Theme.of(context).colorScheme.outlineVariant,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.article_outlined, size: 18),
                const SizedBox(width: 8),
                Text(
                  'Context (Optional)',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'Provide additional context for a more accurate explanation',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _contextController,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: 'e.g., This is from a legal document about...',
                filled: true,
                fillColor: Theme.of(context).colorScheme.surfaceContainerHighest,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExplanationResult(BuildContext context, String explanation) {
    return Card(
      elevation: 0,
      color: Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.3),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Theme.of(context).colorScheme.secondaryContainer,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.school,
                  size: 18,
                  color: Theme.of(context).colorScheme.secondary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Explanation',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const Divider(),
            const SizedBox(height: 8),
            Text(
              explanation,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickExplainSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Quick Explanations',
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Tap any topic below to get an instant explanation:',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _buildQuickExplainChip(context, 'Machine Learning'),
            _buildQuickExplainChip(context, 'Neural Networks'),
            _buildQuickExplainChip(context, 'Blockchain'),
            _buildQuickExplainChip(context, 'Quantum Computing'),
            _buildQuickExplainChip(context, 'Climate Change'),
            _buildQuickExplainChip(context, 'Photosynthesis'),
          ],
        ),
      ],
    );
  }

  Widget _buildQuickExplainChip(BuildContext context, String topic) {
    return ActionChip(
      avatar: const Icon(Icons.help_outline, size: 16),
      label: Text(topic),
      onPressed: () {
        _textController.text = topic;
        _explain(context);
      },
    );
  }

  void _explain(BuildContext context) {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter text to explain')),
      );
      return;
    }
    context.read<AIAssistantCubit>().explainText(text);
  }
}
