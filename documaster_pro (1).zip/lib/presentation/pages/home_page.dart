import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../config/extensions.dart';
import '../../core/widgets/app_bar.dart';
import '../../core/widgets/bottom_nav.dart';
import '../../core/widgets/loading_indicator.dart';
import '../../core/widgets/empty_state.dart';
import '../../core/widgets/error_state.dart';
import '../../core/widgets/search_bar.dart';
import '../../core/widgets/file_icon.dart';
import '../blocs/home/home_cubit.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<HomeCubit>().loadHomeData();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'DocuMaster Pro',
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
        ],
      ),
      body: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) {
          if (state.isLoading) {
            return const LoadingIndicator(message: 'Loading...');
          }
          if (state.error != null && state.recentFiles.isEmpty) {
            return ErrorState(
              message: state.error!,
              onRetry: () => context.read<HomeCubit>().loadHomeData(),
            );
          }
          return _buildContent(state);
        },
      ),
      bottomNavigationBar: const AppBottomNav(currentIndex: 0),
    );
  }

  Widget _buildContent(HomeState state) {
    return RefreshIndicator(
      onRefresh: () => context.read<HomeCubit>().loadHomeData(),
      child: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: DocuSearchBar(
                controller: _searchController,
                onChanged: (query) {
                  if (query.length > 2) {
                    context.read<HomeCubit>().search(query);
                  } else if (query.isEmpty) {
                    context.read<HomeCubit>().clearSearch();
                  }
                },
              ),
            ),
          ),
          if (state.searchResults.isNotEmpty) ...[
            SliverToBoxAdapter(
              child: _buildSectionHeader('Search Results', () {}),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) => FileListItem(
                  name: state.searchResults[index].name,
                  fileType: state.searchResults[index].fileType,
                  fileSize: state.searchResults[index].fileSize,
                  modifiedAt: state.searchResults[index].updatedAt,
                  onTap: () => _openDocument(state.searchResults[index]),
                ),
                childCount: state.searchResults.length,
              ),
            ),
          ] else ...[
            SliverToBoxAdapter(child: _buildQuickActions()),
            if (state.recentScans.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: _buildSectionHeader('Recent Scans', () {}),
              ),
              SliverToBoxAdapter(
                child: _buildHorizontalScroll(state.recentScans),
              ),
            ],
            if (state.favorites.isNotEmpty) ...[
              SliverToBoxAdapter(
                child: _buildSectionHeader('Favorites', () {}),
              ),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                sliver: SliverGrid(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.8,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (context, index) => _buildDocumentCard(state.favorites[index]),
                    childCount: state.favorites.length,
                  ),
                ),
              ),
            ],
            SliverToBoxAdapter(
              child: _buildSectionHeader('Recent Files', () {}),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => FileListItem(
                    name: state.recentFiles[index].name,
                    fileType: state.recentFiles[index].fileType,
                    fileSize: state.recentFiles[index].fileSize,
                    modifiedAt: state.recentFiles[index].updatedAt,
                    onTap: () => _openDocument(state.recentFiles[index]),
                  ),
                  childCount: state.recentFiles.length,
                ),
              ),
            ),
          ],
          const SliverPadding(padding: EdgeInsets.only(bottom: 32)),
        ],
      ),
    );
  }

  Widget _buildQuickActions() {
    final actions = [
      _QuickAction(Icons.document_scanner, 'Scan', '/scanner', Colors.blue),
      _QuickAction(Icons.file_upload, 'Import', null, Colors.green),
      _QuickAction(Icons.create_new_folder, 'Folder', null, Colors.orange),
      _QuickAction(Icons.transform, 'Convert', '/converter', Colors.purple),
      _QuickAction(Icons.more_horiz, 'More', null, Colors.grey),
    ];

    return Container(
      height: 100,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: actions.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final action = actions[index];
          return Column(
            children: [
              InkWell(
                onTap: action.route != null
                    ? () => context.push(action.route!)
                    : () {},
                borderRadius: BorderRadius.circular(20),
                child: Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: action.color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Icon(action.icon, color: action.color),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                action.label,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSectionHeader(String title, VoidCallback onSeeAll) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          TextButton(
            onPressed: onSeeAll,
            child: const Text('See All'),
          ),
        ],
      ),
    );
  }

  Widget _buildHorizontalScroll(List<dynamic> items) {
    return SizedBox(
      height: 180,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) => _buildDocumentCard(items[index]),
      ),
    );
  }

  Widget _buildDocumentCard(dynamic doc) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _openDocument(doc),
        child: SizedBox(
          width: 140,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Container(
                  width: double.infinity,
                  color: doc.fileType.color.withOpacity(0.1),
                  child: Icon(
                    doc.fileType.icon,
                    size: 48,
                    color: doc.fileType.color,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      doc.name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    Text(
                      doc.fileSize.fileSize,
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openDocument(dynamic doc) {
    context.push('/editor?path=${Uri.encodeComponent(doc.filePath)}');
  }
}

class _QuickAction {
  final IconData icon;
  final String label;
  final String? route;
  final Color color;

  _QuickAction(this.icon, this.label, this.route, this.color);
}
