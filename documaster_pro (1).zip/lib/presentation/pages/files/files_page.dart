import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/bottom_nav.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/file_icon.dart';
import '../../../config/extensions.dart';
import '../../blocs/files/files_cubit.dart';
import 'file_search_page.dart';

class FilesPage extends StatefulWidget {
  const FilesPage({super.key});

  @override
  State<FilesPage> createState() => _FilesPageState();
}

class _FilesPageState extends State<FilesPage> {
  @override
  void initState() {
    super.initState();
    context.read<FilesCubit>().loadFiles();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'My Files',
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => _openSearch(context),
          ),
          _buildSortMenu(),
          _buildViewToggle(),
        ],
      ),
      body: BlocConsumer<FilesCubit, FilesState>(
        listenWhen: (previous, current) => current.error != null && previous.error != current.error,
        listener: (context, state) {
          if (state.error != null) {
            context.showSnackBar(state.error!, isError: true);
            context.read<FilesCubit>().clearError();
          }
        },
        builder: (context, state) {
          if (state.isLoading) {
            return const LoadingIndicator();
          }
          if (state.folders.isEmpty && state.documents.isEmpty) {
            return EmptyState(
              icon: Icons.folder_open,
              title: 'No files yet',
              subtitle: 'Import documents or scan to get started',
              action: FilledButton.icon(
                onPressed: () => _showAddOptions(context),
                icon: const Icon(Icons.add),
                label: const Text('Add Files'),
              ),
            );
          }
          return Column(
            children: [
              if (state.currentPath.isNotEmpty) _buildBreadcrumbs(state),
              Expanded(
                child: state.viewMode == ViewMode.list
                    ? _buildListView(state)
                    : _buildGridView(state),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddOptions(context),
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: const AppBottomNav(currentIndex: 2),
    );
  }

  Widget _buildSortMenu() {
    return PopupMenuButton<SortOption>(
      icon: const Icon(Icons.sort),
      tooltip: 'Sort',
      onSelected: (option) => context.read<FilesCubit>().setSortOption(option),
      itemBuilder: (context) => [
        const PopupMenuItem(value: SortOption.name, child: Text('Sort by Name')),
        const PopupMenuItem(value: SortOption.date, child: Text('Sort by Date')),
        const PopupMenuItem(value: SortOption.size, child: Text('Sort by Size')),
        const PopupMenuItem(value: SortOption.type, child: Text('Sort by Type')),
      ],
    );
  }

  Widget _buildViewToggle() {
    return BlocBuilder<FilesCubit, FilesState>(
      buildWhen: (prev, curr) => prev.viewMode != curr.viewMode,
      builder: (context, state) {
        return IconButton(
          icon: Icon(state.viewMode == ViewMode.list ? Icons.grid_view : Icons.list),
          onPressed: () => context.read<FilesCubit>().toggleViewMode(),
        );
      },
    );
  }

  Widget _buildBreadcrumbs(FilesState state) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: context.colors.surfaceContainerHighest.withOpacity(0.3),
        border: Border(
          bottom: BorderSide(color: context.colors.outlineVariant.withOpacity(0.5)),
        ),
      ),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: state.currentPath.length + 1,
        separatorBuilder: (_, __) => const Icon(Icons.chevron_right, size: 18),
        itemBuilder: (context, index) {
          if (index == 0) {
            return InkWell(
              onTap: () => context.read<FilesCubit>().loadFiles(folderId: null),
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Row(
                  children: [
                    Icon(Icons.home, size: 16),
                    SizedBox(width: 4),
                    Text('Home'),
                  ],
                ),
              ),
            );
          }
          final folder = state.currentPath[index - 1];
          final isLast = index == state.currentPath.length;
          return InkWell(
            onTap: isLast ? null : () => context.read<FilesCubit>().loadFiles(folderId: folder.id),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                folder.name,
                style: TextStyle(
                  color: isLast ? context.colors.onSurface : context.colors.primary,
                  fontWeight: isLast ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildListView(FilesState state) {
    final itemCount = state.folders.length + state.documents.length;
    return ListView.builder(
      itemCount: itemCount,
      itemBuilder: (context, index) {
        if (index < state.folders.length) {
          return _buildFolderListTile(state.folders[index]);
        }
        final doc = state.documents[index - state.folders.length];
        return FileListItem(
          name: doc.name,
          fileType: doc.fileType,
          fileSize: doc.fileSize,
          modifiedAt: doc.updatedAt,
          onTap: () => _onDocumentTap(context, doc),
          onMore: () => _showDocumentOptions(context, doc),
        );
      },
    );
  }

  Widget _buildGridView(FilesState state) {
    final items = [...state.folders, ...state.documents];
    return GridView.builder(
      padding: const EdgeInsets.all(12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.85,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        if (item is dynamic && item.runtimeType.toString().contains('Folder')) {
          return _buildFolderGridCard(item);
        }
        // Document grid card
        return _buildDocumentGridCard(item);
      },
    );
  }

  Widget _buildFolderListTile(dynamic folder) {
    final color = Color(int.parse(folder.color.replaceFirst('#', '0xFF')));
    return ListTile(
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(Icons.folder, color: color),
      ),
      title: Text(folder.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text(
        '${folder.children.length} folders · ${folder.documents.length} files',
        style: Theme.of(context).textTheme.bodySmall,
      ),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => context.read<FilesCubit>().loadFiles(folderId: folder.id),
      onLongPress: () => _showFolderOptions(context, folder),
    );
  }

  Widget _buildFolderGridCard(dynamic folder) {
    final color = Color(int.parse(folder.color.replaceFirst('#', '0xFF')));
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => context.read<FilesCubit>().loadFiles(folderId: folder.id),
        onLongPress: () => _showFolderOptions(context, folder),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.folder, size: 56, color: color),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                folder.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '${folder.documents.length} files',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDocumentGridCard(dynamic doc) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => _onDocumentTap(context, doc),
        onLongPress: () => _showDocumentOptions(context, doc),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FileIcon(fileType: doc.fileType, size: 56),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Text(
                doc.name,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              doc.fileSize.fileSize,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }

  void _onDocumentTap(BuildContext context, dynamic doc) {
    context.read<FilesCubit>().openFile(doc.filePath);
  }

  void _showDocumentOptions(BuildContext context, dynamic doc) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(doc.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(doc.fileSize.fileSize),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.open_in_new),
              title: const Text('Open'),
              onTap: () {
                Navigator.pop(ctx);
                context.read<FilesCubit>().openFile(doc.filePath);
              },
            ),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Share'),
              onTap: () {
                Navigator.pop(ctx);
                context.read<FilesCubit>().shareFile(doc.filePath);
              },
            ),
            ListTile(
              leading: Icon(doc.isFavorite ? Icons.favorite : Icons.favorite_border),
              title: Text(doc.isFavorite ? 'Remove Favorite' : 'Add Favorite'),
              onTap: () {
                Navigator.pop(ctx);
                context.read<FilesCubit>().toggleFavorite(doc.id);
              },
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('Rename'),
              onTap: () {
                Navigator.pop(ctx);
                _showRenameDialog(context, doc.id, doc.name);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: Colors.red),
              title: const Text('Delete', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                _showDeleteConfirm(context, doc.id, doc.name);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showFolderOptions(BuildContext context, dynamic folder) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(title: Text(folder.name)),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.open_in_new),
              title: const Text('Open'),
              onTap: () {
                Navigator.pop(ctx);
                context.read<FilesCubit>().loadFiles(folderId: folder.id);
              },
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('Rename'),
              onTap: () {
                Navigator.pop(ctx);
                _showRenameFolderDialog(context, folder.id, folder.name);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showRenameDialog(BuildContext context, int id, String currentName) {
    final controller = TextEditingController(text: currentName);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename Document'),
        content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'New name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                context.read<FilesCubit>().renameDocument(id, controller.text);
              }
              Navigator.pop(ctx);
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  void _showRenameFolderDialog(BuildContext context, int id, String currentName) {
    final controller = TextEditingController(text: currentName);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename Folder'),
        content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(hintText: 'New name')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                // Would need a rename folder use case
              }
              Navigator.pop(ctx);
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirm(BuildContext context, int id, String name) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Document?'),
        content: Text('Are you sure you want to delete "$name"? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              context.read<FilesCubit>().deleteDocument(id);
              Navigator.pop(ctx);
            },
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showAddOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.create_new_folder),
              title: const Text('Create Folder'),
              onTap: () {
                Navigator.pop(ctx);
                _showCreateFolderDialog(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_upload),
              title: const Text('Import Files'),
              onTap: () => Navigator.pop(ctx),
            ),
            ListTile(
              leading: const Icon(Icons.document_scanner),
              title: const Text('Scan Document'),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  void _showCreateFolderDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Folder'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Folder name'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                context.read<FilesCubit>().createFolder(controller.text);
              }
              Navigator.pop(ctx);
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }

  void _openSearch(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const FileSearchPage()),
    );
  }
}
