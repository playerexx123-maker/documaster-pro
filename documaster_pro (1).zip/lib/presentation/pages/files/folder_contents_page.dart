import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/widgets/file_icon.dart';
import '../../../config/extensions.dart';
import '../../blocs/files/files_cubit.dart';

class FolderContentsPage extends StatefulWidget {
  final int folderId;

  const FolderContentsPage({super.key, required this.folderId});

  @override
  State<FolderContentsPage> createState() => _FolderContentsPageState();
}

class _FolderContentsPageState extends State<FolderContentsPage> {
  @override
  void initState() {
    super.initState();
    // Load folder contents
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<FilesCubit>().loadFiles(folderId: widget.folderId);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: BlocBuilder<FilesCubit, FilesState>(
        builder: (context, state) {
          final folderName = state.currentPath.isNotEmpty
              ? state.currentPath.last.name
              : 'Folder';
          return DocuMasterAppBar(
            title: folderName,
            showBackButton: true,
            actions: [
              IconButton(
                icon: const Icon(Icons.search),
                onPressed: () {},
              ),
              PopupMenuButton<SortOption>(
                icon: const Icon(Icons.sort),
                onSelected: (option) => context.read<FilesCubit>().setSortOption(option),
                itemBuilder: (context) => [
                  const PopupMenuItem(value: SortOption.name, child: Text('Sort by Name')),
                  const PopupMenuItem(value: SortOption.date, child: Text('Sort by Date')),
                  const PopupMenuItem(value: SortOption.size, child: Text('Sort by Size')),
                  const PopupMenuItem(value: SortOption.type, child: Text('Sort by Type')),
                ],
              ),
            ],
          );
        },
      ),
      body: BlocConsumer<FilesCubit, FilesState>(
        listenWhen: (previous, current) => current.error != null && previous.error != current.error,
        listener: (context, state) {
          if (state.error != null) {
            context.showSnackBar(state.error!, isError: true);
            context.read<FilesCubit>().clearError();
          }
        },
        builder: (context, state) {
          if (state.isLoading) {
            return const LoadingIndicator();
          }

          return Column(
            children: [
              // Breadcrumb navigation
              _buildBreadcrumbs(state),
              // Content
              Expanded(
                child: state.folders.isEmpty && state.documents.isEmpty
                    ? EmptyState(
                        icon: Icons.folder_open,
                        title: 'Empty folder',
                        subtitle: 'This folder contains no files or subfolders',
                        action: FilledButton.icon(
                          onPressed: () => _showAddOptions(context),
                          icon: const Icon(Icons.add),
                          label: const Text('Add Files'),
                        ),
                      )
                    : _buildContentList(state),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddOptions(context),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBreadcrumbs(FilesState state) {
    return Container(
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.3),
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).colorScheme.outlineVariant.withOpacity(0.5),
          ),
        ),
      ),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: (state.currentPath.length) + 1,
        separatorBuilder: (_, __) => const Icon(Icons.chevron_right, size: 16),
        itemBuilder: (context, index) {
          if (index == 0) {
            return InkWell(
              onTap: () => Navigator.of(context).maybePop(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Row(
                  children: [
                    Icon(Icons.home, size: 14, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(width: 2),
                    Text(
                      'Home',
                      style: TextStyle(
                        fontSize: 13,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
            );
          }

          final folder = state.currentPath[index - 1];
          final isLast = index == state.currentPath.length;

          return InkWell(
            onTap: isLast
                ? null
                : () {
                    // Navigate to parent folder
                    context.read<FilesCubit>().loadFiles(folderId: folder.id);
                  },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                folder.name,
                style: TextStyle(
                  fontSize: 13,
                  color: isLast
                      ? Theme.of(context).colorScheme.onSurface
                      : Theme.of(context).colorScheme.primary,
                  fontWeight: isLast ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildContentList(FilesState state) {
    final totalItems = state.folders.length + state.documents.length;

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemCount: totalItems,
      itemBuilder: (context, index) {
        // Folders first
        if (index < state.folders.length) {
          final folder = state.folders[index];
          return _buildFolderTile(folder);
        }

        // Then documents
        final docIndex = index - state.folders.length;
        final doc = state.documents[docIndex];
        return FileListItem(
          name: doc.name,
          fileType: doc.fileType,
          fileSize: doc.fileSize,
          modifiedAt: doc.updatedAt,
          onTap: () => _onDocumentTap(doc.filePath),
          onMore: () => _showDocumentOptions(doc),
        );
      },
    );
  }

  Widget _buildFolderTile(dynamic folder) {
    final color = Color(int.parse(folder.color.replaceFirst('#', '0xFF')));

    return ListTile(
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(Icons.folder, color: color),
      ),
      title: Text(
        folder.name,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Text(
        '${folder.children.length} folders · ${folder.documents.length} files',
        style: Theme.of(context).textTheme.bodySmall,
      ),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {
        context.read<FilesCubit>().loadFiles(folderId: folder.id);
      },
    );
  }

  void _onDocumentTap(String filePath) {
    context.read<FilesCubit>().openFile(filePath);
  }

  void _showDocumentOptions(dynamic doc) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(doc.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text(doc.fileSize.fileSize),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.open_in_new),
              title: const Text('Open'),
              onTap: () {
                Navigator.pop(ctx);
                _onDocumentTap(doc.filePath);
              },
            ),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Share'),
              onTap: () {
                Navigator.pop(ctx);
                context.read<FilesCubit>().shareFile(doc.filePath);
              },
            ),
            ListTile(
              leading: Icon(doc.isFavorite ? Icons.favorite : Icons.favorite_border),
              title: Text(doc.isFavorite ? 'Remove Favorite' : 'Add Favorite'),
              onTap: () {
                Navigator.pop(ctx);
                context.read<FilesCubit>().toggleFavorite(doc.id);
              },
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('Rename'),
              onTap: () {
                Navigator.pop(ctx);
                _showRenameDialog(doc.id, doc.name);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: Colors.red),
              title: const Text('Delete', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(ctx);
                _showDeleteConfirm(doc.id, doc.name);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showRenameDialog(int id, String currentName) {
    final controller = TextEditingController(text: currentName);
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename Document'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'New name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                context.read<FilesCubit>().renameDocument(id, controller.text);
              }
              Navigator.pop(ctx);
            },
            child: const Text('Rename'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirm(int id, String name) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Document?'),
        content: Text('Are you sure you want to delete "$name"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              context.read<FilesCubit>().deleteDocument(id);
              Navigator.pop(ctx);
            },
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _showAddOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.create_new_folder),
              title: const Text('Create Folder'),
              onTap: () {
                Navigator.pop(ctx);
                _showCreateFolderDialog(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.file_upload),
              title: const Text('Import Files'),
              onTap: () => Navigator.pop(ctx),
            ),
            ListTile(
              leading: const Icon(Icons.document_scanner),
              title: const Text('Scan Document'),
              onTap: () => Navigator.pop(ctx),
            ),
          ],
        ),
      ),
    );
  }

  void _showCreateFolderDialog(BuildContext context) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New Folder'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Folder name'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.isNotEmpty) {
                context.read<FilesCubit>().createFolder(controller.text);
              }
              Navigator.pop(ctx);
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
  }
}
