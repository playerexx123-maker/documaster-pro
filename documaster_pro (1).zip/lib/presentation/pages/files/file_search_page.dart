import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/file_icon.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../config/extensions.dart';
import '../../blocs/search/search_cubit.dart';

class FileSearchPage extends StatefulWidget {
  const FileSearchPage({super.key});

  @override
  State<FileSearchPage> createState() => _FileSearchPageState();
}

class _FileSearchPageState extends State<FileSearchPage> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocus = FocusNode();

  @override
  void initState() {
    super.initState();
    // Load recent searches
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<SearchCubit>().loadRecentSearches();
      // Auto-focus the search field
      _searchFocus.requestFocus();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _searchController,
          focusNode: _searchFocus,
          decoration: InputDecoration(
            hintText: 'Search files, PDF content, OCR text...',
            border: InputBorder.none,
            hintStyle: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant),
            suffixIcon: _searchController.text.isNotEmpty
                ? IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () {
                      _searchController.clear();
                      context.read<SearchCubit>().clearSearch();
                      setState(() {});
                    },
                  )
                : null,
          ),
          style: Theme.of(context).textTheme.titleMedium,
          textInputAction: TextInputAction.search,
          onSubmitted: (query) => context.read<SearchCubit>().search(query),
          onChanged: (_) => setState(() {}),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: _buildFilterChips(),
        ),
      ),
      body: BlocConsumer<SearchCubit, SearchState>(
        listenWhen: (previous, current) =>
            current.error != null && previous.error != current.error,
        listener: (context, state) {
          if (state.error != null) {
            context.showSnackBar(state.error!, isError: true);
            context.read<SearchCubit>().clearError();
          }
        },
        builder: (context, state) {
          if (state.isLoading) {
            return const LoadingIndicator();
          }

          // Show recent searches if no search has been made
          if (!state.hasSearched) {
            return _buildRecentSearches(state);
          }

          // Show results
          if (state.results.isEmpty) {
            return EmptyState(
              icon: Icons.search_off,
              title: 'No results found',
              subtitle: state.currentQuery != null
                  ? 'No matches for "${state.currentQuery}"'
                  : 'Try a different search term',
            );
          }

          return _buildSearchResults(state);
        },
      ),
    );
  }

  Widget _buildFilterChips() {
    return BlocBuilder<SearchCubit, SearchState>(
      buildWhen: (prev, curr) => prev.filter != curr.filter,
      builder: (context, state) {
        return Container(
          height: 48,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: ListView(
            scrollDirection: Axis.horizontal,
            children: [
              _FilterChip(
                label: 'All',
                icon: Icons.search,
                isActive: state.filter == SearchFilter.all,
                onTap: () => context.read<SearchCubit>().searchWithFilter(SearchFilter.all),
              ),
              _FilterChip(
                label: 'Files',
                icon: Icons.insert_drive_file,
                isActive: state.filter == SearchFilter.files,
                onTap: () => context.read<SearchCubit>().searchWithFilter(SearchFilter.files),
              ),
              _FilterChip(
                label: 'PDF',
                icon: Icons.picture_as_pdf,
                isActive: state.filter == SearchFilter.pdf,
                onTap: () => context.read<SearchCubit>().searchWithFilter(SearchFilter.pdf),
              ),
              _FilterChip(
                label: 'OCR',
                icon: Icons.text_fields,
                isActive: state.filter == SearchFilter.ocr,
                onTap: () => context.read<SearchCubit>().searchWithFilter(SearchFilter.ocr),
              ),
              _FilterChip(
                label: 'Tags',
                icon: Icons.label,
                isActive: state.filter == SearchFilter.tags,
                onTap: () => context.read<SearchCubit>().searchWithFilter(SearchFilter.tags),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRecentSearches(SearchState state) {
    if (state.recentSearches.isEmpty) {
      return EmptyState(
        icon: Icons.history,
        title: 'Search your documents',
        subtitle: 'Search by file name, PDF content, OCR text, or tags',
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Recent Searches',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
            ),
            TextButton(
              onPressed: () {
                // Would need a clear recent searches use case
              },
              child: const Text('Clear'),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ...state.recentSearches.map((search) => ListTile(
              leading: const Icon(Icons.history, size: 20),
              title: Text(search),
              trailing: IconButton(
                icon: const Icon(Icons.north_west, size: 16),
                onPressed: () {
                  _searchController.text = search;
                  context.read<SearchCubit>().search(search);
                },
              ),
              onTap: () {
                _searchController.text = search;
                context.read<SearchCubit>().search(search);
              },
            )),
      ],
    );
  }

  Widget _buildSearchResults(SearchState state) {
    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: state.results.length,
      itemBuilder: (context, index) {
        final result = state.results[index];
        return _buildResultTile(result);
      },
    );
  }

  Widget _buildResultTile(dynamic result) {
    final type = result.type;
    final icon = _getResultTypeIcon(type);
    final color = _getResultTypeColor(type);

    return ListTile(
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: color),
      ),
      title: Text(
        result.documentName,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (result.snippet.isNotEmpty && result.snippet != result.documentName)
            Text(
              result.snippet,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          const SizedBox(height: 2),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  _getResultTypeLabel(type),
                  style: TextStyle(
                    fontSize: 10,
                    color: color,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      onTap: () {
        // Navigate to document or open it
      },
    );
  }

  IconData _getResultTypeIcon(dynamic type) {
    switch (type.toString()) {
      case 'SearchResultType.filename':
        return Icons.insert_drive_file;
      case 'SearchResultType.pdfContent':
        return Icons.picture_as_pdf;
      case 'SearchResultType.ocrText':
        return Icons.text_snippet;
      case 'SearchResultType.tag':
        return Icons.label;
      case 'SearchResultType.note':
        return Icons.note;
      default:
        return Icons.search;
    }
  }

  Color _getResultTypeColor(dynamic type) {
    switch (type.toString()) {
      case 'SearchResultType.filename':
        return Colors.blue;
      case 'SearchResultType.pdfContent':
        return Colors.red;
      case 'SearchResultType.ocrText':
        return Colors.green;
      case 'SearchResultType.tag':
        return Colors.orange;
      case 'SearchResultType.note':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  String _getResultTypeLabel(dynamic type) {
    switch (type.toString()) {
      case 'SearchResultType.filename':
        return 'FILE';
      case 'SearchResultType.pdfContent':
        return 'PDF';
      case 'SearchResultType.ocrText':
        return 'OCR';
      case 'SearchResultType.tag':
        return 'TAG';
      case 'SearchResultType.note':
        return 'NOTE';
      default:
        return 'SEARCH';
    }
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isActive;
  final VoidCallback onTap;

  const _FilterChip({
    required this.label,
    required this.icon,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: isActive
                ? Theme.of(context).colorScheme.primaryContainer
                : Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.5),
            borderRadius: BorderRadius.circular(20),
            border: isActive
                ? Border.all(color: Theme.of(context).colorScheme.primary)
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 14,
                color: isActive
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              const SizedBox(width: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  color: isActive
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.onSurfaceVariant,
                  fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
