import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../config/extensions.dart';
import 'converter_page.dart';

/// Page shown after a conversion completes successfully
class ConversionResultPage extends StatelessWidget {
  final ConversionTool tool;
  final String sourcePath;
  final String sourceName;

  const ConversionResultPage({
    super.key,
    required this.tool,
    required this.sourcePath,
    required this.sourceName,
  });

  @override
  Widget build(BuildContext context) {
    final outputName = _getOutputName();
    final outputExt = _getOutputExtension();

    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Conversion Complete',
        showBackButton: true,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Success icon
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.green.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check_circle,
                  size: 48,
                  color: Colors.green,
                ),
              ),
              const SizedBox(height: 24),

              // Success text
              Text(
                'Conversion Successful!',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                'Your file has been converted successfully.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
              const SizedBox(height: 32),

              // File details card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildDetailRow('Source', sourceName),
                      const Divider(),
                      _buildDetailRow('Output', '$outputName.$outputExt'),
                      const Divider(),
                      _buildDetailRow('Type', _getConversionLabel()),
                      const Divider(),
                      _buildDetailRow('Location', '/Exports/'),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 32),

              // Action buttons
              FilledButton.icon(
                onPressed: () => _openFile(context),
                icon: const Icon(Icons.open_in_new),
                label: const Text('Open File'),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => _shareFile(context),
                icon: const Icon(Icons.share),
                label: const Text('Share'),
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () {
                  // Navigate back to converter home
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
                child: const Text('Convert Another File'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              color: Colors.grey,
            ),
          ),
          Flexible(
            child: Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.end,
            ),
          ),
        ],
      ),
    );
  }

  String _getOutputName() {
    final nameWithoutExt = sourceName.contains('.')
        ? sourceName.substring(0, sourceName.lastIndexOf('.'))
        : sourceName;
    return '${nameWithoutExt}_converted';
  }

  String _getOutputExtension() {
    switch (tool) {
      case ConversionTool.imageToPdf:
      case ConversionTool.wordToPdf:
      case ConversionTool.excelToPdf:
      case ConversionTool.powerPointToPdf:
      case ConversionTool.textToPdf:
        return 'pdf';
      case ConversionTool.pdfToImages:
        return 'png';
      case ConversionTool.pdfToText:
        return 'txt';
    }
  }

  String _getConversionLabel() {
    switch (tool) {
      case ConversionTool.imageToPdf:
        return 'Images → PDF';
      case ConversionTool.wordToPdf:
        return 'Word → PDF';
      case ConversionTool.excelToPdf:
        return 'Excel → PDF';
      case ConversionTool.powerPointToPdf:
        return 'PowerPoint → PDF';
      case ConversionTool.textToPdf:
        return 'Text → PDF';
      case ConversionTool.pdfToImages:
        return 'PDF → Images';
      case ConversionTool.pdfToText:
        return 'PDF → Text';
    }
  }

  void _openFile(BuildContext context) {
    context.showSnackBar('Opening file...');
  }

  void _shareFile(BuildContext context) {
    context.showSnackBar('Sharing file...');
  }
}

/// Page for batch conversion - convert multiple files at once
class BatchConversionPage extends StatefulWidget {
  final ConversionTool tool;

  const BatchConversionPage({super.key, required this.tool});

  @override
  State<BatchConversionPage> createState() => _BatchConversionPageState();
}

class _BatchConversionPageState extends State<BatchConversionPage> {
  final List<String> _selectedFiles = [];
  bool _isConverting = false;
  int _completedCount = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Batch ${_getToolTitle()}',
        showBackButton: true,
        actions: [
          if (_selectedFiles.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear_all),
              onPressed: () => setState(() => _selectedFiles.clear()),
              tooltip: 'Clear all',
            ),
        ],
      ),
      body: _selectedFiles.isEmpty
          ? EmptyState(
              icon: Icons.folder_open,
              title: 'No files selected',
              subtitle: 'Add files to start batch conversion',
              action: FilledButton.icon(
                onPressed: _addFiles,
                icon: const Icon(Icons.add),
                label: const Text('Add Files'),
              ),
            )
          : _buildFileList(),
      floatingActionButton: _selectedFiles.isNotEmpty
          ? FloatingActionButton(
              onPressed: _isConverting ? null : _startBatchConversion,
              child: _isConverting
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.play_arrow),
            )
          : FloatingActionButton(
              onPressed: _addFiles,
              child: const Icon(Icons.add),
            ),
    );
  }

  Widget _buildFileList() {
    return Column(
      children: [
        if (_isConverting) ...[
          LinearProgressIndicator(
            value: _selectedFiles.isEmpty ? 0 : _completedCount / _selectedFiles.length,
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              'Converting $_completedCount of ${_selectedFiles.length}...',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
        Expanded(
          child: ListView.builder(
            itemCount: _selectedFiles.length,
            itemBuilder: (context, index) {
              final file = _selectedFiles[index];
              final fileName = file.split('/').last;
              return ListTile(
                leading: const Icon(Icons.insert_drive_file),
                title: Text(fileName, maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: !_isConverting
                    ? IconButton(
                        icon: const Icon(Icons.remove_circle, color: Colors.red),
                        onPressed: () => setState(() => _selectedFiles.removeAt(index)),
                      )
                    : index < _completedCount
                        ? const Icon(Icons.check_circle, color: Colors.green)
                        : const SizedBox.shrink(),
              );
            },
          ),
        ),
      ],
    );
  }

  Future<void> _addFiles() async {
    // Would use file_picker for multi-file selection
    setState(() {
      _selectedFiles.addAll([
        '/storage/example1.jpg',
        '/storage/example2.jpg',
      ]);
    });
  }

  Future<void> _startBatchConversion() async {
    setState(() {
      _isConverting = true;
      _completedCount = 0;
    });

    for (int i = 0; i < _selectedFiles.length; i++) {
      await Future.delayed(const Duration(milliseconds: 500));
      if (mounted) {
        setState(() => _completedCount = i + 1);
      }
    }

    if (mounted) {
      setState(() => _isConverting = false);
      context.showSnackBar('Batch conversion complete! $_completedCount files converted.');
    }
  }

  String _getToolTitle() {
    switch (widget.tool) {
      case ConversionTool.imageToPdf:
        return 'Images to PDF';
      case ConversionTool.pdfToImages:
        return 'PDF to Images';
      case ConversionTool.wordToPdf:
        return 'Word to PDF';
      case ConversionTool.excelToPdf:
        return 'Excel to PDF';
      case ConversionTool.powerPointToPdf:
        return 'PowerPoint to PDF';
      case ConversionTool.textToPdf:
        return 'Text to PDF';
      case ConversionTool.pdfToText:
        return 'PDF to Text';
    }
  }
}
