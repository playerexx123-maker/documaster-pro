import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../config/extensions.dart';
import 'conversion_result_page.dart';

/// Main converter hub page - lists all available conversion tools
class ConverterPage extends StatelessWidget {
  const ConverterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DocuMasterAppBar(
        title: 'Convert Documents',
        showBackButton: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Convert to PDF',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          _ConversionCard(
            icon: Icons.image,
            color: Colors.purple,
            title: 'Images to PDF',
            subtitle: 'Combine JPG, PNG, GIF images into a PDF',
            onTap: () => _navigateToTool(context, ConversionTool.imageToPdf),
          ),
          _ConversionCard(
            icon: Icons.description,
            color: Colors.blue,
            title: 'Word to PDF',
            subtitle: 'Convert DOCX documents to PDF',
            onTap: () => _navigateToTool(context, ConversionTool.wordToPdf),
          ),
          _ConversionCard(
            icon: Icons.table_chart,
            color: Colors.green,
            title: 'Excel to PDF',
            subtitle: 'Convert XLSX spreadsheets to PDF',
            onTap: () => _navigateToTool(context, ConversionTool.excelToPdf),
          ),
          _ConversionCard(
            icon: Icons.slideshow,
            color: Colors.orange,
            title: 'PowerPoint to PDF',
            subtitle: 'Convert PPTX presentations to PDF',
            onTap: () => _navigateToTool(context, ConversionTool.powerPointToPdf),
          ),
          _ConversionCard(
            icon: Icons.text_snippet,
            color: Colors.grey,
            title: 'Text to PDF',
            subtitle: 'Convert TXT, MD, CSV files to PDF',
            onTap: () => _navigateToTool(context, ConversionTool.textToPdf),
          ),
          const SizedBox(height: 16),
          Text(
            'Convert from PDF',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 8),
          _ConversionCard(
            icon: Icons.image,
            color: Colors.indigo,
            title: 'PDF to Images',
            subtitle: 'Extract pages as PNG/JPG images',
            onTap: () => _navigateToTool(context, ConversionTool.pdfToImages),
          ),
          _ConversionCard(
            icon: Icons.text_fields,
            color: Colors.teal,
            title: 'PDF to Text',
            subtitle: 'Extract text content from PDF',
            onTap: () => _navigateToTool(context, ConversionTool.pdfToText),
          ),
        ],
      ),
    );
  }

  void _navigateToTool(BuildContext context, ConversionTool tool) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => ConversionToolPage(tool: tool),
      ),
    );
  }
}

enum ConversionTool {
  imageToPdf,
  pdfToImages,
  wordToPdf,
  excelToPdf,
  powerPointToPdf,
  textToPdf,
  pdfToText,
}

class _ConversionCard extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  const _ConversionCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: color),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Individual conversion tool page
class ConversionToolPage extends StatefulWidget {
  final ConversionTool tool;

  const ConversionToolPage({super.key, required this.tool});

  @override
  State<ConversionToolPage> createState() => _ConversionToolPageState();
}

class _ConversionToolPageState extends State<ConversionToolPage> {
  String? _selectedFilePath;
  String? _selectedFileName;
  bool _isConverting = false;
  double _progress = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: _getToolTitle(),
        showBackButton: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Info card
            _buildInfoCard(),
            const SizedBox(height: 24),

            // File selection area
            Expanded(
              child: _buildFileSelectionArea(),
            ),

            // Progress indicator
            if (_isConverting) ...[
              const SizedBox(height: 16),
              LinearProgressIndicator(value: _progress > 0 ? _progress : null),
              const SizedBox(height: 8),
              Text(
                _progress > 0 ? 'Converting... ${(_progress * 100).toInt()}%' : 'Converting...',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],

            const SizedBox(height: 16),

            // Convert button
            FilledButton.icon(
              onPressed: _selectedFilePath != null && !_isConverting ? _startConversion : null,
              icon: _isConverting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.transform),
              label: Text(_isConverting ? 'Converting...' : 'Convert'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoCard() {
    final info = _getToolInfo();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: info.color.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: info.color.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Icon(info.icon, color: info.color, size: 32),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  info.title,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                const SizedBox(height: 2),
                Text(
                  info.description,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFileSelectionArea() {
    if (_selectedFilePath == null) {
      return InkWell(
        onTap: _pickFile,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: Theme.of(context).colorScheme.outlineVariant,
              style: BorderStyle.solid,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.upload_file,
                size: 48,
                color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.5),
              ),
              const SizedBox(height: 12),
              Text(
                'Tap to select file',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                _getAcceptedExtensions(),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.7),
                    ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineVariant,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.insert_drive_file,
            size: 48,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(
              _selectedFileName ?? 'Unknown file',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleSmall,
            ),
          ),
          const SizedBox(height: 12),
          TextButton.icon(
            onPressed: _pickFile,
            icon: const Icon(Icons.swap_horiz, size: 18),
            label: const Text('Change File'),
          ),
        ],
      ),
    );
  }

  Future<void> _pickFile() async {
    // Would use file_picker here
    // For now, show a dialog to simulate file selection
    setState(() {
      _selectedFilePath = '/storage/example${_getAcceptedExtensions().split(',').first}';
      _selectedFileName = 'example${_getAcceptedExtensions().split(',').first}';
    });
  }

  Future<void> _startConversion() async {
    if (_selectedFilePath == null) return;

    setState(() {
      _isConverting = true;
      _progress = 0;
    });

    // Simulate progress
    for (int i = 1; i <= 10; i++) {
      await Future.delayed(const Duration(milliseconds: 200));
      if (mounted) {
        setState(() {
          _progress = i / 10;
        });
      }
    }

    if (mounted) {
      setState(() {
        _isConverting = false;
        _progress = 1.0;
      });

      // Show result page
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => ConversionResultPage(
            tool: widget.tool,
            sourcePath: _selectedFilePath!,
            sourceName: _selectedFileName!,
          ),
        ),
      );
    }
  }

  String _getToolTitle() {
    switch (widget.tool) {
      case ConversionTool.imageToPdf:
        return 'Images to PDF';
      case ConversionTool.pdfToImages:
        return 'PDF to Images';
      case ConversionTool.wordToPdf:
        return 'Word to PDF';
      case ConversionTool.excelToPdf:
        return 'Excel to PDF';
      case ConversionTool.powerPointToPdf:
        return 'PowerPoint to PDF';
      case ConversionTool.textToPdf:
        return 'Text to PDF';
      case ConversionTool.pdfToText:
        return 'PDF to Text';
    }
  }

  String _getAcceptedExtensions() {
    switch (widget.tool) {
      case ConversionTool.imageToPdf:
        return '.jpg, .jpeg, .png, .gif, .bmp, .webp';
      case ConversionTool.pdfToImages:
        return '.pdf';
      case ConversionTool.wordToPdf:
        return '.docx, .doc';
      case ConversionTool.excelToPdf:
        return '.xlsx, .xls';
      case ConversionTool.powerPointToPdf:
        return '.pptx, .ppt';
      case ConversionTool.textToPdf:
        return '.txt, .md, .csv';
      case ConversionTool.pdfToText:
        return '.pdf';
    }
  }

  ({String title, String description, IconData icon, Color color}) _getToolInfo() {
    switch (widget.tool) {
      case ConversionTool.imageToPdf:
        return (
          title: 'Images to PDF',
          description: 'Combine one or more images into a single PDF document.',
          icon: Icons.image,
          color: Colors.purple,
        );
      case ConversionTool.pdfToImages:
        return (
          title: 'PDF to Images',
          description: 'Extract each page of a PDF as a separate image file.',
          icon: Icons.image,
          color: Colors.indigo,
        );
      case ConversionTool.wordToPdf:
        return (
          title: 'Word to PDF',
          description: 'Convert Word documents (.docx) to PDF format.',
          icon: Icons.description,
          color: Colors.blue,
        );
      case ConversionTool.excelToPdf:
        return (
          title: 'Excel to PDF',
          description: 'Convert Excel spreadsheets (.xlsx) to PDF format.',
          icon: Icons.table_chart,
          color: Colors.green,
        );
      case ConversionTool.powerPointToPdf:
        return (
          title: 'PowerPoint to PDF',
          description: 'Convert PowerPoint presentations (.pptx) to PDF format.',
          icon: Icons.slideshow,
          color: Colors.orange,
        );
      case ConversionTool.textToPdf:
        return (
          title: 'Text to PDF',
          description: 'Convert text files (.txt, .md, .csv) to PDF format.',
          icon: Icons.text_snippet,
          color: Colors.grey,
        );
      case ConversionTool.pdfToText:
        return (
          title: 'PDF to Text',
          description: 'Extract text content from PDF files.',
          icon: Icons.text_fields,
          color: Colors.teal,
        );
    }
  }
}
