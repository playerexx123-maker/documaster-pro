import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// A modal overlay that prompts the user for biometric authentication.
///
/// Can be used as a dialog or a full-screen overlay.
/// Shows biometric icon, title, description, and action buttons.
class BiometricPrompt extends StatefulWidget {
  final String title;
  final String subtitle;
  final String cancelButtonLabel;
  final VoidCallback? onAuthenticate;
  final VoidCallback? onCancel;
  final VoidCallback? onUsePin;

  const BiometricPrompt({
    super.key,
    this.title = 'Authentication Required',
    this.subtitle = 'Please authenticate to access DocuMaster Pro',
    this.cancelButtonLabel = 'Cancel',
    this.onAuthenticate,
    this.onCancel,
    this.onUsePin,
  });

  /// Shows the biometric prompt as a modal bottom sheet.
  static Future<void> showBottomSheet(
    BuildContext context, {
    String title = 'Authentication Required',
    String subtitle = 'Please authenticate to access DocuMaster Pro',
    String cancelButtonLabel = 'Cancel',
    VoidCallback? onAuthenticate,
    VoidCallback? onCancel,
    VoidCallback? onUsePin,
  }) {
    HapticFeedback.mediumImpact();
    return showModalBottomSheet(
      context: context,
      isDismissible: false,
      enableDrag: false,
      backgroundColor: Colors.transparent,
      builder: (context) => BiometricPrompt(
        title: title,
        subtitle: subtitle,
        cancelButtonLabel: cancelButtonLabel,
        onAuthenticate: onAuthenticate,
        onCancel: onCancel ?? () => Navigator.pop(context),
        onUsePin: onUsePin,
      ),
    );
  }

  /// Shows the biometric prompt as a dialog.
  static Future<void> showDialogPrompt(
    BuildContext context, {
    String title = 'Authentication Required',
    String subtitle = 'Please authenticate to access DocuMaster Pro',
    String cancelButtonLabel = 'Cancel',
    VoidCallback? onAuthenticate,
    VoidCallback? onCancel,
    VoidCallback? onUsePin,
  }) {
    HapticFeedback.mediumImpact();
    return showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: BiometricPrompt(
          title: title,
          subtitle: subtitle,
          cancelButtonLabel: cancelButtonLabel,
          onAuthenticate: onAuthenticate,
          onCancel: onCancel ?? () => Navigator.pop(context),
          onUsePin: onUsePin,
        ),
      ),
    );
  }

  @override
  State<BiometricPrompt> createState() => _BiometricPromptState();
}

class _BiometricPromptState extends State<BiometricPrompt>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;
  bool _isAuthenticating = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _pulseAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween(begin: 1.0, end: 1.15)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 1,
      ),
      TweenSequenceItem(
        tween: Tween(begin: 1.15, end: 1.0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 1,
      ),
    ]).animate(_pulseController);

    _pulseController.repeat();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  void _onAuthenticatePressed() {
    HapticFeedback.mediumImpact();
    setState(() {
      _isAuthenticating = true;
    });
    widget.onAuthenticate?.call();
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Container(
      margin: const EdgeInsets.all(24),
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Biometric Icon with pulse animation
          AnimatedBuilder(
            animation: _pulseAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _isAuthenticating ? 1.0 : _pulseAnimation.value,
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: colorScheme.primaryContainer,
                    shape: BoxShape.circle,
                  ),
                  child: _isAuthenticating
                      ? SizedBox(
                          width: 40,
                          height: 40,
                          child: CircularProgressIndicator(
                            strokeWidth: 3,
                            color: colorScheme.primary,
                          ),
                        )
                      : Icon(
                          Icons.fingerprint,
                          size: 40,
                          color: colorScheme.primary,
                        ),
                ),
              );
            },
          ),
          const SizedBox(height: 24),

          // Title
          Text(
            widget.title,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),

          // Subtitle
          Text(
            widget.subtitle,
            textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 32),

          // Authenticate Button
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: _isAuthenticating ? null : _onAuthenticatePressed,
              icon: const Icon(Icons.fingerprint),
              label: Text(
                _isAuthenticating ? 'Authenticating...' : 'Use Biometric',
              ),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),

          // Use PIN Button
          if (widget.onUsePin != null)
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: _isAuthenticating ? null : widget.onUsePin,
                icon: const Icon(Icons.pin_outlined),
                label: const Text('Use PIN Instead'),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 8),

          // Cancel Button
          TextButton(
            onPressed: _isAuthenticating ? null : widget.onCancel,
            child: Text(widget.cancelButtonLabel),
          ),
        ],
      ),
    );
  }
}

/// A full-screen biometric prompt page that can be used as a route.
class BiometricPromptPage extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback? onAuthenticated;
  final VoidCallback? onCancelled;

  const BiometricPromptPage({
    super.key,
    this.title = 'Authentication Required',
    this.subtitle = 'Please authenticate to access DocuMaster Pro',
    this.onAuthenticated,
    this.onCancelled,
  });

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: SafeArea(
        child: Center(
          child: BiometricPrompt(
            title: title,
            subtitle: subtitle,
            onAuthenticate: onAuthenticated,
            onCancel: onCancelled ?? () => Navigator.pop(context),
          ),
        ),
      ),
    );
  }
}
