import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Enum defining the mode of PIN entry.
enum PinEntryMode {
  /// First-time PIN setup (create new PIN).
  setup,
  /// Verify existing PIN (login).
  verify,
  /// Change existing PIN.
  change,
}

/// A full-screen PIN entry page with a numeric keypad.
///
/// Supports setup, verification, and change modes with visual feedback.
class PinEntryPage extends StatefulWidget {
  final PinEntryMode mode;
  final ValueChanged<String>? onPinSet;
  final ValueChanged<String>? onPinVerified;
  final VoidCallback? onCancel;

  const PinEntryPage({
    super.key,
    required this.mode,
    this.onPinSet,
    this.onPinVerified,
    this.onCancel,
  });

  @override
  State<PinEntryPage> createState() => _PinEntryPageState();
}

class _PinEntryPageState extends State<PinEntryPage>
    with SingleTickerProviderStateMixin {
  String _enteredPin = '';
  String? _firstPin;
  String? _errorMessage;
  bool _isProcessing = false;

  late AnimationController _shakeController;
  late Animation<double> _shakeAnimation;

  static const int _pinLength = 4;

  String get _title {
    switch (widget.mode) {
      case PinEntryMode.setup:
        return 'Create PIN';
      case PinEntryMode.verify:
        return 'Enter PIN';
      case PinEntryMode.change:
        return 'Change PIN';
    }
  }

  String get _subtitle {
    if (_errorMessage != null) return _errorMessage!;
    if (widget.mode == PinEntryMode.setup && _firstPin != null) {
      return 'Confirm your PIN';
    }
    switch (widget.mode) {
      case PinEntryMode.setup:
        return 'Enter a $_pinLength-digit PIN';
      case PinEntryMode.verify:
        return 'Enter your PIN to continue';
      case PinEntryMode.change:
        return 'Enter a new $_pinLength-digit PIN';
    }
  }

  @override
  void initState() {
    super.initState();
    _shakeController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _shakeAnimation = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0, end: -10), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -10, end: 10), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10, end: -10), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -10, end: 10), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 10, end: 0), weight: 1),
    ]).animate(_shakeController);
  }

  @override
  void dispose() {
    _shakeController.dispose();
    super.dispose();
  }

  void _onKeyPressed(String key) {
    HapticFeedback.lightImpact();

    if (_enteredPin.length < _pinLength) {
      setState(() {
        _enteredPin += key;
        _errorMessage = null;
      });

      if (_enteredPin.length == _pinLength) {
        _processPin();
      }
    }
  }

  void _onBackspace() {
    HapticFeedback.lightImpact();
    if (_enteredPin.isNotEmpty) {
      setState(() {
        _enteredPin = _enteredPin.substring(0, _enteredPin.length - 1);
        _errorMessage = null;
      });
    }
  }

  void _processPin() {
    if (_isProcessing) return;
    _isProcessing = true;

    switch (widget.mode) {
      case PinEntryMode.setup:
        _handleSetup();
        break;
      case PinEntryMode.verify:
        _handleVerify();
        break;
      case PinEntryMode.change:
        _handleChange();
        break;
    }
  }

  void _handleSetup() {
    if (_firstPin == null) {
      setState(() {
        _firstPin = _enteredPin;
        _enteredPin = '';
        _isProcessing = false;
      });
    } else {
      if (_enteredPin == _firstPin) {
        widget.onPinSet?.call(_enteredPin);
      } else {
        _triggerError('PINs do not match. Try again.');
        setState(() {
          _firstPin = null;
          _enteredPin = '';
          _isProcessing = false;
        });
      }
    }
  }

  void _handleVerify() {
    widget.onPinVerified?.call(_enteredPin);
    setState(() {
      _isProcessing = false;
    });
  }

  void _handleChange() {
    if (_firstPin == null) {
      setState(() {
        _firstPin = _enteredPin;
        _enteredPin = '';
        _isProcessing = false;
      });
    } else {
      if (_enteredPin == _firstPin) {
        widget.onPinSet?.call(_enteredPin);
      } else {
        _triggerError('PINs do not match. Try again.');
        setState(() {
          _firstPin = null;
          _enteredPin = '';
          _isProcessing = false;
        });
      }
    }
  }

  void _triggerError(String message) {
    HapticFeedback.heavyImpact();
    setState(() {
      _errorMessage = message;
    });
    _shakeController.forward(from: 0);
  }

  void _clearPin() {
    setState(() {
      _enteredPin = '';
      _errorMessage = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final isError = _errorMessage != null;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  if (widget.mode != PinEntryMode.verify)
                    TextButton(
                      onPressed: widget.onCancel ?? () => Navigator.pop(context),
                      child: const Text('CANCEL'),
                    )
                  else
                    const SizedBox(width: 80),
                  TextButton(
                    onPressed: _enteredPin.isNotEmpty ? _clearPin : null,
                    child: const Text('CLEAR'),
                  ),
                ],
              ),
            ),

            const Spacer(),

            // Title and Subtitle
            Text(
              _title,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            AnimatedDefaultTextStyle(
              duration: const Duration(milliseconds: 200),
              style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                color: isError ? colorScheme.error : colorScheme.onSurfaceVariant,
              ),
              child: Text(_subtitle),
            ),
            const SizedBox(height: 32),

            // PIN Dots
            AnimatedBuilder(
              animation: _shakeAnimation,
              builder: (context, child) {
                return Transform.translate(
                  offset: Offset(_shakeAnimation.value, 0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(_pinLength, (index) {
                      final isFilled = index < _enteredPin.length;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        margin: const EdgeInsets.symmetric(horizontal: 8),
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isFilled
                              ? (isError ? colorScheme.error : colorScheme.primary)
                              : Colors.transparent,
                          border: Border.all(
                            color: isError
                                ? colorScheme.error
                                : colorScheme.outline,
                            width: 2,
                          ),
                        ),
                      );
                    }),
                  ),
                );
              },
            ),

            const Spacer(),

            // Numeric Keypad
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
              child: Column(
                children: [
                  _buildKeypadRow(['1', '2', '3']),
                  const SizedBox(height: 12),
                  _buildKeypadRow(['4', '5', '6']),
                  const SizedBox(height: 12),
                  _buildKeypadRow(['7', '8', '9']),
                  const SizedBox(height: 12),
                  _buildKeypadRow(['', '0', 'backspace'], isLastRow: true),
                ],
              ),
            ),

            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildKeypadRow(List<String> keys, {bool isLastRow = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: keys.map((key) {
        if (key.isEmpty) {
          return const SizedBox(width: 72, height: 72);
        }
        if (key == 'backspace') {
          return _buildBackspaceKey();
        }
        return _buildNumberKey(key);
      }).toList(),
    );
  }

  Widget _buildNumberKey(String number) {
    final colorScheme = Theme.of(context).colorScheme;

    return Material(
      color: colorScheme.surfaceVariant.withOpacity(0.5),
      borderRadius: BorderRadius.circular(36),
      child: InkWell(
        borderRadius: BorderRadius.circular(36),
        onTap: () => _onKeyPressed(number),
        child: Container(
          width: 72,
          height: 72,
          alignment: Alignment.center,
          child: Text(
            number,
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.w500,
              color: colorScheme.onSurface,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBackspaceKey() {
    final colorScheme = Theme.of(context).colorScheme;

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(36),
      child: InkWell(
        borderRadius: BorderRadius.circular(36),
        onTap: _onBackspace,
        onLongPress: _clearPin,
        child: Container(
          width: 72,
          height: 72,
          alignment: Alignment.center,
          child: Icon(
            Icons.backspace_outlined,
            color: _enteredPin.isEmpty
                ? colorScheme.outline
                : colorScheme.onSurface,
          ),
        ),
      ),
    );
  }
}
