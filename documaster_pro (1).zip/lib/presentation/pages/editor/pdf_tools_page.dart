import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../domain/entities/pdf_annotation.dart';
import '../../blocs/editor/editor_cubit.dart';

class PdfToolsPage extends StatefulWidget {
  final EditorCubit cubit;

  const PdfToolsPage({super.key, required this.cubit});

  @override
  State<PdfToolsPage> createState() => _PdfToolsPageState();
}

class _PdfToolsPageState extends State<PdfToolsPage> {
  int _selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const DocuMasterAppBar(
        title: 'PDF Tools',
        showBackButton: true,
      ),
      body: Column(
        children: [
          // Tab selector
          Padding(
            padding: const EdgeInsets.all(12),
            child: SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Merge'), icon: Icon(Icons.merge_type)),
                ButtonSegment(value: 1, label: Text('Compress'), icon: Icon(Icons.compress)),
                ButtonSegment(value: 2, label: Text('Protect'), icon: Icon(Icons.security)),
                ButtonSegment(value: 3, label: Text('Watermark'), icon: Icon(Icons.water_drop)),
              ],
              selected: {_selectedTab},
              onSelectionChanged: (set) {
                setState(() => _selectedTab = set.first);
              },
            ),
          ),

          // Content area
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: _buildTabContent(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabContent() {
    switch (_selectedTab) {
      case 0:
        return _MergeTab(cubit: widget.cubit);
      case 1:
        return _CompressTab(cubit: widget.cubit);
      case 2:
        return _ProtectTab(cubit: widget.cubit);
      case 3:
        return _WatermarkTab(cubit: widget.cubit);
      default:
        return const SizedBox.shrink();
    }
  }
}

// ─── Merge Tab ───

class _MergeTab extends StatefulWidget {
  final EditorCubit cubit;

  const _MergeTab({required this.cubit});

  @override
  State<_MergeTab> createState() => _MergeTabState();
}

class _MergeTabState extends State<_MergeTab> {
  final List<String> _selectedPaths = [];
  bool _isProcessing = false;

  Future<void> _pickFiles() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      allowMultiple: true,
    );
    if (result != null) {
      setState(() {
        for (final file in result.files) {
          if (file.path != null && !_selectedPaths.contains(file.path!)) {
            _selectedPaths.add(file.path!);
          }
        }
      });
    }
  }

  void _removeFile(int index) {
    setState(() => _selectedPaths.removeAt(index));
  }

  void _reorderFile(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) newIndex--;
      final item = _selectedPaths.removeAt(oldIndex);
      _selectedPaths.insert(newIndex, item);
    });
  }

  Future<void> _merge() async {
    if (_selectedPaths.length < 2) return;
    setState(() => _isProcessing = true);
    await widget.cubit.mergePdfs(_selectedPaths);
    setState(() => _isProcessing = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PDFs merged successfully')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Merge PDFs',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          Text(
            'Select multiple PDFs and arrange them in the desired order.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            icon: const Icon(Icons.add),
            label: const Text('Add PDFs'),
            onPressed: _pickFiles,
          ),
          const SizedBox(height: 12),

          if (_selectedPaths.isNotEmpty) ...[
            Text(
              '${_selectedPaths.length} PDF(s) selected:',
              style: Theme.of(context).textTheme.labelLarge,
            ),
            const SizedBox(height: 8),
            Expanded(
              child: ReorderableListView.builder(
                itemCount: _selectedPaths.length,
                onReorder: _reorderFile,
                itemBuilder: (context, index) {
                  final path = _selectedPaths[index];
                  final fileName = path.split('/').last;
                  return Card(
                    key: ValueKey(path),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
                        child: Text('${index + 1}'),
                      ),
                      title: Text(fileName),
                      subtitle: Text(
                        path,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: () => _removeFile(index),
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: _isProcessing
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.merge_type),
                label: Text(_isProcessing ? 'Merging...' : 'Merge PDFs'),
                onPressed: _isProcessing || _selectedPaths.length < 2 ? null : _merge,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ─── Compress Tab ───

class _CompressTab extends StatefulWidget {
  final EditorCubit cubit;

  const _CompressTab({required this.cubit});

  @override
  State<_CompressTab> createState() => _CompressTabState();
}

class _CompressTabState extends State<_CompressTab> {
  CompressionLevel _level = CompressionLevel.medium;
  bool _isProcessing = false;
  String? _originalSize;
  String? _compressedSize;

  @override
  void initState() {
    super.initState();
    _loadFileSize();
  }

  Future<void> _loadFileSize() async {
    final path = widget.cubit.state.documentPath;
    if (path != null) {
      final file = File(path);
      if (await file.exists()) {
        final size = await file.length();
        setState(() => _originalSize = _formatSize(size));
      }
    }
  }

  String _formatSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  Future<void> _compress() async {
    setState(() => _isProcessing = true);
    await widget.cubit.compressPdf(_level);
    setState(() => _isProcessing = false);

    final path = widget.cubit.state.documentPath;
    if (path != null) {
      final file = File(path);
      if (await file.exists()) {
        final size = await file.length();
        setState(() => _compressedSize = _formatSize(size));
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PDF compressed successfully')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Compress PDF',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 8),
          if (_originalSize != null)
            Text(
              'Original size: $_originalSize',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          if (_compressedSize != null)
            Text(
              'Compressed size: $_compressedSize',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
          const SizedBox(height: 24),
          Text('Compression Level', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 12),
          SegmentedButton<CompressionLevel>(
            segments: const [
              ButtonSegment(
                value: CompressionLevel.low,
                label: Text('Low'),
                icon: Icon(Icons.speed),
              ),
              ButtonSegment(
                value: CompressionLevel.medium,
                label: Text('Medium'),
                icon: Icon(Icons.tune),
              ),
              ButtonSegment(
                value: CompressionLevel.high,
                label: Text('High'),
                icon: Icon(Icons.compress),
              ),
            ],
            selected: {_level},
            onSelectionChanged: (set) => setState(() => _level = set.first),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _LevelInfo(
                    icon: Icons.speed,
                    title: 'Low',
                    description: 'Faster compression, minimal size reduction. Best quality.',
                    isSelected: _level == CompressionLevel.low,
                  ),
                  const Divider(),
                  _LevelInfo(
                    icon: Icons.tune,
                    title: 'Medium',
                    description: 'Balanced compression and quality.',
                    isSelected: _level == CompressionLevel.medium,
                  ),
                  const Divider(),
                  _LevelInfo(
                    icon: Icons.compress,
                    title: 'High',
                    description: 'Maximum compression, smaller file size. May reduce quality.',
                    isSelected: _level == CompressionLevel.high,
                  ),
                ],
              ),
            ),
          ),
          const Spacer(),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: _isProcessing
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.compress),
              label: Text(_isProcessing ? 'Compressing...' : 'Compress PDF'),
              onPressed: _isProcessing ? null : _compress,
            ),
          ),
        ],
      ),
    );
  }
}

class _LevelInfo extends StatelessWidget {
  final IconData icon;
  final String title;
  final String description;
  final bool isSelected;

  const _LevelInfo({
    required this.icon,
    required this.title,
    required this.description,
    required this.isSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color: isSelected
              ? Theme.of(context).colorScheme.primary
              : Theme.of(context).colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w500,
                ),
              ),
              Text(
                description,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── Protect Tab ───

class _ProtectTab extends StatefulWidget {
  final EditorCubit cubit;

  const _ProtectTab({required this.cubit});

  @override
  State<_ProtectTab> createState() => _ProtectTabState();
}

class _ProtectTabState extends State<_ProtectTab> {
  bool _isEncrypt = true;
  final _passwordController = TextEditingController();
  final _confirmController = TextEditingController();
  bool _isProcessing = false;
  bool _obscurePassword = true;

  @override
  void dispose() {
    _passwordController.dispose();
    _confirmController.dispose();
    super.dispose();
  }

  Future<void> _process() async {
    if (_passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a password')),
      );
      return;
    }

    if (_isEncrypt && _passwordController.text != _confirmController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Passwords do not match')),
      );
      return;
    }

    setState(() => _isProcessing = true);

    if (_isEncrypt) {
      await widget.cubit.encryptPdf(_passwordController.text);
    } else {
      await widget.cubit.decryptPdf(_passwordController.text);
    }

    setState(() => _isProcessing = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_isEncrypt ? 'PDF encrypted' : 'PDF decrypted'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Protect PDF',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(
                value: true,
                label: Text('Encrypt'),
                icon: Icon(Icons.lock),
              ),
              ButtonSegment(
                value: false,
                label: Text('Decrypt'),
                icon: Icon(Icons.lock_open),
              ),
            ],
            selected: {_isEncrypt},
            onSelectionChanged: (set) => setState(() => _isEncrypt = set.first),
          ),
          const SizedBox(height: 24),
          TextField(
            controller: _passwordController,
            obscureText: _obscurePassword,
            decoration: InputDecoration(
              labelText: 'Password',
              prefixIcon: const Icon(Icons.password),
              suffixIcon: IconButton(
                icon: Icon(
                  _obscurePassword ? Icons.visibility_off : Icons.visibility,
                ),
                onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (_isEncrypt)
            TextField(
              controller: _confirmController,
              obscureText: _obscurePassword,
              decoration: const InputDecoration(
                labelText: 'Confirm Password',
                prefixIcon: Icon(Icons.password),
              ),
            ),
          const Spacer(),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: _isProcessing
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(_isEncrypt ? Icons.lock : Icons.lock_open),
              label: Text(_isProcessing
                  ? 'Processing...'
                  : (_isEncrypt ? 'Encrypt PDF' : 'Decrypt PDF')),
              onPressed: _isProcessing ? null : _process,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Watermark Tab ───

class _WatermarkTab extends StatefulWidget {
  final EditorCubit cubit;

  const _WatermarkTab({required this.cubit});

  @override
  State<_WatermarkTab> createState() => _WatermarkTabState();
}

class _WatermarkTabState extends State<_WatermarkTab> {
  final _textController = TextEditingController();
  double _fontSize = 48;
  double _opacity = 0.3;
  int _pages = 0; // 0 = all pages
  bool _isProcessing = false;

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  Future<void> _apply() async {
    if (_textController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter watermark text')),
      );
      return;
    }

    setState(() => _isProcessing = true);

    final options = WatermarkOptions(
      text: _textController.text,
      fontSize: _fontSize,
      opacity: _opacity,
      pages: _pages,
    );

    await widget.cubit.addWatermark(options);

    setState(() => _isProcessing = false);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Watermark applied')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Add Watermark',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _textController,
            decoration: const InputDecoration(
              labelText: 'Watermark Text',
              prefixIcon: Icon(Icons.text_fields),
              hintText: 'e.g., CONFIDENTIAL',
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                child: Text('Font Size: ${_fontSize.toInt()}pt'),
              ),
              Expanded(
                flex: 3,
                child: Slider(
                  value: _fontSize,
                  min: 12,
                  max: 96,
                  divisions: 84,
                  label: _fontSize.toStringAsFixed(0),
                  onChanged: (v) => setState(() => _fontSize = v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text('Opacity: ${(_opacity * 100).toInt()}%'),
              ),
              Expanded(
                flex: 3,
                child: Slider(
                  value: _opacity,
                  min: 0.05,
                  max: 1.0,
                  divisions: 19,
                  label: '${(_opacity * 100).toInt()}%',
                  onChanged: (v) => setState(() => _opacity = v),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Preview
          Container(
            width: double.infinity,
            height: 120,
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: Center(
              child: Opacity(
                opacity: _opacity,
                child: Text(
                  _textController.text.isEmpty ? 'Preview' : _textController.text,
                  style: TextStyle(
                    fontSize: _fontSize,
                    color: Colors.grey.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: _isProcessing
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.water_drop),
              label: Text(_isProcessing ? 'Applying...' : 'Apply Watermark'),
              onPressed: _isProcessing ? null : _apply,
            ),
          ),
        ],
      ),
    );
  }
}
