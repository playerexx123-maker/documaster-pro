import 'dart:io';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../../../core/widgets/app_bar.dart';

class PdfViewerPage extends StatefulWidget {
  final String filePath;
  final int initialPage;

  const PdfViewerPage({
    super.key,
    required this.filePath,
    this.initialPage = 1,
  });

  @override
  State<PdfViewerPage> createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends State<PdfViewerPage> {
  final PdfViewerController _controller = PdfViewerController();
  int _currentPage = 1;
  int _totalPages = 0;
  double _zoomLevel = 1.0;
  bool _isUIVisible = true;

  @override
  void initState() {
    super.initState();
    _currentPage = widget.initialPage;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggleUI() {
    setState(() {
      _isUIVisible = !_isUIVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _isUIVisible
          ? DocuMasterAppBar(
              title: 'PDF Viewer',
              showBackButton: true,
              actions: [
                IconButton(
                  icon: const Icon(Icons.zoom_in),
                  onPressed: () {
                    _zoomLevel += 0.25;
                    _controller.zoomValue = _zoomLevel;
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.zoom_out),
                  onPressed: () {
                    _zoomLevel = (_zoomLevel - 0.25).clamp(0.25, 5.0);
                    _controller.zoomValue = _zoomLevel;
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.first_page),
                  onPressed: () => _controller.jumpToPage(1),
                ),
                IconButton(
                  icon: const Icon(Icons.last_page),
                  onPressed: () => _controller.jumpToPage(_totalPages),
                ),
              ],
            )
          : null,
      body: GestureDetector(
        onTap: _toggleUI,
        child: SfPdfViewer.file(
          File(widget.filePath),
          controller: _controller,
          initialPageNumber: widget.initialPage,
          enableDoubleTapZooming: true,
          enableTextSelection: true,
          pageSpacing: 4,
          onPageChanged: (details) {
            setState(() {
              _currentPage = details.newPageNumber;
            });
          },
          onDocumentLoaded: (details) {
            setState(() {
              _totalPages = _controller.pageCount;
            });
          },
        ),
      ),
      bottomNavigationBar: _isUIVisible
          ? Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                border: Border(
                  top: BorderSide(
                    color: Theme.of(context).dividerTheme.color ?? Colors.grey,
                  ),
                ),
              ),
              child: SafeArea(
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.chevron_left),
                      onPressed: _currentPage > 1
                          ? () => _controller.previousPage()
                          : null,
                    ),
                    Expanded(
                      child: Slider(
                        value: _currentPage.toDouble(),
                        min: 1,
                        max: _totalPages > 0 ? _totalPages.toDouble() : 1,
                        divisions: _totalPages > 1 ? _totalPages - 1 : null,
                        label: 'Page $_currentPage',
                        onChanged: (value) {
                          setState(() {
                            _currentPage = value.toInt();
                          });
                          _controller.jumpToPage(_currentPage);
                        },
                      ),
                    ),
                    Text(
                      '$_currentPage / $_totalPages',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    IconButton(
                      icon: const Icon(Icons.chevron_right),
                      onPressed: _currentPage < _totalPages
                          ? () => _controller.nextPage()
                          : null,
                    ),
                  ],
                ),
              ),
            )
          : null,
    );
  }
}
