import 'dart:io';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../domain/entities/pdf_annotation.dart';
import '../../blocs/editor/editor_cubit.dart';

class PageManagerPage extends StatefulWidget {
  final EditorCubit cubit;

  const PageManagerPage({super.key, required this.cubit});

  @override
  State<PageManagerPage> createState() => _PageManagerPageState();
}

class _PageManagerPageState extends State<PageManagerPage> {
  late List<int> _pageOrder;
  List<bool> _selectedPages = [];
  int _totalPages = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadPages();
  }

  Future<void> _loadPages() async {
    final state = widget.cubit.state;
    if (state.documentPath != null) {
      try {
        final file = File(state.documentPath!);
        final bytes = await file.readAsBytes();
        final document = PdfDocument(inputBytes: bytes);
        final count = document.pages.count;
        document.dispose();

        setState(() {
          _totalPages = count;
          _pageOrder = List.generate(count, (i) => i + 1);
          _selectedPages = List.generate(count, (_) => false);
          _isLoading = false;
        });
      } catch (e) {
        setState(() => _isLoading = false);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Failed to load pages: $e')),
          );
        }
      }
    } else {
      setState(() => _isLoading = false);
    }
  }

  void _reorderPage(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) newIndex--;
      final item = _pageOrder.removeAt(oldIndex);
      _pageOrder.insert(newIndex, item);

      final selected = _selectedPages.removeAt(oldIndex);
      _selectedPages.insert(newIndex, selected);
    });
  }

  Future<void> _applyReorder() async {
    final state = widget.cubit.state;
    if (state.documentPath == null) return;

    await widget.cubit.reorderPages(state.documentPath!, _pageOrder);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pages reordered')),
      );
    }
  }

  Future<void> _rotateSelected(Rotation rotation) async {
    final selectedIndices = <int>[];
    for (int i = 0; i < _selectedPages.length; i++) {
      if (_selectedPages[i]) selectedIndices.add(_pageOrder[i]);
    }

    if (selectedIndices.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select at least one page')),
      );
      return;
    }

    final state = widget.cubit.state;
    if (state.documentPath == null) return;

    // Rotate each selected page
    for (final pageNum in selectedIndices) {
      await widget.cubit.rotatePage(pageNum, rotation);
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Selected pages rotated')),
      );
    }
  }

  Future<void> _deleteSelected() async {
    final selectedIndices = <int>[];
    for (int i = 0; i < _selectedPages.length; i++) {
      if (_selectedPages[i]) selectedIndices.add(_pageOrder[i]);
    }

    if (selectedIndices.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select at least one page')),
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Pages'),
        content: Text('Delete ${selectedIndices.length} page(s)?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await widget.cubit.deletePages(selectedIndices);
      await _loadPages(); // Refresh
    }
  }

  Future<void> _duplicateSelected() async {
    final selectedIndices = <int>[];
    for (int i = 0; i < _selectedPages.length; i++) {
      if (_selectedPages[i]) selectedIndices.add(_pageOrder[i]);
    }

    if (selectedIndices.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select at least one page')),
      );
      return;
    }

    // Duplicate the last selected page
    await widget.cubit.duplicatePage(selectedIndices.last);
    await _loadPages(); // Refresh

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Page duplicated')),
      );
    }
  }

  void _selectAll() {
    setState(() {
      final allSelected = _selectedPages.every((s) => s);
      for (int i = 0; i < _selectedPages.length; i++) {
        _selectedPages[i] = !allSelected;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'Page Manager',
        showBackButton: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.select_all),
            tooltip: 'Select All',
            onPressed: _selectAll,
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: LoadingIndicator())
          : Column(
              children: [
                // Toolbar
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    border: Border(
                      bottom: BorderSide(
                        color: Theme.of(context).dividerTheme.color ?? Colors.grey,
                      ),
                    ),
                  ),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _ActionChip(
                          icon: Icons.rotate_90_degrees_cw,
                          label: 'CW',
                          onTap: () => _rotateSelected(Rotation.clockwise90),
                        ),
                        _ActionChip(
                          icon: Icons.rotate_90_degrees_ccw,
                          label: 'CCW',
                          onTap: () => _rotateSelected(Rotation.counterClockwise90),
                        ),
                        _ActionChip(
                          icon: Icons.rotate_left,
                          label: '180',
                          onTap: () => _rotateSelected(Rotation.rotate180),
                        ),
                        _ActionChip(
                          icon: Icons.content_copy,
                          label: 'Duplicate',
                          onTap: _duplicateSelected,
                        ),
                        _ActionChip(
                          icon: Icons.delete,
                          label: 'Delete',
                          color: Theme.of(context).colorScheme.error,
                          onTap: _deleteSelected,
                        ),
                        if (_pageOrder.isNotEmpty) ...[
                          const VerticalDivider(),
                          _ActionChip(
                            icon: Icons.save,
                            label: 'Save Order',
                            onTap: _applyReorder,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),

                // Page count
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      Text(
                        '$_totalPages page(s)',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const Spacer(),
                      Text(
                        '${_selectedPages.where((s) => s).length} selected',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),

                // Page grid
                Expanded(
                  child: _totalPages == 0
                      ? const Center(child: Text('No pages'))
                      : ReorderableListView.builder(
                          padding: const EdgeInsets.all(8),
                          itemCount: _totalPages,
                          onReorder: _reorderPage,
                          proxyDecorator: (child, index, animation) {
                            return Material(
                              elevation: 8,
                              borderRadius: BorderRadius.circular(12),
                              child: child,
                            );
                          },
                          itemBuilder: (context, index) {
                            final pageNum = _pageOrder[index];
                            final isSelected = _selectedPages[index];

                            return _PageThumbnailItem(
                              key: ValueKey('page_$pageNum'),
                              pageNumber: pageNum,
                              displayIndex: index + 1,
                              isSelected: isSelected,
                              onToggle: () {
                                setState(() {
                                  _selectedPages[index] = !_selectedPages[index];
                                });
                              },
                              documentPath: widget.cubit.state.documentPath,
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class _PageThumbnailItem extends StatelessWidget {
  final int pageNumber;
  final int displayIndex;
  final bool isSelected;
  final VoidCallback onToggle;
  final String? documentPath;

  const _PageThumbnailItem({
    required super.key,
    required this.pageNumber,
    required this.displayIndex,
    required this.isSelected,
    required this.onToggle,
    this.documentPath,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: isSelected
            ? BorderSide(
                color: Theme.of(context).colorScheme.primary,
                width: 2,
              )
            : BorderSide.none,
      ),
      child: InkWell(
        onTap: onToggle,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              // Page number
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: isSelected
                      ? Theme.of(context).colorScheme.primaryContainer
                      : Theme.of(context).colorScheme.surfaceVariant,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: isSelected
                      ? Icon(
                          Icons.check,
                          size: 20,
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                        )
                      : Text(
                          '$displayIndex',
                          style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                ),
              ),
              const SizedBox(width: 16),

              // Thumbnail placeholder
              Container(
                width: 60,
                height: 80,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(4),
                  border: Border.all(color: Colors.grey.shade300),
                ),
                child: const Icon(
                  Icons.picture_as_pdf,
                  color: Colors.grey,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),

              // Page info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Page $pageNumber',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Original position: $pageNumber',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),

              // Drag handle
              const Icon(Icons.drag_handle, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _ActionChip({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: ActionChip(
        avatar: Icon(icon, size: 18, color: color),
        label: Text(
          label,
          style: TextStyle(color: color),
        ),
        onPressed: onTap,
      ),
    );
  }
}
