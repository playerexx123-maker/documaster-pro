import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/bottom_nav.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/error_state.dart';
import '../../../domain/entities/pdf_annotation.dart';
import '../../blocs/editor/editor_cubit.dart';
import 'annotation_page.dart';
import 'pdf_tools_page.dart';
import 'page_manager_page.dart';
import 'pdf_viewer_page.dart';

class EditorPage extends StatefulWidget {
  final String? filePath;
  final int? documentId;

  const EditorPage({super.key, this.filePath, this.documentId});

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  @override
  void initState() {
    super.initState();
    if (widget.filePath != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<EditorCubit>().loadDocument(
          widget.filePath!,
          documentId: widget.documentId,
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: DocuMasterAppBar(
        title: 'PDF Editor',
        showBackButton: true,
        actions: [
          _ToolMenuButton(),
          _AnnotationMenuButton(),
          _PageManagerButton(),
          _MoreMenuButton(),
        ],
      ),
      body: BlocBuilder<EditorCubit, EditorState>(
        builder: (context, state) {
          if (state.isLoading) {
            return const Center(child: LoadingIndicator());
          }

          if (state.error != null) {
            return ErrorState(
              message: state.error!,
              onRetry: () {
                if (widget.filePath != null) {
                  context.read<EditorCubit>().loadDocument(
                    widget.filePath!,
                    documentId: widget.documentId,
                  );
                }
              },
            );
          }

          if (state.documentPath == null) {
            return const _EmptyEditor();
          }

          return _EditorBody(state: state);
        },
      ),
      bottomNavigationBar: const AppBottomNav(currentIndex: 3),
    );
  }
}

class _EditorBody extends StatelessWidget {
  final EditorState state;

  const _EditorBody({required this.state});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Main PDF Viewer
        Column(
          children: [
            // Page navigation bar
            _PageNavigationBar(state: state),

            // PDF content
            Expanded(
              child: state.documentPath != null
                  ? SfPdfViewer.file(
                      File(state.documentPath!),
                      pageSpacing: 4,
                      enableDoubleTapZooming: true,
                      enableTextSelection: state.selectedTool == EditorTool.highlight ||
                          state.selectedTool == EditorTool.underline ||
                          state.selectedTool == EditorTool.strikeout,
                      onPageChanged: (details) {
                        context.read<EditorCubit>().goToPage(details.newPageNumber);
                      },
                    )
                  : const Center(child: Text('No document loaded')),
            ),

            // Bottom tool bar when annotation mode is active
            if (state.selectedTool != null) _AnnotationToolBar(state: state),
          ],
        ),

        // Side panels
        if (state.showAnnotationPanel)
          Positioned(
            right: 0,
            top: 0,
            bottom: 0,
            width: 300,
            child: AnnotationPanel(
              annotations: state.annotations,
              currentPage: state.currentPage,
              onClose: () => context.read<EditorCubit>().setShowAnnotationPanel(false),
              onDeleteAnnotation: (id) => context.read<EditorCubit>().removeAnnotation(id),
              selectedColor: state.selectedColor,
              onColorChanged: (color) => context.read<EditorCubit>().setSelectedColor(color),
              strokeWidth: state.strokeWidth,
              onStrokeWidthChanged: (w) => context.read<EditorCubit>().setStrokeWidth(w),
            ),
          ),
      ],
    );
  }
}

class _PageNavigationBar extends StatelessWidget {
  final EditorState state;

  const _PageNavigationBar({required this.state});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).dividerTheme.color ?? Colors.grey,
          ),
        ),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left),
            onPressed: state.currentPage > 1
                ? () => context.read<EditorCubit>().previousPage()
                : null,
            iconSize: 20,
          ),
          Expanded(
            child: Center(
              child: Text(
                'Page ${state.currentPage} of ${state.totalPages}',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.chevron_right),
            onPressed: state.currentPage < state.totalPages
                ? () => context.read<EditorCubit>().nextPage()
                : null,
            iconSize: 20,
          ),
        ],
      ),
    );
  }
}

class _AnnotationToolBar extends StatelessWidget {
  final EditorState state;

  const _AnnotationToolBar({required this.state});

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<EditorCubit>();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).dividerTheme.color ?? Colors.grey,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 4,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Color picker row
            Row(
              children: [
                Text('Color:', style: Theme.of(context).textTheme.bodySmall),
                const SizedBox(width: 8),
                ...[
                  Colors.yellow,
                  Colors.green,
                  Colors.blue,
                  Colors.red,
                  Colors.purple,
                  Colors.orange,
                  Colors.black,
                  Colors.white,
                ].map((color) {
                  final isSelected = state.selectedColor.value == color.value;
                  return GestureDetector(
                    onTap: () => cubit.setSelectedColor(color),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: color,
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: isSelected
                              ? Theme.of(context).colorScheme.primary
                              : Colors.grey,
                          width: isSelected ? 3 : 1,
                        ),
                      ),
                    ),
                  );
                }).toList(),
                const Spacer(),
                // Stroke width selector for pen tool
                if (state.selectedTool == EditorTool.pen) ...[
                  Text('Width:', style: Theme.of(context).textTheme.bodySmall),
                  SizedBox(
                    width: 80,
                    child: Slider(
                      value: state.strokeWidth,
                      min: 1,
                      max: 10,
                      divisions: 9,
                      onChanged: (v) => cubit.setStrokeWidth(v),
                    ),
                  ),
                ],
              ],
            ),

            // Action buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                TextButton.icon(
                  icon: const Icon(Icons.clear, size: 18),
                  label: const Text('Clear'),
                  onPressed: () => cubit.clearDrawingPoints(),
                ),
                TextButton.icon(
                  icon: const Icon(Icons.save, size: 18),
                  label: const Text('Save'),
                  onPressed: () => _saveAnnotation(context),
                ),
                TextButton.icon(
                  icon: const Icon(Icons.close, size: 18),
                  label: const Text('Done'),
                  onPressed: () => cubit.selectTool(null),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _saveAnnotation(BuildContext context) {
    final cubit = context.read<EditorCubit>();
    final state = cubit.state;

    if (state.drawingPoints.isEmpty &&
        (state.textContent == null || state.textContent!.isEmpty)) {
      return;
    }

    AnnotationType type;
    switch (state.selectedTool) {
      case EditorTool.highlight:
        type = AnnotationType.highlight;
        break;
      case EditorTool.underline:
        type = AnnotationType.underline;
        break;
      case EditorTool.strikeout:
        type = AnnotationType.strikeout;
        break;
      case EditorTool.pen:
        type = AnnotationType.draw;
        break;
      case EditorTool.text:
        type = AnnotationType.textBox;
        break;
      case EditorTool.comment:
        type = AnnotationType.comment;
        break;
      case EditorTool.signature:
        type = AnnotationType.signature;
        break;
      default:
        type = AnnotationType.draw;
    }

    final annotation = PdfAnnotation(
      documentId: state.documentId ?? -1,
      pageNumber: state.currentPage,
      type: type,
      color: state.selectedColor,
      content: state.textContent,
      points: state.drawingPoints.isNotEmpty ? state.drawingPoints : null,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    cubit.addAnnotation(annotation);
    cubit.clearDrawingPoints();
    cubit.setTextContent('');
  }
}

class _ToolMenuButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.build),
      tooltip: 'Tools',
      onPressed: () {
        final state = context.read<EditorCubit>().state;
        if (state.documentPath != null) {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => PdfToolsPage(
                cubit: context.read<EditorCubit>(),
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Open a PDF first')),
          );
        }
      },
    );
  }
}

class _AnnotationMenuButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.annotation),
      tooltip: 'Annotations',
      onPressed: () {
        final cubit = context.read<EditorCubit>();
        cubit.setShowAnnotationPanel(!cubit.state.showAnnotationPanel);
      },
    );
  }
}

class _PageManagerButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.view_carousel),
      tooltip: 'Page Manager',
      onPressed: () {
        final state = context.read<EditorCubit>().state;
        if (state.documentPath != null) {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => PageManagerPage(
                cubit: context.read<EditorCubit>(),
              ),
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Open a PDF first')),
          );
        }
      },
    );
  }
}

class _MoreMenuButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      icon: const Icon(Icons.more_vert),
      onSelected: (value) {
        final cubit = context.read<EditorCubit>();
        switch (value) {
          case 'viewer':
            if (cubit.state.documentPath != null) {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => PdfViewerPage(
                    filePath: cubit.state.documentPath!,
                    initialPage: cubit.state.currentPage,
                  ),
                ),
              );
            }
            break;
          case 'save_annotations':
            cubit.annotatePdf();
            break;
        }
      },
      itemBuilder: (context) => [
        const PopupMenuItem(value: 'viewer', child: Text('Full Screen Viewer')),
        const PopupMenuItem(value: 'save_annotations', child: Text('Save Annotations to PDF')),
      ],
    );
  }
}

class _EmptyEditor extends StatelessWidget {
  const _EmptyEditor();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.edit_note,
            size: 100,
            color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Select a document to edit',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Open a PDF to view, annotate, and edit',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.7),
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            icon: const Icon(Icons.folder_open),
            label: const Text('Browse Files'),
            onPressed: () {
              // Navigate to files page to select a PDF
              Navigator.of(context).pushNamed('/files');
            },
          ),
        ],
      ),
    );
  }
}
