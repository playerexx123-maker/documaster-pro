import 'dart:math';
import 'package:flutter/material.dart';
import '../../../domain/entities/pdf_annotation.dart';
import '../../blocs/editor/editor_cubit.dart';

// ─── Annotation Panel (side drawer) ───

class AnnotationPanel extends StatelessWidget {
  final List<PdfAnnotation> annotations;
  final int currentPage;
  final VoidCallback onClose;
  final Function(int) onDeleteAnnotation;
  final Color selectedColor;
  final Function(Color) onColorChanged;
  final double strokeWidth;
  final Function(double) onStrokeWidthChanged;

  const AnnotationPanel({
    super.key,
    required this.annotations,
    required this.currentPage,
    required this.onClose,
    required this.onDeleteAnnotation,
    required this.selectedColor,
    required this.onColorChanged,
    required this.strokeWidth,
    required this.onStrokeWidthChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(-2, 0),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: Theme.of(context).dividerTheme.color ?? Colors.grey,
                ),
              ),
            ),
            child: Row(
              children: [
                const Icon(Icons.annotation, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Annotations',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 20),
                  onPressed: onClose,
                ),
              ],
            ),
          ),

          // Color picker section
          _ColorPickerSection(
            selectedColor: selectedColor,
            onColorChanged: onColorChanged,
            strokeWidth: strokeWidth,
            onStrokeWidthChanged: onStrokeWidthChanged,
          ),

          const Divider(),

          // Annotation list
          Expanded(
            child: _AnnotationList(
              annotations: annotations,
              currentPage: currentPage,
              onDelete: onDeleteAnnotation,
            ),
          ),
        ],
      ),
    );
  }
}

class _ColorPickerSection extends StatelessWidget {
  final Color selectedColor;
  final Function(Color) onColorChanged;
  final double strokeWidth;
  final Function(double) onStrokeWidthChanged;

  const _ColorPickerSection({
    required this.selectedColor,
    required this.onColorChanged,
    required this.strokeWidth,
    required this.onStrokeWidthChanged,
  });

  @override
  Widget build(BuildContext context) {
    final colors = [
      Colors.yellow,
      Colors.green,
      Colors.blue,
      Colors.red,
      Colors.purple,
      Colors.orange,
      Colors.cyan,
      Colors.pink,
      Colors.teal,
      Colors.lime,
      Colors.black,
      Colors.white,
    ];

    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Color', style: Theme.of(context).textTheme.labelSmall),
          const SizedBox(height: 6),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: colors.map((color) {
              final isSelected = selectedColor.value == color.value;
              return GestureDetector(
                onTap: () => onColorChanged(color),
                child: Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: isSelected
                          ? Theme.of(context).colorScheme.primary
                          : (color == Colors.white ? Colors.grey : Colors.transparent),
                      width: isSelected ? 3 : 1,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          Text('Stroke Width', style: Theme.of(context).textTheme.labelSmall),
          Row(
            children: [
              const Text('1'),
              Expanded(
                child: Slider(
                  value: strokeWidth,
                  min: 1,
                  max: 10,
                  divisions: 9,
                  label: strokeWidth.toStringAsFixed(1),
                  onChanged: onStrokeWidthChanged,
                ),
              ),
              const Text('10'),
            ],
          ),
        ],
      ),
    );
  }
}

class _AnnotationList extends StatelessWidget {
  final List<PdfAnnotation> annotations;
  final int currentPage;
  final Function(int) onDelete;

  const _AnnotationList({
    required this.annotations,
    required this.currentPage,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final pageAnnotations = annotations
        .where((a) => a.pageNumber == currentPage)
        .toList();

    if (pageAnnotations.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.comment_outlined,
              size: 48,
              color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.5),
            ),
            const SizedBox(height: 8),
            Text(
              'No annotations on this page',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      itemCount: pageAnnotations.length,
      padding: const EdgeInsets.symmetric(vertical: 4),
      itemBuilder: (context, index) {
        final annotation = pageAnnotations[index];
        return _AnnotationListItem(
          annotation: annotation,
          onDelete: () {
            if (annotation.id != null) {
              onDelete(annotation.id!);
            }
          },
        );
      },
    );
  }
}

class _AnnotationListItem extends StatelessWidget {
  final PdfAnnotation annotation;
  final VoidCallback onDelete;

  const _AnnotationListItem({required this.annotation, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        dense: true,
        leading: Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(
            color: annotation.color ?? Colors.grey,
            shape: BoxShape.circle,
          ),
        ),
        title: Text(
          _annotationTypeLabel(annotation.type),
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w500,
          ),
        ),
        subtitle: annotation.content != null && annotation.content!.isNotEmpty
            ? Text(
                annotation.content!,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              )
            : null,
        trailing: IconButton(
          icon: const Icon(Icons.delete_outline, size: 18),
          onPressed: onDelete,
        ),
      ),
    );
  }

  String _annotationTypeLabel(AnnotationType type) {
    switch (type) {
      case AnnotationType.highlight:
        return 'Highlight';
      case AnnotationType.underline:
        return 'Underline';
      case AnnotationType.strikeout:
        return 'Strikeout';
      case AnnotationType.draw:
        return 'Drawing';
      case AnnotationType.comment:
        return 'Comment';
      case AnnotationType.stickyNote:
        return 'Sticky Note';
      case AnnotationType.signature:
        return 'Signature';
      case AnnotationType.textBox:
        return 'Text Box';
    }
  }
}

// ─── Annotation Toolbar (floating overlay) ───

class AnnotationToolbar extends StatelessWidget {
  final EditorTool? selectedTool;
  final Function(EditorTool?) onToolSelected;
  final VoidCallback onDone;

  const AnnotationToolbar({
    super.key,
    required this.selectedTool,
    required this.onToolSelected,
    required this.onDone,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _ToolButton(
            icon: Icons.highlight,
            label: 'Highlight',
            isSelected: selectedTool == EditorTool.highlight,
            onTap: () => onToolSelected(EditorTool.highlight),
          ),
          _ToolButton(
            icon: Icons.format_underline,
            label: 'Underline',
            isSelected: selectedTool == EditorTool.underline,
            onTap: () => onToolSelected(EditorTool.underline),
          ),
          _ToolButton(
            icon: Icons.format_strikethrough,
            label: 'Strikeout',
            isSelected: selectedTool == EditorTool.strikeout,
            onTap: () => onToolSelected(EditorTool.strikeout),
          ),
          _ToolButton(
            icon: Icons.edit,
            label: 'Pen',
            isSelected: selectedTool == EditorTool.pen,
            onTap: () => onToolSelected(EditorTool.pen),
          ),
          _ToolButton(
            icon: Icons.text_fields,
            label: 'Text',
            isSelected: selectedTool == EditorTool.text,
            onTap: () => onToolSelected(EditorTool.text),
          ),
          _ToolButton(
            icon: Icons.comment,
            label: 'Comment',
            isSelected: selectedTool == EditorTool.comment,
            onTap: () => onToolSelected(EditorTool.comment),
          ),
          _ToolButton(
            icon: Icons.draw,
            label: 'Signature',
            isSelected: selectedTool == EditorTool.signature,
            onTap: () => onToolSelected(EditorTool.signature),
          ),
          const SizedBox(width: 8),
          const VerticalDivider(width: 1),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: onDone,
            tooltip: 'Done',
          ),
        ],
      ),
    );
  }
}

class _ToolButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _ToolButton({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: label,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: isSelected
                ? Theme.of(context).colorScheme.primaryContainer
                : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            icon,
            size: 20,
            color: isSelected
                ? Theme.of(context).colorScheme.onPrimaryContainer
                : Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }
}

// ─── Signature Pad ───

class SignaturePad extends StatefulWidget {
  final Function(List<Point<double>>) onSignatureComplete;
  final VoidCallback onCancel;
  final Color strokeColor;
  final double strokeWidth;

  const SignaturePad({
    super.key,
    required this.onSignatureComplete,
    required this.onCancel,
    this.strokeColor = Colors.black,
    this.strokeWidth = 3,
  });

  @override
  State<SignaturePad> createState() => _SignaturePadState();
}

class _SignaturePadState extends State<SignaturePad> {
  final List<Point<double>> _points = [];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Text(
                  'Sign here',
                  style: Theme.of(context).textTheme.labelMedium,
                ),
                const Spacer(),
                TextButton.icon(
                  icon: const Icon(Icons.clear, size: 18),
                  label: const Text('Clear'),
                  onPressed: () => setState(() => _points.clear()),
                ),
              ],
            ),
          ),
          Container(
            height: 180,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade300),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: GestureDetector(
                onPanUpdate: (details) {
                  final box = context.findRenderObject() as RenderBox;
                  final localPosition = box.globalToLocal(details.globalPosition);
                  setState(() {
                    _points.add(Point<double>(
                      localPosition.dx.clamp(0, box.size.width),
                      localPosition.dy.clamp(0, box.size.height),
                    ));
                  });
                },
                onPanEnd: (_) {
                  _points.add(Point<double>(double.nan, double.nan));
                },
                child: CustomPaint(
                  size: Size.infinite,
                  painter: _SignaturePainter(
                    points: _points,
                    color: widget.strokeColor,
                    strokeWidth: widget.strokeWidth,
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: widget.onCancel,
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () {
                    final validPoints = _points
                        .where((p) => !p.x.isNaN && !p.y.isNaN)
                        .toList();
                    if (validPoints.isNotEmpty) {
                      widget.onSignatureComplete(validPoints);
                    }
                  },
                  child: const Text('Apply'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SignaturePainter extends CustomPainter {
  final List<Point<double>> points;
  final Color color;
  final double strokeWidth;

  _SignaturePainter({
    required this.points,
    required this.color,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    final path = Path();
    bool started = false;

    for (int i = 0; i < points.length; i++) {
      if (points[i].x.isNaN || points[i].y.isNaN) {
        started = false;
        continue;
      }
      if (!started) {
        path.moveTo(points[i].x, points[i].y);
        started = true;
      } else {
        path.lineTo(points[i].x, points[i].y);
      }
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _SignaturePainter oldDelegate) => true;
}

// ─── Sticky Note Dialog ───

class StickyNoteDialog extends StatefulWidget {
  final String? initialText;
  final Function(String) onSave;

  const StickyNoteDialog({
    super.key,
    this.initialText,
    required this.onSave,
  });

  @override
  State<StickyNoteDialog> createState() => _StickyNoteDialogState();
}

class _StickyNoteDialogState extends State<StickyNoteDialog> {
  late final TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialText);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Row(
        children: [
          Icon(Icons.sticky_note_2, color: Colors.yellow.shade700),
          const SizedBox(width: 8),
          const Text('Sticky Note'),
        ],
      ),
      content: TextField(
        controller: _controller,
        maxLines: 4,
        decoration: const InputDecoration(
          hintText: 'Enter your note...',
          border: OutlineInputBorder(),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onSave(_controller.text);
            Navigator.of(context).pop();
          },
          child: const Text('Save'),
        ),
      ],
    );
  }
}

// ─── Drawing Canvas for Pen Tool ───

class DrawingCanvas extends StatefulWidget {
  final List<Point<double>> points;
  final Function(List<Point<double>>) onPointsChanged;
  final Color color;
  final double strokeWidth;

  const DrawingCanvas({
    super.key,
    required this.points,
    required this.onPointsChanged,
    required this.color,
    required this.strokeWidth,
  });

  @override
  State<DrawingCanvas> createState() => _DrawingCanvasState();
}

class _DrawingCanvasState extends State<DrawingCanvas> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onPanUpdate: (details) {
        final box = context.findRenderObject() as RenderBox;
        final localPosition = box.globalToLocal(details.globalPosition);
        final newPoints = List<Point<double>>.from(widget.points)
          ..add(Point<double>(localPosition.dx, localPosition.dy));
        widget.onPointsChanged(newPoints);
      },
      onPanEnd: (_) {
        final newPoints = List<Point<double>>.from(widget.points)
          ..add(Point<double>(double.nan, double.nan));
        widget.onPointsChanged(newPoints);
      },
      child: CustomPaint(
        size: Size.infinite,
        painter: _DrawingPainter(
          points: widget.points,
          color: widget.color,
          strokeWidth: widget.strokeWidth,
        ),
      ),
    );
  }
}

class _DrawingPainter extends CustomPainter {
  final List<Point<double>> points;
  final Color color;
  final double strokeWidth;

  _DrawingPainter({
    required this.points,
    required this.color,
    required this.strokeWidth,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final path = Path();
    bool started = false;

    for (final point in points) {
      if (point.x.isNaN || point.y.isNaN) {
        started = false;
        continue;
      }
      if (!started) {
        path.moveTo(point.x, point.y);
        started = true;
      } else {
        path.lineTo(point.x, point.y);
      }
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _DrawingPainter oldDelegate) => true;
}
