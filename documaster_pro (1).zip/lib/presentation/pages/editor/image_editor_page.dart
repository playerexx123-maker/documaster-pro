import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:photo_view/photo_view.dart';
import '../../../core/widgets/app_bar.dart';
import '../../../core/widgets/loading_indicator.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../domain/repositories/image_editor_repository.dart';
import '../../blocs/image_editor/image_editor_cubit.dart';

class ImageEditorPage extends StatelessWidget {
  final String? imagePath;
  final ImageEditorCubit? cubit;

  const ImageEditorPage({super.key, this.imagePath, this.cubit});

  @override
  Widget build(BuildContext context) {
    if (cubit != null) {
      if (imagePath != null) {
        cubit!.loadImage(imagePath!);
      }
      return BlocProvider.value(
        value: cubit!,
        child: const _ImageEditorView(),
      );
    }
    return const Scaffold(
      body: Center(
        child: Text(
          'Image Editor requires a cubit.\nUse dependency injection to provide ImageEditorCubit.',
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}

class _ImageEditorView extends StatelessWidget {
  const _ImageEditorView();

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ImageEditorCubit, ImageEditorState>(
      builder: (context, state) {
        return Scaffold(
          appBar: DocuMasterAppBar(
            title: 'Image Editor',
            showBackButton: true,
            actions: [
              if (state.canUndo)
                IconButton(
                  icon: const Icon(Icons.undo),
                  tooltip: 'Undo',
                  onPressed: () => context.read<ImageEditorCubit>().undo(),
                ),
              if (state.canRedo)
                IconButton(
                  icon: const Icon(Icons.redo),
                  tooltip: 'Redo',
                  onPressed: () => context.read<ImageEditorCubit>().redo(),
                ),
              if (state.hasChanges)
                IconButton(
                  icon: const Icon(Icons.save),
                  tooltip: 'Save',
                  onPressed: () => _showSaveOptions(context),
                ),
              IconButton(
                icon: const Icon(Icons.refresh),
                tooltip: 'Reset',
                onPressed: () => _showResetConfirm(context),
              ),
            ],
          ),
          body: state.hasImage
              ? _buildEditorBody(context, state)
              : const EmptyState(
                  icon: Icons.image,
                  title: 'No Image Loaded',
                  subtitle: 'Open an image to start editing',
                ),
          bottomNavigationBar: state.hasImage
              ? _buildToolsToolbar(context, state)
              : null,
        );
      },
    );
  }

  Widget _buildEditorBody(BuildContext context, ImageEditorState state) {
    return Column(
      children: [
        // Image preview area
        Expanded(
          child: Container(
            color: Colors.black87,
            child: state.isProcessing
                ? const LoadingIndicator(
                    message: 'Processing...',
                    size: 48,
                  )
                : _buildImagePreview(state),
          ),
        ),
        // Tool panel
        if (state.selectedTool != ImageEditorTool.none)
          _buildToolPanel(context, state),
        // Status bar
        if (state.error != null)
          Container(
            width: double.infinity,
            color: Theme.of(context).colorScheme.errorContainer,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Icon(
                  Icons.error_outline,
                  color: Theme.of(context).colorScheme.error,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    state.error!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.error,
                      fontSize: 12,
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close, size: 16),
                  onPressed: () => context.read<ImageEditorCubit>().clearError(),
                  color: Theme.of(context).colorScheme.error,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildImagePreview(ImageEditorState state) {
    final displayPath = state.editedImagePath ?? state.imagePath;
    if (displayPath == null) {
      return const Center(child: Text('No image', style: TextStyle(color: Colors.white)));
    }

    return PhotoView(
      imageProvider: FileImage(File(displayPath)),
      backgroundDecoration: const BoxDecoration(color: Colors.transparent),
      minScale: PhotoViewComputedScale.contained,
      maxScale: PhotoViewComputedScale.covered * 3,
      enableRotation: false,
      enablePanAlways: true,
    );
  }

  Widget _buildToolsToolbar(BuildContext context, ImageEditorState state) {
    return Container(
      height: 80,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(
            children: [
              _buildToolButton(
                context,
                Icons.crop,
                'Crop',
                ImageEditorTool.crop,
                state.selectedTool == ImageEditorTool.crop,
              ),
              _buildToolButton(
                context,
                Icons.aspect_ratio,
                'Resize',
                ImageEditorTool.resize,
                state.selectedTool == ImageEditorTool.resize,
              ),
              _buildToolButton(
                context,
                Icons.rotate_right,
                'Rotate',
                ImageEditorTool.rotate,
                state.selectedTool == ImageEditorTool.rotate,
              ),
              _buildToolButton(
                context,
                Icons.brightness_6,
                'Brightness',
                ImageEditorTool.brightness,
                state.selectedTool == ImageEditorTool.brightness,
              ),
              _buildToolButton(
                context,
                Icons.contrast,
                'Contrast',
                ImageEditorTool.contrast,
                state.selectedTool == ImageEditorTool.contrast,
              ),
              _buildToolButton(
                context,
                Icons.auto_fix_high,
                'Sharpen',
                ImageEditorTool.sharpen,
                state.selectedTool == ImageEditorTool.sharpen,
              ),
              _buildToolButton(
                context,
                Icons.transform,
                'Format',
                ImageEditorTool.formatConvert,
                state.selectedTool == ImageEditorTool.formatConvert,
              ),
              _buildToolButton(
                context,
                Icons.format_color_reset,
                'No BG',
                ImageEditorTool.removeBackground,
                state.selectedTool == ImageEditorTool.removeBackground,
              ),
              _buildToolButton(
                context,
                Icons.compress,
                'Compress',
                ImageEditorTool.compress,
                state.selectedTool == ImageEditorTool.compress,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildToolButton(
    BuildContext context,
    IconData icon,
    String label,
    ImageEditorTool tool,
    bool isSelected,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: InkWell(
        onTap: () {
          final cubit = context.read<ImageEditorCubit>();
          if (isSelected) {
            cubit.selectTool(ImageEditorTool.none);
          } else {
            cubit.selectTool(tool);
          }
        },
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 64,
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? Theme.of(context).colorScheme.primaryContainer
                : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: 24,
                color: isSelected
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10,
                  color: isSelected
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildToolPanel(BuildContext context, ImageEditorState state) {
    switch (state.selectedTool) {
      case ImageEditorTool.crop:
        return _CropToolPanel(state: state);
      case ImageEditorTool.resize:
        return _ResizeToolPanel(state: state);
      case ImageEditorTool.rotate:
        return _RotateToolPanel(state: state);
      case ImageEditorTool.brightness:
        return _BrightnessToolPanel(state: state);
      case ImageEditorTool.contrast:
        return _ContrastToolPanel(state: state);
      case ImageEditorTool.sharpen:
        return _SharpenToolPanel(state: state);
      case ImageEditorTool.formatConvert:
        return _FormatConvertPanel(state: state);
      case ImageEditorTool.removeBackground:
        return _RemoveBackgroundPanel(state: state);
      case ImageEditorTool.compress:
        return _CompressToolPanel(state: state);
      default:
        return const SizedBox.shrink();
    }
  }

  void _showSaveOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.save),
              title: const Text('Save'),
              subtitle: const Text('Overwrite original file'),
              onTap: () {
                Navigator.pop(ctx);
                // Save logic
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Image saved')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.save_as),
              title: const Text('Save As'),
              subtitle: const Text('Create a new file'),
              onTap: () {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Image saved as new file')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Share'),
              onTap: () {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Share functionality')),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showResetConfirm(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset Image?'),
        content: const Text('This will discard all changes and restore the original image.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(ctx);
              context.read<ImageEditorCubit>().reset();
            },
            child: const Text('Reset'),
          ),
        ],
      ),
    );
  }
}

class _CropToolPanel extends StatelessWidget {
  final ImageEditorState state;
  const _CropToolPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Crop Image',
      children: [
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: () => _showCropDialog(context),
                icon: const Icon(Icons.crop),
                label: const Text('Custom Crop'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              _buildPresetCrop(context, '1:1', const Rect(x: 0, y: 0, width: 100, height: 100)),
              _buildPresetCrop(context, '4:3', const Rect(x: 0, y: 0, width: 400, height: 300)),
              _buildPresetCrop(context, '16:9', const Rect(x: 0, y: 0, width: 1600, height: 900)),
              _buildPresetCrop(context, '3:4', const Rect(x: 0, y: 0, width: 300, height: 400)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPresetCrop(BuildContext context, String label, Rect rect) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: OutlinedButton(
        onPressed: () => context.read<ImageEditorCubit>().applyCrop(rect),
        child: Text(label),
      ),
    );
  }

  void _showCropDialog(BuildContext context) {
    final xController = TextEditingController();
    final yController = TextEditingController();
    final wController = TextEditingController();
    final hController = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Crop Rectangle'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: xController,
              decoration: const InputDecoration(labelText: 'X'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: yController,
              decoration: const InputDecoration(labelText: 'Y'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: wController,
              decoration: const InputDecoration(labelText: 'Width'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: hController,
              decoration: const InputDecoration(labelText: 'Height'),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final x = double.tryParse(xController.text) ?? 0;
              final y = double.tryParse(yController.text) ?? 0;
              final w = double.tryParse(wController.text) ?? 100;
              final h = double.tryParse(hController.text) ?? 100;
              Navigator.pop(ctx);
              context.read<ImageEditorCubit>().applyCrop(
                Rect(x: x, y: y, width: w, height: h),
              );
            },
            child: const Text('Apply'),
          ),
        ],
      ),
    );
  }
}

class _ResizeToolPanel extends StatefulWidget {
  final ImageEditorState state;
  const _ResizeToolPanel({required this.state});

  @override
  State<_ResizeToolPanel> createState() => _ResizeToolPanelState();
}

class _ResizeToolPanelState extends State<_ResizeToolPanel> {
  late TextEditingController _wController;
  late TextEditingController _hController;

  @override
  void initState() {
    super.initState();
    _wController = TextEditingController(text: widget.state.resizeWidth.toString());
    _hController = TextEditingController(text: widget.state.resizeHeight.toString());
  }

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Resize Image',
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: _wController,
                decoration: const InputDecoration(
                  labelText: 'Width (px)',
                  prefixIcon: Icon(Icons.width_normal),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: TextField(
                controller: _hController,
                decoration: const InputDecoration(
                  labelText: 'Height (px)',
                  prefixIcon: Icon(Icons.height),
                ),
                keyboardType: TextInputType.number,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () {
            final w = int.tryParse(_wController.text) ?? 0;
            final h = int.tryParse(_hController.text) ?? 0;
            if (w > 0 && h > 0) {
              context.read<ImageEditorCubit>().applyResize(w, h);
            }
          },
          icon: const Icon(Icons.check),
          label: const Text('Apply Resize'),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _wController.dispose();
    _hController.dispose();
    super.dispose();
  }
}

class _RotateToolPanel extends StatelessWidget {
  final ImageEditorState state;
  const _RotateToolPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Rotate Image',
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _buildRotateButton(context, '90° CCW', -90),
            _buildRotateButton(context, '90° CW', 90),
            _buildRotateButton(context, '180°', 180),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            const Text('Custom:'),
            Expanded(
              child: Slider(
                value: state.rotateAngle,
                min: -180,
                max: 180,
                divisions: 36,
                label: '${state.rotateAngle.round()}°',
                onChanged: (v) => context.read<ImageEditorCubit>().setRotateAngle(v),
              ),
            ),
            SizedBox(
              width: 60,
              child: FilledButton(
                onPressed: () => context.read<ImageEditorCubit>().applyRotate(state.rotateAngle),
                child: const Icon(Icons.check, size: 18),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildRotateButton(BuildContext context, String label, double angle) {
    return OutlinedButton(
      onPressed: () => context.read<ImageEditorCubit>().applyRotate(angle),
      child: Text(label),
    );
  }
}

class _BrightnessToolPanel extends StatelessWidget {
  final ImageEditorState state;
  const _BrightnessToolPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Adjust Brightness',
      children: [
        Row(
          children: [
            const Icon(Icons.brightness_low, size: 20),
            Expanded(
              child: Slider(
                value: state.brightnessValue,
                min: 0.0,
                max: 2.0,
                divisions: 20,
                label: state.brightnessValue.toStringAsFixed(1),
                onChanged: (v) => context.read<ImageEditorCubit>().setBrightness(v),
              ),
            ),
            const Icon(Icons.brightness_high, size: 20),
          ],
        ),
        Text(
          'Value: ${state.brightnessValue.toStringAsFixed(1)}x',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => context.read<ImageEditorCubit>().applyBrightness(state.brightnessValue),
          icon: const Icon(Icons.check),
          label: const Text('Apply'),
        ),
      ],
    );
  }
}

class _ContrastToolPanel extends StatelessWidget {
  final ImageEditorState state;
  const _ContrastToolPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Adjust Contrast',
      children: [
        Row(
          children: [
            const Text('Low'),
            Expanded(
              child: Slider(
                value: state.contrastValue,
                min: 0.0,
                max: 2.0,
                divisions: 20,
                label: state.contrastValue.toStringAsFixed(1),
                onChanged: (v) => context.read<ImageEditorCubit>().setContrast(v),
              ),
            ),
            const Text('High'),
          ],
        ),
        Text(
          'Value: ${state.contrastValue.toStringAsFixed(1)}x',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => context.read<ImageEditorCubit>().applyContrast(state.contrastValue),
          icon: const Icon(Icons.check),
          label: const Text('Apply'),
        ),
      ],
    );
  }
}

class _SharpenToolPanel extends StatelessWidget {
  final ImageEditorState state;
  const _SharpenToolPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Sharpen Image',
      children: [
        Row(
          children: [
            const Text('Soft'),
            Expanded(
              child: Slider(
                value: state.sharpenAmount,
                min: 0.5,
                max: 3.0,
                divisions: 25,
                label: state.sharpenAmount.toStringAsFixed(1),
                onChanged: (v) => context.read<ImageEditorCubit>().setSharpenAmount(v),
              ),
            ),
            const Text('Strong'),
          ],
        ),
        Text(
          'Amount: ${state.sharpenAmount.toStringAsFixed(1)}x',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => context.read<ImageEditorCubit>().applySharpen(state.sharpenAmount),
          icon: const Icon(Icons.check),
          label: const Text('Apply'),
        ),
      ],
    );
  }
}

class _FormatConvertPanel extends StatelessWidget {
  final ImageEditorState state;
  const _FormatConvertPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Convert Format',
      children: [
        SegmentedButton<ImageFormat>(
          segments: const [
            ButtonSegment(
              value: ImageFormat.jpeg,
              label: Text('JPEG'),
              icon: Icon(Icons.image),
            ),
            ButtonSegment(
              value: ImageFormat.png,
              label: Text('PNG'),
              icon: Icon(Icons.image),
            ),
            ButtonSegment(
              value: ImageFormat.bmp,
              label: Text('BMP'),
              icon: Icon(Icons.image),
            ),
          ],
          selected: {state.targetFormat},
          onSelectionChanged: (Set<ImageFormat> selected) {
            context.read<ImageEditorCubit>().setTargetFormat(selected.first);
          },
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () => context.read<ImageEditorCubit>().applyFormatConvert(state.targetFormat),
          icon: const Icon(Icons.transform),
          label: const Text('Convert'),
        ),
      ],
    );
  }
}

class _RemoveBackgroundPanel extends StatelessWidget {
  final ImageEditorState state;
  const _RemoveBackgroundPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Remove Background',
      children: [
        const Text(
          'This will remove the background from the image using edge detection.',
          style: TextStyle(fontSize: 13),
        ),
        const SizedBox(height: 4),
        const Text(
          'Note: This is a placeholder. For production, connect to an AI background removal service.',
          style: TextStyle(fontSize: 11, color: Colors.orange),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: () => context.read<ImageEditorCubit>().applyRemoveBackground(),
          icon: const Icon(Icons.format_color_reset),
          label: const Text('Remove Background'),
        ),
      ],
    );
  }
}

class _CompressToolPanel extends StatelessWidget {
  final ImageEditorState state;
  const _CompressToolPanel({required this.state});

  @override
  Widget build(BuildContext context) {
    return _ToolPanelContainer(
      title: 'Compress Image',
      children: [
        Row(
          children: [
            const Text('Low'),
            Expanded(
              child: Slider(
                value: state.compressQuality.toDouble(),
                min: 10,
                max: 100,
                divisions: 18,
                label: '${state.compressQuality}%',
                onChanged: (v) => context.read<ImageEditorCubit>().setCompressQuality(v.round()),
              ),
            ),
            const Text('High'),
          ],
        ),
        Text(
          'Quality: ${state.compressQuality}%',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => context.read<ImageEditorCubit>().applyCompress(state.compressQuality),
          icon: const Icon(Icons.compress),
          label: const Text('Compress'),
        ),
      ],
    );
  }
}

class _ToolPanelContainer extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _ToolPanelContainer({
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border(
          top: BorderSide(
            color: Theme.of(context).colorScheme.outlineVariant,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }
}
