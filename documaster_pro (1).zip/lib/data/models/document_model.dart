import '../../domain/entities/document.dart';

class DocumentModel {
  final int? id;
  final String name;
  final String filePath;
  final String fileType;
  final int fileSize;
  final int? folderId;
  final int pageCount;
  final String? ocrText;
  final String? tags;
  final int isFavorite;
  final int isEncrypted;
  final String? passwordHash;
  final String? thumbnailPath;
  final String? cloudSyncId;
  final String? cloudProvider;
  final int createdAt;
  final int updatedAt;
  final int? accessedAt;
  final String? metadata;

  DocumentModel({
    this.id,
    required this.name,
    required this.filePath,
    required this.fileType,
    required this.fileSize,
    this.folderId,
    this.pageCount = 1,
    this.ocrText,
    this.tags,
    this.isFavorite = 0,
    this.isEncrypted = 0,
    this.passwordHash,
    this.thumbnailPath,
    this.cloudSyncId,
    this.cloudProvider,
    required this.createdAt,
    required this.updatedAt,
    this.accessedAt,
    this.metadata,
  });

  factory DocumentModel.fromMap(Map<String, dynamic> map) {
    return DocumentModel(
      id: map['id'] as int?,
      name: map['name'] as String,
      filePath: map['file_path'] as String,
      fileType: map['file_type'] as String,
      fileSize: map['file_size'] as int,
      folderId: map['folder_id'] as int?,
      pageCount: map['page_count'] as int? ?? 1,
      ocrText: map['ocr_text'] as String?,
      tags: map['tags'] as String?,
      isFavorite: map['is_favorite'] as int? ?? 0,
      isEncrypted: map['is_encrypted'] as int? ?? 0,
      passwordHash: map['password_hash'] as String?,
      thumbnailPath: map['thumbnail_path'] as String?,
      cloudSyncId: map['cloud_sync_id'] as String?,
      cloudProvider: map['cloud_provider'] as String?,
      createdAt: map['created_at'] as int,
      updatedAt: map['updated_at'] as int,
      accessedAt: map['accessed_at'] as int?,
      metadata: map['metadata'] as String?,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'file_path': filePath,
      'file_type': fileType,
      'file_size': fileSize,
      'folder_id': folderId,
      'page_count': pageCount,
      'ocr_text': ocrText,
      'tags': tags,
      'is_favorite': isFavorite,
      'is_encrypted': isEncrypted,
      'password_hash': passwordHash,
      'thumbnail_path': thumbnailPath,
      'cloud_sync_id': cloudSyncId,
      'cloud_provider': cloudProvider,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'accessed_at': accessedAt,
      'metadata': metadata,
    };
  }

  Document toEntity() {
    return Document(
      id: id,
      name: name,
      filePath: filePath,
      fileType: _parseFileType(fileType),
      fileSize: fileSize,
      folderId: folderId,
      pageCount: pageCount,
      ocrText: ocrText,
      tags: tags != null ? tags!.split(',') : [],
      isFavorite: isFavorite == 1,
      isEncrypted: isEncrypted == 1,
      passwordHash: passwordHash,
      thumbnailPath: thumbnailPath,
      cloudSyncId: cloudSyncId,
      cloudProvider: cloudProvider,
      createdAt: DateTime.fromMillisecondsSinceEpoch(createdAt),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(updatedAt),
      accessedAt: accessedAt != null ? DateTime.fromMillisecondsSinceEpoch(accessedAt!) : null,
      metadata: null,
    );
  }

  static DocumentModel fromEntity(Document doc) {
    return DocumentModel(
      id: doc.id,
      name: doc.name,
      filePath: doc.filePath,
      fileType: doc.fileType.name,
      fileSize: doc.fileSize,
      folderId: doc.folderId,
      pageCount: doc.pageCount,
      ocrText: doc.ocrText,
      tags: doc.tags.isNotEmpty ? doc.tags.join(',') : null,
      isFavorite: doc.isFavorite ? 1 : 0,
      isEncrypted: doc.isEncrypted ? 1 : 0,
      passwordHash: doc.passwordHash,
      thumbnailPath: doc.thumbnailPath,
      cloudSyncId: doc.cloudSyncId,
      cloudProvider: doc.cloudProvider,
      createdAt: doc.createdAt.millisecondsSinceEpoch,
      updatedAt: doc.updatedAt.millisecondsSinceEpoch,
      accessedAt: doc.accessedAt?.millisecondsSinceEpoch,
      metadata: null,
    );
  }

  FileType _parseFileType(String type) {
    try {
      return FileType.values.byName(type);
    } catch (_) {
      return FileType.unknown;
    }
  }
}
