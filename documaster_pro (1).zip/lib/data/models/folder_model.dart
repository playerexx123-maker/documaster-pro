import '../../domain/entities/folder.dart';

class FolderModel {
  final int? id;
  final String name;
  final int? parentId;
  final String color;
  final String icon;
  final int createdAt;
  final int updatedAt;

  FolderModel({
    this.id,
    required this.name,
    this.parentId,
    this.color = '#2196F3',
    this.icon = 'folder',
    required this.createdAt,
    required this.updatedAt,
  });

  factory FolderModel.fromMap(Map<String, dynamic> map) {
    return FolderModel(
      id: map['id'] as int?,
      name: map['name'] as String,
      parentId: map['parent_id'] as int?,
      color: map['color'] as String? ?? '#2196F3',
      icon: map['icon'] as String? ?? 'folder',
      createdAt: map['created_at'] as int,
      updatedAt: map['updated_at'] as int,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'parent_id': parentId,
      'color': color,
      'icon': icon,
      'created_at': createdAt,
      'updated_at': updatedAt,
    };
  }

  Folder toEntity() {
    return Folder(
      id: id,
      name: name,
      parentId: parentId,
      color: color,
      icon: icon,
      createdAt: DateTime.fromMillisecondsSinceEpoch(createdAt),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(updatedAt),
    );
  }

  static FolderModel fromEntity(Folder folder) {
    return FolderModel(
      id: folder.id,
      name: folder.name,
      parentId: folder.parentId,
      color: folder.color,
      icon: folder.icon,
      createdAt: folder.createdAt.millisecondsSinceEpoch,
      updatedAt: folder.updatedAt.millisecondsSinceEpoch,
    );
  }
}
