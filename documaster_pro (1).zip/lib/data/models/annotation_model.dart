import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../domain/entities/pdf_annotation.dart';

class AnnotationModel {
  final int? id;
  final int documentId;
  final int pageNumber;
  final String type;
  final String? color;
  final String? content;
  final String? points;
  final String? rect;
  final int createdAt;
  final int updatedAt;

  AnnotationModel({
    this.id,
    required this.documentId,
    required this.pageNumber,
    required this.type,
    this.color,
    this.content,
    this.points,
    this.rect,
    required this.createdAt,
    required this.updatedAt,
  });

  factory AnnotationModel.fromMap(Map<String, dynamic> map) {
    return AnnotationModel(
      id: map['id'] as int?,
      documentId: map['document_id'] as int,
      pageNumber: map['page_number'] as int,
      type: map['type'] as String,
      color: map['color'] as String?,
      content: map['content'] as String?,
      points: map['points'] as String?,
      rect: map['rect'] as String?,
      createdAt: map['created_at'] as int,
      updatedAt: map['updated_at'] as int,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'document_id': documentId,
      'page_number': pageNumber,
      'type': type,
      'color': color,
      'content': content,
      'points': points,
      'rect': rect,
      'created_at': createdAt,
      'updated_at': updatedAt,
    };
  }

  PdfAnnotation toEntity() {
    return PdfAnnotation(
      id: id,
      documentId: documentId,
      pageNumber: pageNumber,
      type: AnnotationType.values.byName(type),
      color: color != null ? _parseColor(color!) : null,
      content: content,
      points: points != null ? _parsePoints(points!) : null,
      rect: rect != null ? _parseRect(rect!) : null,
      createdAt: DateTime.fromMillisecondsSinceEpoch(createdAt),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(updatedAt),
    );
  }

  static AnnotationModel fromEntity(PdfAnnotation annotation) {
    return AnnotationModel(
      id: annotation.id,
      documentId: annotation.documentId,
      pageNumber: annotation.pageNumber,
      type: annotation.type.name,
      color: annotation.color != null ? _colorToString(annotation.color!) : null,
      content: annotation.content,
      points: annotation.points != null ? _pointsToString(annotation.points!) : null,
      rect: annotation.rect != null ? _rectToString(annotation.rect!) : null,
      createdAt: annotation.createdAt.millisecondsSinceEpoch,
      updatedAt: annotation.updatedAt.millisecondsSinceEpoch,
    );
  }

  static Color _parseColor(String colorStr) {
    final hex = colorStr.replaceFirst('#', '');
    return Color(int.parse('FF$hex', radix: 16));
  }

  static String _colorToString(Color color) {
    return '#${color.value.toRadixString(16).padLeft(8, '0').substring(2)}';
  }

  static List<Point<double>> _parsePoints(String pointsStr) {
    final List<dynamic> json = jsonDecode(pointsStr);
    return json.map((p) => Point<double>(p['x'].toDouble(), p['y'].toDouble())).toList();
  }

  static String _pointsToString(List<Point<double>> points) {
    return jsonEncode(points.map((p) => {'x': p.x, 'y': p.y}).toList());
  }

  static Rect _parseRect(String rectStr) {
    final json = jsonDecode(rectStr);
    return Rect.fromLTWH(
      json['left'].toDouble(),
      json['top'].toDouble(),
      json['width'].toDouble(),
      json['height'].toDouble(),
    );
  }

  static String _rectToString(Rect rect) {
    return jsonEncode({
      'left': rect.left,
      'top': rect.top,
      'width': rect.width,
      'height': rect.height,
    });
  }
}
