import '../../domain/entities/ocr_result.dart';

class OcrResultModel {
  final int? id;
  final int documentId;
  final int pageNumber;
  final String recognizedText;
  final String language;
  final double? confidence;
  final int createdAt;

  OcrResultModel({
    this.id,
    required this.documentId,
    this.pageNumber = 1,
    required this.recognizedText,
    this.language = 'en',
    this.confidence,
    required this.createdAt,
  });

  factory OcrResultModel.fromMap(Map<String, dynamic> map) {
    return OcrResultModel(
      id: map['id'] as int?,
      documentId: map['document_id'] as int,
      pageNumber: map['page_number'] as int? ?? 1,
      recognizedText: map['recognized_text'] as String,
      language: map['language'] as String? ?? 'en',
      confidence: map['confidence'] as double?,
      createdAt: map['created_at'] as int,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'document_id': documentId,
      'page_number': pageNumber,
      'recognized_text': recognizedText,
      'language': language,
      'confidence': confidence,
      'created_at': createdAt,
    };
  }

  OcrResult toEntity() {
    return OcrResult(
      id: id,
      documentId: documentId,
      pageNumber: pageNumber,
      recognizedText: recognizedText,
      language: language,
      confidence: confidence,
      createdAt: DateTime.fromMillisecondsSinceEpoch(createdAt),
    );
  }
}
