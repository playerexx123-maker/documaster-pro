import 'dart:io';
import 'dart:typed_data';
import 'package:dartz/dartz.dart';
import 'package:path_provider/path_provider.dart';
import '../../core/errors/exceptions.dart';
import '../../core/errors/failures.dart';
import '../../core/utils/file_utils.dart';
import '../../domain/entities/pdf_annotation.dart';
import '../../domain/repositories/pdf_editor_repository.dart';
import '../../services/pdf_service.dart';
import '../datasources/local/annotation_dao.dart';
import '../models/annotation_model.dart';

class PdfEditorRepositoryImpl implements PdfEditorRepository {
  final PdfService _pdfService;
  final AnnotationDao _annotationDao;

  PdfEditorRepositoryImpl(this._pdfService, this._annotationDao);

  Future<String> _generateOutputPath(String prefix, String extension) async {
    final dir = await getApplicationDocumentsDirectory();
    final fileName = FileUtils.generateFileName(prefix, extension);
    return FileUtils.getUniqueFilePath('${dir.path}/edited', fileName);
  }

  Future<String> _generateOutputPathInDir(String dirPath, String prefix, String extension) async {
    final fileName = FileUtils.generateFileName(prefix, extension);
    return FileUtils.getUniqueFilePath(dirPath, fileName);
  }

  // ─── PDF Manipulation ───

  @override
  Future<Either<Failure, String>> mergePdfs(List<String> paths) async {
    try {
      if (paths.length < 2) {
        return Left(ValidationFailure('At least 2 PDFs are required for merging'));
      }
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'merged', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.mergePdfs(paths, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to merge PDFs: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> reorderPages(String path, List<int> newOrder) async {
    try {
      if (newOrder.isEmpty) {
        return Left(ValidationFailure('New page order cannot be empty'));
      }
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'reordered', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.reorderPages(path, newOrder, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to reorder pages: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> rotatePage(
    String path,
    int pageNumber,
    Rotation rotation,
  ) async {
    try {
      final angle = _rotationToAngle(rotation);
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'rotated', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.rotatePage(path, pageNumber, angle, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to rotate page: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> deletePages(String path, List<int> pageNumbers) async {
    try {
      if (pageNumbers.isEmpty) {
        return Left(ValidationFailure('No pages specified for deletion'));
      }
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'edited', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.deletePages(path, pageNumbers, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to delete pages: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> duplicatePage(String path, int pageNumber) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'duplicated', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.duplicatePage(path, pageNumber, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to duplicate page: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> compressPdf(String path, CompressionLevel level) async {
    try {
      final quality = _compressionLevelToQuality(level);
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'compressed', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.compressPdf(path, outputPath, quality: quality);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to compress PDF: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> encryptPdf(String path, String password) async {
    try {
      if (password.isEmpty) {
        return Left(ValidationFailure('Password cannot be empty'));
      }
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'encrypted', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.encryptPdf(path, password, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to encrypt PDF: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> decryptPdf(String path, String password) async {
    try {
      if (password.isEmpty) {
        return Left(ValidationFailure('Password cannot be empty'));
      }
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'decrypted', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.decryptPdf(path, password, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to decrypt PDF: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> addWatermark(String path, WatermarkOptions options) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'watermarked', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.addWatermark(
        path,
        options.text,
        outputPath,
        fontSize: options.fontSize,
        color: options.color,
        opacity: options.opacity,
        pages: options.pages,
      );
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to add watermark: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> addPageNumbers(String path, PageNumberOptions options) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'pagenum', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.addPageNumbers(
        path,
        outputPath,
        startNumber: options.startNumber,
        format: options.format,
        fontSize: options.fontSize,
        color: options.color,
        position: options.position,
      );
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to add page numbers: $e'));
    }
  }

  @override
  Future<Either<Failure, int>> getPageCount(String path) async {
    try {
      final count = await _pdfService.getPageCount(path);
      return Right(count);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to get page count: $e'));
    }
  }

  @override
  Future<Either<Failure, Uint8List>> renderPage(
    String path,
    int pageNumber, {
    int width = 800,
  }) async {
    try {
      final bytes = await _pdfService.renderPage(path, pageNumber, width: width);
      return Right(bytes);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to render page: $e'));
    }
  }

  // ─── Annotation Management ───

  @override
  Future<Either<Failure, List<PdfAnnotation>>> getAnnotations(int documentId) async {
    try {
      final models = await _annotationDao.getAnnotationsForDocument(documentId);
      return Right(models.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get annotations: $e'));
    }
  }

  @override
  Future<Either<Failure, PdfAnnotation>> addAnnotation(PdfAnnotation annotation) async {
    try {
      final model = AnnotationModel.fromEntity(annotation);
      final id = await _annotationDao.insertAnnotation(model);
      final inserted = await _annotationDao.getAnnotationsForDocument(annotation.documentId);
      final insertedModel = inserted.firstWhere((m) => m.id == id);
      return Right(insertedModel.toEntity());
    } catch (e) {
      return Left(DatabaseFailure('Failed to add annotation: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> removeAnnotation(int id) async {
    try {
      await _annotationDao.deleteAnnotation(id);
      return const Right(null);
    } catch (e) {
      return Left(DatabaseFailure('Failed to remove annotation: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> annotatePdf(
    String path,
    List<PdfAnnotation> annotations,
  ) async {
    try {
      final dir = await getApplicationDocumentsDirectory();
      final outputPath = await _generateOutputPathInDir(
        '${dir.path}/edited', 'annotated', 'pdf',
      );
      await FileUtils.ensureDirectory('${dir.path}/edited');
      final result = await _pdfService.annotatePdf(path, annotations, outputPath);
      return Right(result);
    } on PdfException catch (e) {
      return Left(PdfFailure(e.message));
    } catch (e) {
      return Left(UnknownFailure('Failed to annotate PDF: $e'));
    }
  }

  // ─── Helpers ───

  int _rotationToAngle(Rotation rotation) {
    switch (rotation) {
      case Rotation.clockwise90:
        return 90;
      case Rotation.counterClockwise90:
        return -90;
      case Rotation.rotate180:
        return 180;
    }
  }

  int _compressionLevelToQuality(CompressionLevel level) {
    switch (level) {
      case CompressionLevel.low:
        return 1;
      case CompressionLevel.medium:
        return 2;
      case CompressionLevel.high:
        return 3;
    }
  }
}
