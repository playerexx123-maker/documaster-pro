import 'package:dartz/dartz.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/errors/failures.dart';
import '../../domain/entities/search_result.dart';
import '../../domain/repositories/search_repository.dart';
import '../datasources/local/search_index_dao.dart';
import '../datasources/local/database_helper.dart';

class SearchRepositoryImpl implements SearchRepository {
  final SearchIndexDao _searchIndexDao;

  SearchRepositoryImpl(this._searchIndexDao);

  Future<Database> get _db async => await DatabaseHelper.database;

  List<SearchResult> _mapToSearchResults(List<Map<String, dynamic>> maps, SearchResultType type) {
    return maps.map((m) {
      final name = m['name'] as String? ?? 'Unknown';
      final ocrText = m['ocr_text'] as String?;
      final tags = m['tags'] as String?;

      String snippet = name;
      if (type == SearchResultType.pdfContent && ocrText != null && ocrText.isNotEmpty) {
        snippet = ocrText.length > 120 ? '${ocrText.substring(0, 120)}...' : ocrText;
      } else if (type == SearchResultType.ocrText && ocrText != null && ocrText.isNotEmpty) {
        snippet = ocrText.length > 120 ? '${ocrText.substring(0, 120)}...' : ocrText;
      } else if (type == SearchResultType.tag && tags != null && tags.isNotEmpty) {
        snippet = 'Tags: $tags';
      }

      return SearchResult(
        documentId: m['id'] as int? ?? 0,
        documentName: name,
        snippet: snippet,
        type: type,
        relevance: _calculateRelevance(name, snippet),
      );
    }).toList();
  }

  int _calculateRelevance(String name, String snippet) {
    // Simple relevance scoring
    int score = 0;
    if (name.toLowerCase() == snippet.toLowerCase()) score += 100;
    else if (name.toLowerCase().contains(snippet.toLowerCase())) score += 50;
    else score += 10;
    return score;
  }

  @override
  Future<Either<Failure, List<SearchResult>>> globalSearch(String query) async {
    try {
      final db = await _db;
      final maps = await db.rawQuery('''
        SELECT * FROM documents
        WHERE name LIKE ? OR ocr_text LIKE ? OR tags LIKE ?
        ORDER BY updated_at DESC
      ''', ['%$query%', '%$query%', '%$query%']);

      return Right(_mapToSearchResults(maps, SearchResultType.filename));
    } catch (e) {
      return Left(DatabaseFailure('Global search failed: $e'));
    }
  }

  @override
  Future<Either<Failure, List<SearchResult>>> searchFileNames(String query) async {
    try {
      final db = await _db;
      final maps = await db.rawQuery('''
        SELECT * FROM documents
        WHERE name LIKE ?
        ORDER BY name ASC
      ''', ['%$query%']);

      return Right(_mapToSearchResults(maps, SearchResultType.filename));
    } catch (e) {
      return Left(DatabaseFailure('File name search failed: $e'));
    }
  }

  @override
  Future<Either<Failure, List<SearchResult>>> searchPdfContents(String query) async {
    try {
      final db = await _db;
      final maps = await db.rawQuery('''
        SELECT * FROM documents
        WHERE file_type = 'pdf' AND (ocr_text LIKE ? OR name LIKE ?)
        ORDER BY updated_at DESC
      ''', ['%$query%', '%$query%']);

      return Right(_mapToSearchResults(maps, SearchResultType.pdfContent));
    } catch (e) {
      return Left(DatabaseFailure('PDF content search failed: $e'));
    }
  }

  @override
  Future<Either<Failure, List<SearchResult>>> searchOcrText(String query) async {
    try {
      final db = await _db;
      final maps = await db.rawQuery('''
        SELECT * FROM documents
        WHERE ocr_text LIKE ? AND ocr_text IS NOT NULL
        ORDER BY updated_at DESC
      ''', ['%$query%']);

      return Right(_mapToSearchResults(maps, SearchResultType.ocrText));
    } catch (e) {
      return Left(DatabaseFailure('OCR text search failed: $e'));
    }
  }

  @override
  Future<Either<Failure, List<SearchResult>>> searchTags(String query) async {
    try {
      final db = await _db;
      final maps = await db.rawQuery('''
        SELECT * FROM documents
        WHERE tags LIKE ? AND tags IS NOT NULL
        ORDER BY updated_at DESC
      ''', ['%$query%']);

      return Right(_mapToSearchResults(maps, SearchResultType.tag));
    } catch (e) {
      return Left(DatabaseFailure('Tag search failed: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> rebuildIndex() async {
    try {
      await _searchIndexDao.rebuildIndex();
      return const Right(null);
    } catch (e) {
      return Left(DatabaseFailure('Failed to rebuild search index: $e'));
    }
  }

  @override
  Future<Either<Failure, List<String>>> getRecentSearches() async {
    try {
      final db = await _db;
      final results = await db.query(
        'app_settings',
        where: 'key = ?',
        whereArgs: ['recent_searches'],
      );

      if (results.isEmpty) {
        return const Right([]);
      }

      final value = results.first['value'] as String? ?? '';
      if (value.isEmpty) return const Right([]);

      return Right(value.split('||').take(20).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get recent searches: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> addRecentSearch(String query) async {
    try {
      final db = await _db;

      // Get existing searches
      final results = await db.query(
        'app_settings',
        where: 'key = ?',
        whereArgs: ['recent_searches'],
      );

      List<String> searches = [];
      if (results.isNotEmpty) {
        final value = results.first['value'] as String? ?? '';
        if (value.isNotEmpty) {
          searches = value.split('||');
        }
      }

      // Remove if exists (to move to front) and add new
      searches.remove(query);
      searches.insert(0, query);

      // Keep only last 20
      if (searches.length > 20) {
        searches = searches.sublist(0, 20);
      }

      final newValue = searches.join('||');

      if (results.isEmpty) {
        await db.insert('app_settings', {
          'key': 'recent_searches',
          'value': newValue,
        });
      } else {
        await db.update(
          'app_settings',
          {'value': newValue},
          where: 'key = ?',
          whereArgs: ['recent_searches'],
        );
      }

      return const Right(null);
    } catch (e) {
      return Left(DatabaseFailure('Failed to add recent search: $e'));
    }
  }
}
