import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../../core/errors/exceptions.dart';
import '../../domain/entities/cloud_file.dart';
import '../../domain/repositories/cloud_repository.dart';
import '../datasources/remote/cloud_sync_service.dart';
import '../datasources/remote/google_drive_api.dart';
import '../datasources/remote/dropbox_api.dart';
import '../datasources/remote/onedrive_api.dart';
import '../datasources/local/database_helper.dart';
import 'package:sqflite/sqflite.dart';

class CloudRepositoryImpl implements CloudRepository {
  final GoogleDriveApi _googleDriveApi;
  final DropboxApi _dropboxApi;
  final OneDriveApi _oneDriveApi;

  CloudRepositoryImpl(
    this._googleDriveApi,
    this._dropboxApi,
    this._oneDriveApi,
  );

  CloudSyncService _getService(String provider) {
    switch (provider.toLowerCase()) {
      case 'google_drive':
      case 'googledrive':
        return _googleDriveApi;
      case 'dropbox':
        return _dropboxApi;
      case 'onedrive':
      case 'one_drive':
        return _oneDriveApi;
      default:
        throw ValidationException('Unsupported cloud provider: $provider');
    }
  }

  @override
  Future<Either<Failure, bool>> authenticate(String provider) async {
    try {
      final service = _getService(provider);
      final result = await service.connect(provider);
      return Right(result);
    } on ValidationException catch (e) {
      return Left(ValidationFailure(e.message, code: e.code));
    } catch (e) {
      return Left(NetworkFailure('Failed to authenticate with $provider: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> logout(String provider) async {
    try {
      final service = _getService(provider);
      await service.disconnect(provider);
      final db = await DatabaseHelper.database;
      await db.delete(
        'cloud_accounts',
        where: 'provider = ?',
        whereArgs: [provider],
      );
      return const Right(null);
    } on ValidationException catch (e) {
      return Left(ValidationFailure(e.message, code: e.code));
    } catch (e) {
      return Left(NetworkFailure('Failed to logout from $provider: $e'));
    }
  }

  @override
  Future<Either<Failure, List<CloudFile>>> listFiles(
    String provider, {
    String? folderId,
  }) async {
    try {
      final service = _getService(provider);
      final files = await service.listFiles(provider, folderId: folderId);
      return Right(
        files.map((f) => CloudFile(
          id: f['id'] as String,
          name: f['name'] as String,
          size: f['size'] as int? ?? 0,
          mimeType: f['mimeType'] as String? ?? 'application/octet-stream',
          modifiedAt: f['modifiedAt'] != null
              ? DateTime.parse(f['modifiedAt'] as String)
              : DateTime.now(),
          isFolder: f['isFolder'] as bool? ?? false,
          parentId: f['parentId'] as String?,
        )).toList(),
      );
    } on ValidationException catch (e) {
      return Left(ValidationFailure(e.message, code: e.code));
    } catch (e) {
      return Left(NetworkFailure('Failed to list files from $provider: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> uploadFile(
    String provider,
    String localPath, {
    String? parentId,
  }) async {
    try {
      final service = _getService(provider);
      await service.uploadFile(provider, localPath, parentId: parentId);
      return const Right(null);
    } on ValidationException catch (e) {
      return Left(ValidationFailure(e.message, code: e.code));
    } catch (e) {
      return Left(NetworkFailure('Failed to upload to $provider: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> downloadFile(
    String provider,
    String fileId,
    String localPath,
  ) async {
    try {
      final service = _getService(provider);
      await service.downloadFile(provider, fileId, localPath);
      return const Right(null);
    } on ValidationException catch (e) {
      return Left(ValidationFailure(e.message, code: e.code));
    } catch (e) {
      return Left(NetworkFailure('Failed to download from $provider: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> deleteFile(
    String provider,
    String fileId,
  ) async {
    try {
      final service = _getService(provider);
      await service.deleteFile(provider, fileId);
      return const Right(null);
    } on ValidationException catch (e) {
      return Left(ValidationFailure(e.message, code: e.code));
    } catch (e) {
      return Left(NetworkFailure('Failed to delete file from $provider: $e'));
    }
  }

  @override
  Future<Either<Failure, List<CloudAccount>>> getConnectedAccounts() async {
    try {
      final db = await DatabaseHelper.database;
      final rows = await db.query('cloud_accounts');
      return Right(
        rows.map((r) => CloudAccount(
          id: r['id'] as int?,
          provider: r['provider'] as String,
          accountEmail: r['account_email'] as String,
          syncEnabled: (r['sync_enabled'] as int? ?? 1) == 1,
          lastSyncAt: r['last_sync_at'] != null
              ? DateTime.fromMillisecondsSinceEpoch(r['last_sync_at'] as int)
              : null,
          createdAt: DateTime.fromMillisecondsSinceEpoch(
            r['created_at'] as int,
          ),
        )).toList(),
      );
    } catch (e) {
      return Left(DatabaseFailure('Failed to get cloud accounts: $e'));
    }
  }

  @override
  Future<Either<Failure, DateTime?>> getLastSyncTime(String provider) async {
    try {
      final db = await DatabaseHelper.database;
      final rows = await db.query(
        'cloud_accounts',
        where: 'provider = ?',
        whereArgs: [provider],
        limit: 1,
      );
      if (rows.isEmpty) {
        return const Right(null);
      }
      final lastSyncAt = rows.first['last_sync_at'] as int?;
      return Right(
        lastSyncAt != null
            ? DateTime.fromMillisecondsSinceEpoch(lastSyncAt)
            : null,
      );
    } catch (e) {
      return Left(DatabaseFailure('Failed to get last sync time: $e'));
    }
  }
}
