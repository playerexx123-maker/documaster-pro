import 'dart:io';
import 'package:dartz/dartz.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/errors/failures.dart';
import '../../core/utils/file_utils.dart';
import '../../domain/entities/document.dart';
import '../../domain/repositories/file_manager_repository.dart';

class FileManagerRepositoryImpl implements FileManagerRepository {
  FileManagerRepositoryImpl();

  Future<String> get _appDir async {
    final dir = await getApplicationDocumentsDirectory();
    return dir.path;
  }

  FileItem _entityToFileItem(FileSystemEntity entity) {
    final stat = entity.statSync();
    final isDir = entity is Directory;
    final name = entity.path.split('/').last;
    return FileItem(
      path: entity.path,
      name: name,
      type: isDir ? FileType.unknown : FileUtils.getFileType(entity.path),
      size: stat.size,
      modifiedAt: stat.modified,
      isDirectory: isDir,
    );
  }

  @override
  Future<Either<Failure, List<FileItem>>> listDirectory(String path) async {
    try {
      final dir = Directory(path);
      if (!await dir.exists()) {
        return Left(FileSystemFailure('Directory not found: $path'));
      }
      final entities = await dir.list().toList();
      final items = entities.map(_entityToFileItem).toList();

      // Sort: directories first, then by name
      items.sort((a, b) {
        if (a.isDirectory && !b.isDirectory) return -1;
        if (!a.isDirectory && b.isDirectory) return 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

      return Right(items);
    } catch (e) {
      return Left(FileSystemFailure('Failed to list directory: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> createFolder(String path, String name) async {
    try {
      final newDir = Directory('$path/$name');
      await newDir.create(recursive: true);
      return const Right(null);
    } catch (e) {
      return Left(FileSystemFailure('Failed to create folder: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> rename(String oldPath, String newName) async {
    try {
      final entity = FileSystemEntity.typeSync(oldPath);
      final parent = oldPath.substring(0, oldPath.lastIndexOf('/'));
      final newPath = '$parent/$newName';

      if (entity == FileSystemEntityType.directory) {
        await Directory(oldPath).rename(newPath);
      } else {
        await File(oldPath).rename(newPath);
      }
      return const Right(null);
    } catch (e) {
      return Left(FileSystemFailure('Failed to rename: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> copy(String sourcePath, String destPath) async {
    try {
      final entity = FileSystemEntity.typeSync(sourcePath);
      if (entity == FileSystemEntityType.directory) {
        await _copyDirectory(Directory(sourcePath), Directory(destPath));
      } else {
        await File(sourcePath).copy(destPath);
      }
      return const Right(null);
    } catch (e) {
      return Left(FileSystemFailure('Failed to copy: $e'));
    }
  }

  Future<void> _copyDirectory(Directory source, Directory dest) async {
    await dest.create(recursive: true);
    await for (final entity in source.list(recursive: false, followLinks: false)) {
      final name = entity.path.split('/').last;
      final newPath = '${dest.path}/$name';
      if (entity is Directory) {
        await _copyDirectory(entity, Directory(newPath));
      } else if (entity is File) {
        await entity.copy(newPath);
      }
    }
  }

  @override
  Future<Either<Failure, void>> move(String sourcePath, String destPath) async {
    try {
      final entity = FileSystemEntity.typeSync(sourcePath);
      if (entity == FileSystemEntityType.directory) {
        await Directory(sourcePath).rename(destPath);
      } else {
        await File(sourcePath).rename(destPath);
      }
      return const Right(null);
    } catch (e) {
      return Left(FileSystemFailure('Failed to move: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> delete(String path) async {
    try {
      final entity = FileSystemEntity.typeSync(path);
      if (entity == FileSystemEntityType.directory) {
        await Directory(path).delete(recursive: true);
      } else {
        await File(path).delete();
      }
      return const Right(null);
    } catch (e) {
      return Left(FileSystemFailure('Failed to delete: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> share(String path) async {
    try {
      final result = await Share.shareXFiles([XFile(path)]);
      if (result.status == ShareResultStatus.dismissed) {
        return const Right(null);
      }
      return const Right(null);
    } catch (e) {
      return Left(FileSystemFailure('Failed to share file: $e'));
    }
  }

  @override
  Future<Either<Failure, List<FileItem>>> search(String query, {FileType? type}) async {
    try {
      final appDir = await _appDir;
      final results = <FileItem>[];
      final dir = Directory(appDir);

      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          final name = entity.path.split('/').last.toLowerCase();
          if (name.contains(query.toLowerCase())) {
            final fileType = FileUtils.getFileType(entity.path);
            if (type == null || fileType == type) {
              results.add(_entityToFileItem(entity));
            }
          }
        }
      }
      return Right(results);
    } catch (e) {
      return Left(FileSystemFailure('Search failed: $e'));
    }
  }

  @override
  Future<Either<Failure, int>> getStorageUsage() async {
    try {
      final appDir = await _appDir;
      int totalSize = 0;
      final dir = Directory(appDir);

      if (await dir.exists()) {
        await for (final entity in dir.list(recursive: true, followLinks: false)) {
          if (entity is File) {
            totalSize += await entity.length();
          }
        }
      }
      return Right(totalSize);
    } catch (e) {
      return Left(FileSystemFailure('Failed to get storage usage: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> openFile(String path) async {
    try {
      final result = await OpenFilex.open(path);
      if (result.type != ResultType.done) {
        return Left(FileSystemFailure('Cannot open file: ${result.message}'));
      }
      return const Right(null);
    } catch (e) {
      return Left(FileSystemFailure('Failed to open file: $e'));
    }
  }
}
