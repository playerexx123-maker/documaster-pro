import 'dart:io';
import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../../core/errors/exceptions.dart';
import '../../domain/repositories/ai_repository.dart';
import '../../services/ai_service.dart';

class AIRepositoryImpl implements AIRepository {
  final AIService _aiService;

  AIRepositoryImpl(this._aiService);

  /// Helper to extract text content from a document file.
  /// For PDFs, this is a placeholder - in production, use a PDF text extraction library.
  Future<String> _extractDocumentText(String documentPath) async {
    try {
      final file = File(documentPath);
      if (!await file.exists()) {
        throw FileSystemException('Document not found: $documentPath');
      }
      // For text-based files, read directly
      if (documentPath.endsWith('.txt') ||
          documentPath.endsWith('.md') ||
          documentPath.endsWith('.csv')) {
        return await file.readAsString();
      }
      // For PDFs and other formats, return a placeholder
      // In production, use pdf_text or syncfusion to extract text
      return 'Document content from $documentPath';
    } catch (e) {
      throw FileSystemException('Failed to extract text: $e');
    }
  }

  @override
  Future<Either<Failure, String>> summarizePdf(String pdfPath) async {
    try {
      final documentText = await _extractDocumentText(pdfPath);
      final summary = await _aiService.summarizeText(documentText);
      return Right(summary);
    } on AppException catch (e) {
      return Left(UnknownFailure('Summarization failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during summarization: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> translateDocument(String documentPath, String targetLanguage) async {
    try {
      final documentText = await _extractDocumentText(documentPath);
      final translation = await _aiService.translateText(
        documentText,
        targetLanguage,
      );
      return Right(translation);
    } on AppException catch (e) {
      return Left(UnknownFailure('Translation failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during translation: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> explainText(String text, {String? context}) async {
    try {
      final explanation = await _aiService.explainText(text, context: context);
      return Right(explanation);
    } on AppException catch (e) {
      return Left(UnknownFailure('Explanation failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during explanation: $e'));
    }
  }

  @override
  Future<Either<Failure, List<Map<String, dynamic>>>> extractTables(String pdfPath, int pageNumber) async {
    try {
      final documentText = await _extractDocumentText(pdfPath);
      final tables = await _aiService.extractTables(documentText);
      return Right(tables);
    } on AppException catch (e) {
      return Left(UnknownFailure('Table extraction failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during table extraction: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> generateTitle(String documentPath) async {
    try {
      final documentText = await _extractDocumentText(documentPath);
      final title = await _aiService.generateTitle(documentText);
      return Right(title);
    } on AppException catch (e) {
      return Left(UnknownFailure('Title generation failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during title generation: $e'));
    }
  }

  @override
  Future<Either<Failure, List<String>>> generateTags(String documentPath) async {
    try {
      final documentText = await _extractDocumentText(documentPath);
      final tags = await _aiService.generateTags(documentText);
      return Right(tags);
    } on AppException catch (e) {
      return Left(UnknownFailure('Tag generation failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during tag generation: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> chatWithPdf(String pdfPath, String question) async {
    try {
      final documentText = await _extractDocumentText(pdfPath);
      final response = await _aiService.chatWithDocument(documentText, question);
      return Right(response);
    } on AppException catch (e) {
      return Left(UnknownFailure('Chat failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during chat: $e'));
    }
  }
}
