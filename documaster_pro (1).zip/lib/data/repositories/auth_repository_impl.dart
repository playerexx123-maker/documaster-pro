import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../../domain/repositories/auth_repository.dart';
import '../datasources/local/biometric_auth.dart';
import '../datasources/local/secure_storage.dart';
import '../../core/utils/encryption_utils.dart';

class AuthRepositoryImpl implements AuthRepository {
  final BiometricAuth _biometricAuth;
  final SecureStorage _secureStorage;

  static const String _pinHashKey = 'pin_hash';
  static const String _biometricEnabledKey = 'biometric_enabled';

  AuthRepositoryImpl(this._biometricAuth, this._secureStorage);

  @override
  Future<Either<Failure, bool>> isBiometricAvailable() async {
    try {
      final isAvailable = await _biometricAuth.isAvailable();
      return Right(isAvailable);
    } catch (e) {
      return Left(AuthFailure('Failed to check biometric availability: $e'));
    }
  }

  @override
  Future<Either<Failure, bool>> authenticateWithBiometrics() async {
    try {
      final didAuthenticate = await _biometricAuth.authenticate();
      return Right(didAuthenticate);
    } catch (e) {
      return Left(AuthFailure('Biometric authentication failed: $e'));
    }
  }

  @override
  Future<Either<Failure, bool>> setupPin(String pin) async {
    try {
      if (pin.length < 4 || pin.length > 6) {
        return Left(const ValidationFailure(
          'PIN must be between 4 and 6 digits',
          code: 'INVALID_PIN_LENGTH',
        ));
      }
      if (!RegExp(r'^\d+$').hasMatch(pin)) {
        return Left(const ValidationFailure(
          'PIN must contain only digits',
          code: 'INVALID_PIN_FORMAT',
        ));
      }
      final pinHash = EncryptionUtils.hashPin(pin);
      await _secureStorage.write(_pinHashKey, pinHash);
      return Right(true);
    } catch (e) {
      return Left(AuthFailure('Failed to set up PIN: $e'));
    }
  }

  @override
  Future<Either<Failure, bool>> verifyPin(String pin) async {
    try {
      final storedHash = await _secureStorage.read(_pinHashKey);
      if (storedHash == null || storedHash.isEmpty) {
        return Left(const AuthFailure(
          'No PIN has been set up',
          code: 'PIN_NOT_SET',
        ));
      }
      final isValid = EncryptionUtils.verifyPin(pin, storedHash);
      return Right(isValid);
    } catch (e) {
      return Left(AuthFailure('PIN verification failed: $e'));
    }
  }

  @override
  Future<Either<Failure, bool>> isPinSetup() async {
    try {
      final storedHash = await _secureStorage.read(_pinHashKey);
      return Right(storedHash != null && storedHash.isNotEmpty);
    } catch (e) {
      return Left(AuthFailure('Failed to check PIN status: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> enableBiometric(bool enable) async {
    try {
      await _secureStorage.write(_biometricEnabledKey, enable.toString());
      return const Right(null);
    } catch (e) {
      return Left(AuthFailure('Failed to enable biometric: $e'));
    }
  }

  @override
  Future<Either<Failure, bool>> isBiometricEnabled() async {
    try {
      final value = await _secureStorage.read(_biometricEnabledKey);
      return Right(value == 'true');
    } catch (e) {
      return Left(AuthFailure('Failed to check biometric status: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> setPin(String pin) async {
    try {
      if (pin.length < 4 || pin.length > 6) {
        return Left(const ValidationFailure(
          'PIN must be between 4 and 6 digits',
          code: 'INVALID_PIN_LENGTH',
        ));
      }
      if (!RegExp(r'^\d+$').hasMatch(pin)) {
        return Left(const ValidationFailure(
          'PIN must contain only digits',
          code: 'INVALID_PIN_FORMAT',
        ));
      }
      final pinHash = EncryptionUtils.hashPin(pin);
      await _secureStorage.write(_pinHashKey, pinHash);
      return const Right(null);
    } catch (e) {
      return Left(AuthFailure('Failed to set PIN: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> clearPin() async {
    try {
      await _secureStorage.delete(_pinHashKey);
      return const Right(null);
    } catch (e) {
      return Left(AuthFailure('Failed to clear PIN: $e'));
    }
  }
}
