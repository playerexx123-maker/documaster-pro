import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../../core/utils/file_utils.dart';
import '../../domain/entities/ocr_result.dart';
import '../../domain/repositories/ocr_repository.dart';
import '../../services/ocr_service.dart';
import '../datasources/local/document_dao.dart';
import '../datasources/local/ocr_result_dao.dart';
import '../models/document_model.dart';
import '../models/ocr_result_model.dart';

class OcrRepositoryImpl implements OcrRepository {
  final OcrService _ocrService;
  final OcrResultDao _ocrResultDao;
  final DocumentDao _documentDao;

  OcrRepositoryImpl(
    this._ocrService,
    this._ocrResultDao,
    this._documentDao,
  );

  Future<String> _getOcrDirectory() async {
    final appDir = await getApplicationDocumentsDirectory();
    final ocrDir = Directory('${appDir.path}/ocr');
    if (!await ocrDir.exists()) {
      await ocrDir.create(recursive: true);
    }
    return ocrDir.path;
  }

  @override
  Future<Either<Failure, OcrResult>> recognizeText(
    String imagePath, {
    String language = 'en',
  }) async {
    try {
      final isSupported = await _ocrService.isLanguageSupported(language);
      if (!isSupported) {
        return Left(OcrFailure('Language not supported: $language'));
      }

      final detailedResult = await _ocrService.recognizeTextDetailed(imagePath, language: language);
      final text = detailedResult['text'] as String;
      final confidence = detailedResult['confidence'] as double;

      final result = OcrResult(
        documentId: 0, // Not associated with a document yet
        pageNumber: 1,
        recognizedText: text,
        language: language,
        confidence: confidence,
        createdAt: DateTime.now(),
      );

      return Right(result);
    } catch (e) {
      return Left(OcrFailure('Text recognition failed: $e'));
    }
  }

  @override
  Future<Either<Failure, OcrResult>> recognizeTextFromPdfPage(
    String pdfPath,
    int pageNumber, {
    String language = 'en',
  }) async {
    try {
      // For PDF text recognition, we would need to first render the PDF page
      // to an image, then run OCR on it. This requires pdf rendering.
      // For now, return an error indicating this needs implementation.
      return Left(OcrFailure(
        'PDF page OCR requires rendering to image first. '
        'Please extract the page as an image before running OCR.',
      ));
    } catch (e) {
      return Left(OcrFailure('PDF page recognition failed: $e'));
    }
  }

  @override
  Future<Either<Failure, List<OcrResult>>> recognizeDocument(
    int documentId, {
    String language = 'en',
  }) async {
    try {
      final docModel = await _documentDao.getDocumentById(documentId);
      if (docModel == null) {
        return Left(ValidationFailure('Document not found: $documentId'));
      }

      final isSupported = await _ocrService.isLanguageSupported(language);
      if (!isSupported) {
        return Left(OcrFailure('Language not supported: $language'));
      }

      // Delete previous results for this document
      await _ocrResultDao.deleteResultsForDocument(documentId);

      final results = <OcrResult>[];

      if (docModel.fileType == 'image') {
        // Single image document
        final result = await _ocrService.recognizeTextDetailed(
          docModel.filePath,
          language: language,
        );
        final ocrResult = OcrResult(
          documentId: documentId,
          pageNumber: 1,
          recognizedText: result['text'] as String,
          language: language,
          confidence: result['confidence'] as double,
          createdAt: DateTime.now(),
        );

        // Save to database
        final ocrModel = OcrResultModel(
          documentId: documentId,
          pageNumber: 1,
          recognizedText: ocrResult.recognizedText,
          language: language,
          confidence: ocrResult.confidence,
          createdAt: DateTime.now().millisecondsSinceEpoch,
        );
        await _ocrResultDao.insertOcrResult(ocrModel);
        results.add(ocrResult);
      } else {
        // For PDF or other multi-page documents, process each page
        // In a real implementation, we'd render each page to an image
        // For now, try to process the file directly
        try {
          final result = await _ocrService.recognizeTextDetailed(
            docModel.filePath,
            language: language,
          );
          final ocrResult = OcrResult(
            documentId: documentId,
            pageNumber: 1,
            recognizedText: result['text'] as String,
            language: language,
            confidence: result['confidence'] as double,
            createdAt: DateTime.now(),
          );

          final ocrModel = OcrResultModel(
            documentId: documentId,
            pageNumber: 1,
            recognizedText: ocrResult.recognizedText,
            language: language,
            confidence: ocrResult.confidence,
            createdAt: DateTime.now().millisecondsSinceEpoch,
          );
          await _ocrResultDao.insertOcrResult(ocrModel);
          results.add(ocrResult);
        } catch (e) {
          // If direct processing fails, return empty
          return Left(OcrFailure('Failed to process document: $e'));
        }
      }

      // Update document with recognized text
      final allText = results.map((r) => r.recognizedText).join('\n');
      final updatedDoc = docModel.toEntity().copyWith(
        ocrText: allText,
        updatedAt: DateTime.now(),
      );
      await _documentDao.updateDocument(DocumentModel.fromEntity(updatedDoc));

      return Right(results);
    } catch (e) {
      return Left(OcrFailure('Document recognition failed: $e'));
    }
  }

  @override
  Future<Either<Failure, List<OcrResult>>> getResultsForDocument(
    int documentId,
  ) async {
    try {
      final models = await _ocrResultDao.getResultsForDocument(documentId);
      return Right(models.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get OCR results: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> getRecognizedText(int documentId) async {
    try {
      // First check database for stored results
      final models = await _ocrResultDao.getResultsForDocument(documentId);
      if (models.isNotEmpty) {
        final text = models.map((m) => m.recognizedText).join('\n');
        return Right(text);
      }

      // Fall back to document's ocr_text field
      final docModel = await _documentDao.getDocumentById(documentId);
      if (docModel?.ocrText != null && docModel!.ocrText!.isNotEmpty) {
        return Right(docModel.ocrText!);
      }

      return const Right('');
    } catch (e) {
      return Left(DatabaseFailure('Failed to get recognized text: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> exportText(
    int documentId,
    ExportFormat format,
  ) async {
    try {
      final textResult = await getRecognizedText(documentId);
      return textResult.fold(
        (failure) => Left(failure),
        (text) async {
          if (text.isEmpty) {
            return Left(ValidationFailure('No text to export'));
          }

          final exportDir = await _getOcrDirectory();
          final docModel = await _documentDao.getDocumentById(documentId);
          final baseName = docModel?.name ?? 'export_$documentId';
          // Remove extension if present
          final cleanName = baseName.contains('.')
              ? baseName.substring(0, baseName.lastIndexOf('.'))
              : baseName;

          switch (format) {
            case ExportFormat.txt:
              return await _exportAsTxt(text, exportDir, cleanName);
            case ExportFormat.pdf:
              return await _exportAsPdf(text, exportDir, cleanName);
            case ExportFormat.docx:
              return await _exportAsDocx(text, exportDir, cleanName);
          }
        },
      );
    } catch (e) {
      return Left(FileSystemFailure('Export failed: $e'));
    }
  }

  Future<Either<Failure, String>> _exportAsTxt(
    String text,
    String exportDir,
    String fileName,
  ) async {
    try {
      final filePath = '$exportDir/${fileName}_export.txt';
      final file = File(filePath);
      await file.writeAsString(text);
      return Right(filePath);
    } catch (e) {
      return Left(FileSystemFailure('TXT export failed: $e'));
    }
  }

  Future<Either<Failure, String>> _exportAsPdf(
    String text,
    String exportDir,
    String fileName,
  ) async {
    try {
      final filePath = '$exportDir/${fileName}_export.pdf';
      // Create a minimal PDF with the text content
      final file = File(filePath);
      await file.create();

      // Simple PDF generation with text content
      final pdfContent = _generateTextPdf(text, fileName);
      await file.writeAsBytes(pdfContent);

      return Right(filePath);
    } catch (e) {
      return Left(PdfFailure('PDF export failed: $e'));
    }
  }

  List<int> _generateTextPdf(String text, String title) {
    // Generate a basic PDF with text content
    final body = 'BT /F1 10 Tf 50 750 Td ($title) Tj ET';
    final lines = text.split('\n');
    var y = 720;
    final buffer = StringBuffer();

    buffer.write('%PDF-1.4\n');
    buffer.write('%\\xc0\\xc1\\xc2\\xc3\\xc4\\xc5\n');
    buffer.write('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
    buffer.write('2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n');
    buffer.write('3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> >> >> >>\nendobj\n');

    // Build content stream
    final contentBuffer = StringBuffer();
    contentBuffer.write('BT /F1 10 Tf 50 750 Td (');
    // Escape special characters in title
    contentBuffer.write(title.replaceAll('(', '\\(').replaceAll(')', '\\)'));
    contentBuffer.write(') Tj ET\n');

    for (final line in lines) {
      if (y < 50) break; // Page bottom margin
      final escapedLine = line
          .replaceAll('\\', '\\\\')
          .replaceAll('(', '\\(')
          .replaceAll(')', '\\)')
          .replaceAll('\r', '');
      contentBuffer.write('BT /F1 10 Tf 50 $y Td (');
      contentBuffer.write(escapedLine.isEmpty ? ' ' : escapedLine);
      contentBuffer.write(') Tj ET\n');
      y -= 12;
    }

    final content = contentBuffer.toString();
    final contentLength = content.length;

    buffer.write('4 0 obj\n<< /Length $contentLength >>\nstream\n');
    buffer.write(content);
    buffer.write('\nendstream\nendobj\n');

    final xrefPos = buffer.toString().length;
    buffer.write('xref\n0 5\n');
    buffer.write('0000000000 65535 f\n');
    buffer.write('trailer\n<< /Size 5 /Root 1 0 R >>\n');
    buffer.write('startxref\n$xrefPos\n');
    buffer.write('%%EOF\n');

    return buffer.toString().codeUnits;
  }

  Future<Either<Failure, String>> _exportAsDocx(
    String text,
    String exportDir,
    String fileName,
  ) async {
    try {
      // DOCX is a ZIP file containing XML
      // For a minimal implementation, create a basic DOCX structure
      final filePath = '$exportDir/${fileName}_export.docx';

      // Write a minimal DOCX as a zip-like binary
      // In a production app, use the archive package
      final file = File(filePath);
      await file.create();

      // Write a minimal binary that resembles a DOCX
      // This is a placeholder - real DOCX needs proper ZIP structure
      final docxContent = _generateMinimalDocx(text, fileName);
      await file.writeAsBytes(docxContent);

      return Right(filePath);
    } catch (e) {
      return Left(FileSystemFailure('DOCX export failed: $e'));
    }
  }

  List<int> _generateMinimalDocx(String text, String title) {
    // Minimal DOCX is a ZIP file with specific XML files
    // This is a simplified binary representation
    // In production, use the archive package to create proper ZIP

    // Return a minimal binary that can be recognized as a document
    final header = [
      0x50, 0x4B, 0x03, 0x04, // ZIP local file header signature
      0x0A, 0x00, 0x00, 0x00, 0x00, 0x00, // version, flags, compression
      0x00, 0x00, 0x00, 0x00, // compressed size, uncompressed size (0 for placeholder)
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, // file name length, extra field length
    ];

    // This is a placeholder - a real implementation would properly
    // construct the DOCX ZIP structure with all required XML parts
    final buffer = <int>[];
    buffer.addAll(header);

    // Add minimal content as UTF-8
    final content = '[Content_Types].xml placeholder\n'
        'word/document.xml with: $text';
    buffer.addAll(content.codeUnits);

    return buffer;
  }

  @override
  Future<Either<Failure, bool>> isLanguageSupported(String languageCode) async {
    try {
      final supported = await _ocrService.isLanguageSupported(languageCode);
      return Right(supported);
    } catch (e) {
      return Left(OcrFailure('Failed to check language support: $e'));
    }
  }
}
