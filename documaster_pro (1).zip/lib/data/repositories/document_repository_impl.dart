import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../../domain/entities/document.dart';
import '../../domain/repositories/document_repository.dart';
import '../datasources/local/document_dao.dart';
import '../models/document_model.dart';

class DocumentRepositoryImpl implements DocumentRepository {
  final DocumentDao _documentDao;

  DocumentRepositoryImpl(this._documentDao);

  @override
  Future<Either<Failure, List<Document>>> getAllDocuments() async {
    try {
      final docs = await _documentDao.getAllDocuments();
      return Right(docs.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get documents: \$e'));
    }
  }

  @override
  Future<Either<Failure, List<Document>>> getRecentDocuments({int limit = 20}) async {
    try {
      final docs = await _documentDao.getRecentDocuments(limit);
      return Right(docs.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get recent documents: \$e'));
    }
  }

  @override
  Future<Either<Failure, List<Document>>> getFavoriteDocuments() async {
    try {
      final docs = await _documentDao.getFavoriteDocuments();
      return Right(docs.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get favorite documents: \$e'));
    }
  }

  @override
  Future<Either<Failure, Document?>> getDocumentById(int id) async {
    try {
      final doc = await _documentDao.getDocumentById(id);
      return Right(doc?.toEntity());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get document: \$e'));
    }
  }

  @override
  Future<Either<Failure, List<Document>>> getDocumentsInFolder(int folderId) async {
    try {
      final docs = await _documentDao.getDocumentsInFolder(folderId);
      return Right(docs.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get folder documents: \$e'));
    }
  }

  @override
  Future<Either<Failure, List<Document>>> searchDocuments(String query) async {
    try {
      final docs = await _documentDao.searchDocuments(query);
      return Right(docs.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Search failed: \$e'));
    }
  }

  @override
  Future<Either<Failure, Document>> createDocument(Document document) async {
    try {
      final model = DocumentModel.fromEntity(document);
      final id = await _documentDao.insertDocument(model);
      return Right(document.copyWith(id: id));
    } catch (e) {
      return Left(DatabaseFailure('Failed to create document: \$e'));
    }
  }

  @override
  Future<Either<Failure, Document>> updateDocument(Document document) async {
    try {
      final model = DocumentModel.fromEntity(document);
      await _documentDao.updateDocument(model);
      return Right(document);
    } catch (e) {
      return Left(DatabaseFailure('Failed to update document: \$e'));
    }
  }

  @override
  Future<Either<Failure, void>> deleteDocument(int id) async {
    try {
      await _documentDao.deleteDocument(id);
      return const Right(null);
    } catch (e) {
      return Left(DatabaseFailure('Failed to delete document: \$e'));
    }
  }

  @override
  Future<Either<Failure, void>> toggleFavorite(int id) async {
    try {
      await _documentDao.toggleFavorite(id);
      return const Right(null);
    } catch (e) {
      return Left(DatabaseFailure('Failed to toggle favorite: \$e'));
    }
  }

  @override
  Future<Either<Failure, void>> updateAccessTime(int id) async {
    try {
      await _documentDao.updateAccessTime(id);
      return const Right(null);
    } catch (e) {
      return Left(DatabaseFailure('Failed to update access time: \$e'));
    }
  }

  @override
  Future<Either<Failure, List<Document>>> getDocumentsByType(FileType type) async {
    try {
      final docs = await _documentDao.getDocumentsByType(type.name);
      return Right(docs.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get documents by type: \$e'));
    }
  }
}
