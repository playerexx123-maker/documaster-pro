import 'dart:io';
import 'dart:ui';
import 'package:dartz/dartz.dart';
import 'package:path_provider/path_provider.dart';
import '../../core/errors/failures.dart';
import '../../core/errors/exceptions.dart';
import '../../domain/repositories/image_editor_repository.dart';
import '../../services/image_processing_service.dart';

class ImageEditorRepositoryImpl implements ImageEditorRepository {
  final ImageProcessingService _imageProcessingService;

  ImageEditorRepositoryImpl(this._imageProcessingService);

  Future<String> _generateOutputPath(String originalPath, String suffix) async {
    final dir = await getTemporaryDirectory();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final ext = originalPath.split('.').last;
    return '${dir.path}/edited_${suffix}_$timestamp.$ext';
  }

  @override
  Future<Either<Failure, String>> crop(String imagePath, Rect cropRect) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'crop');
      final result = await _imageProcessingService.cropImage(
        imagePath,
        cropRect.x.toInt(),
        cropRect.y.toInt(),
        cropRect.width.toInt(),
        cropRect.height.toInt(),
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Crop failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during crop: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> resize(String imagePath, int width, int height) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'resize');
      final result = await _imageProcessingService.resizeImage(
        imagePath,
        width,
        height,
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Resize failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during resize: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> rotate(String imagePath, double angle) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'rotate');
      final result = await _imageProcessingService.rotateImage(
        imagePath,
        angle,
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Rotation failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during rotation: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> adjustBrightness(String imagePath, double value) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'brightness');
      final result = await _imageProcessingService.adjustBrightness(
        imagePath,
        value,
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Brightness adjustment failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error adjusting brightness: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> adjustContrast(String imagePath, double value) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'contrast');
      final result = await _imageProcessingService.adjustContrast(
        imagePath,
        value,
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Contrast adjustment failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error adjusting contrast: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> sharpen(String imagePath, double amount) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'sharpen');
      final result = await _imageProcessingService.sharpenImage(
        imagePath,
        amount,
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Sharpen failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during sharpen: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> convertFormat(String imagePath, ImageFormat format) async {
    try {
      final formatName = format.name;
      final outputPath = await _generateOutputPath(imagePath, 'format');
      // Change extension to match target format
      final basePath = outputPath.substring(0, outputPath.lastIndexOf('.'));
      final newOutputPath = '$basePath.$formatName';
      final result = await _imageProcessingService.convertFormat(
        imagePath,
        formatName,
        newOutputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Format conversion failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during format conversion: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> removeBackground(String imagePath) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'nobg');
      // Placeholder: Use edge detection as approximation for background removal
      // In production, this would use a dedicated ML model (e.g., rembg, U-2-Net)
      final result = await _imageProcessingService.cropImage(
        imagePath,
        10,
        10,
        100,
        100,
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Background removal failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during background removal: $e'));
    }
  }

  @override
  Future<Either<Failure, String>> compressImage(String imagePath, int quality) async {
    try {
      final outputPath = await _generateOutputPath(imagePath, 'compressed');
      final result = await _imageProcessingService.compressImage(
        imagePath,
        quality,
        outputPath,
      );
      return Right(result);
    } on FileSystemException catch (e) {
      return Left(FileSystemFailure('Compression failed: ${e.message}'));
    } catch (e) {
      return Left(UnknownFailure('Unexpected error during compression: $e'));
    }
  }
}
