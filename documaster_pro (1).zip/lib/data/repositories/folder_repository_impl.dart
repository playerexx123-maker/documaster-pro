import 'package:dartz/dartz.dart';
import '../../core/errors/failures.dart';
import '../../domain/entities/folder.dart';
import '../../domain/repositories/folder_repository.dart';
import '../datasources/local/folder_dao.dart';
import '../models/folder_model.dart';

class FolderRepositoryImpl implements FolderRepository {
  final FolderDao _folderDao;

  FolderRepositoryImpl(this._folderDao);

  @override
  Future<Either<Failure, List<Folder>>> getAllFolders() async {
    try {
      final folders = await _folderDao.getAllFolders();
      return Right(folders.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get folders: $e'));
    }
  }

  @override
  Future<Either<Failure, Folder?>> getFolderById(int id) async {
    try {
      final folder = await _folderDao.getFolderById(id);
      return Right(folder?.toEntity());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get folder: $e'));
    }
  }

  @override
  Future<Either<Failure, List<Folder>>> getRootFolders() async {
    try {
      final folders = await _folderDao.getRootFolders();
      return Right(folders.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get root folders: $e'));
    }
  }

  @override
  Future<Either<Failure, List<Folder>>> getSubFolders(int parentId) async {
    try {
      final folders = await _folderDao.getSubFolders(parentId);
      return Right(folders.map((m) => m.toEntity()).toList());
    } catch (e) {
      return Left(DatabaseFailure('Failed to get subfolders: $e'));
    }
  }

  @override
  Future<Either<Failure, Folder>> createFolder(Folder folder) async {
    try {
      final model = FolderModel.fromEntity(folder);
      final id = await _folderDao.insertFolder(model);
      return Right(folder.copyWith(id: id));
    } catch (e) {
      return Left(DatabaseFailure('Failed to create folder: $e'));
    }
  }

  @override
  Future<Either<Failure, Folder>> updateFolder(Folder folder) async {
    try {
      final model = FolderModel.fromEntity(folder);
      await _folderDao.updateFolder(model);
      return Right(folder);
    } catch (e) {
      return Left(DatabaseFailure('Failed to update folder: $e'));
    }
  }

  @override
  Future<Either<Failure, void>> deleteFolder(int id) async {
    try {
      await _folderDao.deleteFolder(id);
      return const Right(null);
    } catch (e) {
      return Left(DatabaseFailure('Failed to delete folder: $e'));
    }
  }

  @override
  Future<Either<Failure, List<Folder>>> getFolderPath(int folderId) async {
    try {
      final path = <Folder>[];
      var currentId = folderId;

      while (currentId != 0) {
        final folder = await _folderDao.getFolderById(currentId);
        if (folder == null) break;
        final entity = folder.toEntity();
        path.insert(0, entity);
        currentId = folder.parentId ?? 0;
      }

      return Right(path);
    } catch (e) {
      return Left(DatabaseFailure('Failed to get folder path: $e'));
    }
  }
}
