abstract class CloudSyncService {
  Future<bool> connect(String provider);
  Future<void> disconnect(String provider);
  Future<List<Map<String, dynamic>>> listFiles(String provider, {String? folderId});
  Future<void> uploadFile(String provider, String localPath, {String? parentId});
  Future<void> downloadFile(String provider, String fileId, String localPath);
  Future<void> deleteFile(String provider, String fileId);
}
