import 'cloud_sync_service.dart';

class GoogleDriveApi implements CloudSyncService {
  @override
  Future<bool> connect(String provider) async => false;
  @override
  Future<void> disconnect(String provider) async {}
  @override
  Future<List<Map<String, dynamic>>> listFiles(String provider, {String? folderId}) async => [];
  @override
  Future<void> uploadFile(String provider, String localPath, {String? parentId}) async {}
  @override
  Future<void> downloadFile(String provider, String fileId, String localPath) async {}
  @override
  Future<void> deleteFile(String provider, String fileId) async {}
}
