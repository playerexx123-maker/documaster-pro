import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';

class ScanSessionDao {
  Future<Database> get _db async => await DatabaseHelper.database;

  Future<int> createSession(String name) async {
    final db = await _db;
    return await db.insert('scan_sessions', {
      'name': name,
      'status': 'in_progress',
      'filter_type': 'color',
      'created_at': DateTime.now().millisecondsSinceEpoch,
    });
  }

  Future<void> completeSession(int sessionId, int documentId) async {
    final db = await _db;
    await db.update(
      'scan_sessions',
      {
        'status': 'completed',
        'document_id': documentId,
        'completed_at': DateTime.now().millisecondsSinceEpoch,
      },
      where: 'id = ?',
      whereArgs: [sessionId],
    );
  }

  Future<void> cancelSession(int sessionId) async {
    final db = await _db;
    await db.update(
      'scan_sessions',
      {'status': 'cancelled'},
      where: 'id = ?',
      whereArgs: [sessionId],
    );
  }

  Future<void> addPage(int sessionId, String imagePath, int pageNumber) async {
    final db = await _db;
    await db.insert('scan_pages', {
      'session_id': sessionId,
      'image_path': imagePath,
      'page_number': pageNumber,
      'filter_applied': 'none',
    });
  }

  Future<List<Map<String, dynamic>>> getSessionPages(int sessionId) async {
    final db = await _db;
    return await db.query(
      'scan_pages',
      where: 'session_id = ?',
      whereArgs: [sessionId],
      orderBy: 'page_number',
    );
  }

  Future<void> updatePageProcessedPath(int pageId, String processedPath, String filter) async {
    final db = await _db;
    await db.update(
      'scan_pages',
      {
        'processed_path': processedPath,
        'filter_applied': filter,
      },
      where: 'id = ?',
      whereArgs: [pageId],
    );
  }
}
