import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../../models/document_model.dart';

class DocumentDao {
  Future<Database> get _db async => await DatabaseHelper.database;

  Future<List<DocumentModel>> getAllDocuments() async {
    final db = await _db;
    final maps = await db.query('documents', orderBy: 'updated_at DESC');
    return maps.map((m) => DocumentModel.fromMap(m)).toList();
  }

  Future<List<DocumentModel>> getRecentDocuments(int limit) async {
    final db = await _db;
    final maps = await db.query(
      'documents',
      orderBy: 'updated_at DESC',
      limit: limit,
    );
    return maps.map((m) => DocumentModel.fromMap(m)).toList();
  }

  Future<List<DocumentModel>> getFavoriteDocuments() async {
    final db = await _db;
    final maps = await db.query(
      'documents',
      where: 'is_favorite = ?',
      whereArgs: [1],
      orderBy: 'updated_at DESC',
    );
    return maps.map((m) => DocumentModel.fromMap(m)).toList();
  }

  Future<DocumentModel?> getDocumentById(int id) async {
    final db = await _db;
    final maps = await db.query(
      'documents',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isEmpty) return null;
    return DocumentModel.fromMap(maps.first);
  }

  Future<List<DocumentModel>> getDocumentsInFolder(int folderId) async {
    final db = await _db;
    final maps = await db.query(
      'documents',
      where: 'folder_id = ?',
      whereArgs: [folderId],
      orderBy: 'updated_at DESC',
    );
    return maps.map((m) => DocumentModel.fromMap(m)).toList();
  }

  Future<List<DocumentModel>> searchDocuments(String query) async {
    final db = await _db;
    final maps = await db.query(
      'documents',
      where: 'name LIKE ? OR ocr_text LIKE ?',
      whereArgs: ['%\$query%', '%\$query%'],
      orderBy: 'updated_at DESC',
    );
    return maps.map((m) => DocumentModel.fromMap(m)).toList();
  }

  Future<int> insertDocument(DocumentModel document) async {
    final db = await _db;
    return await db.insert('documents', document.toMap());
  }

  Future<void> updateDocument(DocumentModel document) async {
    final db = await _db;
    await db.update(
      'documents',
      document.toMap(),
      where: 'id = ?',
      whereArgs: [document.id],
    );
  }

  Future<void> deleteDocument(int id) async {
    final db = await _db;
    await db.delete('documents', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> toggleFavorite(int id) async {
    final db = await _db;
    await db.rawUpdate(
      'UPDATE documents SET is_favorite = CASE WHEN is_favorite = 1 THEN 0 ELSE 1 END WHERE id = ?',
      [id],
    );
  }

  Future<void> updateAccessTime(int id) async {
    final db = await _db;
    await db.update(
      'documents',
      {'accessed_at': DateTime.now().millisecondsSinceEpoch},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<DocumentModel>> getDocumentsByType(String fileType) async {
    final db = await _db;
    final maps = await db.query(
      'documents',
      where: 'file_type = ?',
      whereArgs: [fileType],
      orderBy: 'updated_at DESC',
    );
    return maps.map((m) => DocumentModel.fromMap(m)).toList();
  }
}
