import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../../config/constants.dart';

class DatabaseHelper {
  static Database? _database;

  static Future<Database> get database async {
    _database ??= await _initDatabase();
    return _database!;
  }

  static Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, AppConstants.databaseName);

    return await openDatabase(
      path,
      version: AppConstants.databaseVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  static Future<void> _onCreate(Database db, int version) async {
    // Documents table
    await db.execute('''
      CREATE TABLE documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_type TEXT NOT NULL,
        file_size INTEGER NOT NULL,
        folder_id INTEGER,
        page_count INTEGER DEFAULT 1,
        ocr_text TEXT,
        tags TEXT,
        is_favorite INTEGER DEFAULT 0,
        is_encrypted INTEGER DEFAULT 0,
        password_hash TEXT,
        thumbnail_path TEXT,
        cloud_sync_id TEXT,
        cloud_provider TEXT,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        accessed_at INTEGER,
        metadata TEXT
      )
    ''');

    await db.execute('CREATE INDEX idx_documents_folder ON documents(folder_id)');
    await db.execute('CREATE INDEX idx_documents_type ON documents(file_type)');
    await db.execute('CREATE INDEX idx_documents_favorite ON documents(is_favorite)');
    await db.execute('CREATE INDEX idx_documents_search ON documents(name, ocr_text)');

    // Folders table
    await db.execute('''
      CREATE TABLE folders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        parent_id INTEGER,
        color TEXT DEFAULT '#2196F3',
        icon TEXT DEFAULT 'folder',
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        FOREIGN KEY (parent_id) REFERENCES folders(id) ON DELETE CASCADE
      )
    ''');

    // Scan sessions table
    await db.execute('''
      CREATE TABLE scan_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        document_id INTEGER,
        status TEXT NOT NULL,
        filter_type TEXT DEFAULT 'color',
        created_at INTEGER NOT NULL,
        completed_at INTEGER
      )
    ''');

    // Scan pages table
    await db.execute('''
      CREATE TABLE scan_pages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id INTEGER NOT NULL,
        image_path TEXT NOT NULL,
        processed_path TEXT,
        page_number INTEGER NOT NULL,
        edge_points TEXT,
        filter_applied TEXT DEFAULT 'none',
        ocr_text TEXT,
        FOREIGN KEY (session_id) REFERENCES scan_sessions(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('CREATE INDEX idx_scan_pages_session ON scan_pages(session_id)');

    // OCR results table
    await db.execute('''
      CREATE TABLE ocr_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL,
        page_number INTEGER DEFAULT 1,
        recognized_text TEXT NOT NULL,
        language TEXT DEFAULT 'en',
        confidence REAL,
        created_at INTEGER NOT NULL,
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('CREATE INDEX idx_ocr_document ON ocr_results(document_id)');

    // Annotations table
    await db.execute('''
      CREATE TABLE annotations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_id INTEGER NOT NULL,
        page_number INTEGER NOT NULL,
        type TEXT NOT NULL,
        color TEXT,
        content TEXT,
        points TEXT,
        rect TEXT,
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL,
        FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('CREATE INDEX idx_annotations_doc ON annotations(document_id)');

    // Cloud accounts table
    await db.execute('''
      CREATE TABLE cloud_accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        provider TEXT NOT NULL,
        account_email TEXT NOT NULL,
        access_token TEXT,
        refresh_token TEXT,
        token_expiry INTEGER,
        sync_enabled INTEGER DEFAULT 1,
        last_sync_at INTEGER,
        created_at INTEGER NOT NULL
      )
    ''');

    // App settings table
    await db.execute('''
      CREATE TABLE app_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');

    // Insert default settings
    await db.insert('app_settings', {'key': 'theme_mode', 'value': 'system'});
    await db.insert('app_settings', {'key': 'language', 'value': 'en'});
    await db.insert('app_settings', {'key': 'biometric_enabled', 'value': 'false'});
    await db.insert('app_settings', {'key': 'pin_enabled', 'value': 'false'});
    await db.insert('app_settings', {'key': 'default_ocr_language', 'value': 'en'});
    await db.insert('app_settings', {'key': 'auto_enhance_scans', 'value': 'true'});
    await db.insert('app_settings', {'key': 'default_pdf_quality', 'value': 'medium'});

    // Conversion jobs table
    await db.execute('''
      CREATE TABLE conversion_jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_path TEXT NOT NULL,
        target_path TEXT,
        source_format TEXT NOT NULL,
        target_format TEXT NOT NULL,
        status TEXT NOT NULL,
        progress REAL DEFAULT 0,
        error_message TEXT,
        created_at INTEGER NOT NULL,
        completed_at INTEGER
      )
    ''');
  }

  static Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Handle migrations
  }

  static Future<void> close() async {
    if (_database != null) {
      await _database!.close();
      _database = null;
    }
  }
}
