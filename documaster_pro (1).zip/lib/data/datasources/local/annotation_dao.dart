import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../../models/annotation_model.dart';

class AnnotationDao {
  Future<Database> get _db async => await DatabaseHelper.database;

  Future<int> insertAnnotation(AnnotationModel annotation) async {
    final db = await _db;
    return await db.insert('annotations', annotation.toMap());
  }

  Future<List<AnnotationModel>> getAnnotationsForDocument(int documentId) async {
    final db = await _db;
    final maps = await db.query(
      'annotations',
      where: 'document_id = ?',
      whereArgs: [documentId],
      orderBy: 'created_at',
    );
    return maps.map((m) => AnnotationModel.fromMap(m)).toList();
  }

  Future<void> deleteAnnotation(int id) async {
    final db = await _db;
    await db.delete('annotations', where: 'id = ?', whereArgs: [id]);
  }
}
