import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../../models/folder_model.dart';

class FolderDao {
  Future<Database> get _db async => await DatabaseHelper.database;

  Future<List<FolderModel>> getAllFolders() async {
    final db = await _db;
    final maps = await db.query('folders', orderBy: 'name');
    return maps.map((m) => FolderModel.fromMap(m)).toList();
  }

  Future<FolderModel?> getFolderById(int id) async {
    final db = await _db;
    final maps = await db.query('folders', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return FolderModel.fromMap(maps.first);
  }

  Future<List<FolderModel>> getRootFolders() async {
    final db = await _db;
    final maps = await db.query(
      'folders',
      where: 'parent_id IS NULL',
      orderBy: 'name',
    );
    return maps.map((m) => FolderModel.fromMap(m)).toList();
  }

  Future<List<FolderModel>> getSubFolders(int parentId) async {
    final db = await _db;
    final maps = await db.query(
      'folders',
      where: 'parent_id = ?',
      whereArgs: [parentId],
      orderBy: 'name',
    );
    return maps.map((m) => FolderModel.fromMap(m)).toList();
  }

  Future<int> insertFolder(FolderModel folder) async {
    final db = await _db;
    return await db.insert('folders', folder.toMap());
  }

  Future<void> updateFolder(FolderModel folder) async {
    final db = await _db;
    await db.update(
      'folders',
      folder.toMap(),
      where: 'id = ?',
      whereArgs: [folder.id],
    );
  }

  Future<void> deleteFolder(int id) async {
    final db = await _db;
    await db.delete('folders', where: 'id = ?', whereArgs: [id]);
  }
}
