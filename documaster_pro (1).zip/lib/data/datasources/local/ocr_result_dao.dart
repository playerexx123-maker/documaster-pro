import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';
import '../../models/ocr_result_model.dart';

class OcrResultDao {
  Future<Database> get _db async => await DatabaseHelper.database;

  Future<int> insertOcrResult(OcrResultModel result) async {
    final db = await _db;
    return await db.insert('ocr_results', result.toMap());
  }

  Future<List<OcrResultModel>> getResultsForDocument(int documentId) async {
    final db = await _db;
    final maps = await db.query(
      'ocr_results',
      where: 'document_id = ?',
      whereArgs: [documentId],
      orderBy: 'page_number',
    );
    return maps.map((m) => OcrResultModel.fromMap(m)).toList();
  }

  Future<void> deleteResultsForDocument(int documentId) async {
    final db = await _db;
    await db.delete(
      'ocr_results',
      where: 'document_id = ?',
      whereArgs: [documentId],
    );
  }
}
