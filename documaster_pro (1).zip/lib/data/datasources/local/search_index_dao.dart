import 'package:sqflite/sqflite.dart';
import 'database_helper.dart';

class SearchIndexDao {
  Future<Database> get _db async => await DatabaseHelper.database;

  Future<void> rebuildIndex() async {
    final db = await _db;
    // Simple full-text search using LIKE queries on documents table
    // For production, consider using FTS5 virtual table
    await db.delete('search_index');
  }

  Future<List<Map<String, dynamic>>> search(String query) async {
    final db = await _db;
    return await db.rawQuery('''
      SELECT d.* FROM documents d
      WHERE d.name LIKE ? OR d.ocr_text LIKE ? OR d.tags LIKE ?
      ORDER BY d.updated_at DESC
    ''', ['%\$query%', '%\$query%', '%\$query%']);
  }
}
