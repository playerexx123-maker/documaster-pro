import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  AppTheme._();

  static const Color _primaryLight = Color(0xFF1565C0);
  static const Color _primaryDark = Color(0xFF90CAF9);
  static const Color _secondaryLight = Color(0xFF546E7A);
  static const Color _secondaryDark = Color(0xFFB0BEC5);

  static final ColorScheme _lightColorScheme = ColorScheme.fromSeed(
    seedColor: _primaryLight,
    brightness: Brightness.light,
    primary: _primaryLight,
    onPrimary: Colors.white,
    secondary: _secondaryLight,
    onSecondary: Colors.white,
    surface: const Color(0xFFF5F5F5),
    onSurface: const Color(0xFF212121),
    error: const Color(0xFFB00020),
    onError: Colors.white,
    surfaceVariant: const Color(0xFFE0E0E0),
    outline: const Color(0xFFBDBDBD),
  );

  static final ColorScheme _darkColorScheme = ColorScheme.fromSeed(
    seedColor: _primaryDark,
    brightness: Brightness.dark,
    primary: _primaryDark,
    onPrimary: const Color(0xFF0D47A1),
    secondary: _secondaryDark,
    onSecondary: const Color(0xFF263238),
    surface: const Color(0xFF1E1E1E),
    onSurface: const Color(0xFFE0E0E0),
    error: const Color(0xFFCF6679),
    onError: Colors.black,
    surfaceVariant: const Color(0xFF2C2C2C),
    outline: const Color(0xFF616161),
  );

  static final TextTheme _textTheme = TextTheme(
    displayLarge: GoogleFonts.roboto(fontSize: 57, fontWeight: FontWeight.w400),
    displayMedium: GoogleFonts.roboto(fontSize: 45, fontWeight: FontWeight.w400),
    displaySmall: GoogleFonts.roboto(fontSize: 36, fontWeight: FontWeight.w400),
    headlineLarge: GoogleFonts.roboto(fontSize: 32, fontWeight: FontWeight.w500),
    headlineMedium: GoogleFonts.roboto(fontSize: 28, fontWeight: FontWeight.w500),
    headlineSmall: GoogleFonts.roboto(fontSize: 24, fontWeight: FontWeight.w500),
    titleLarge: GoogleFonts.roboto(fontSize: 22, fontWeight: FontWeight.w500),
    titleMedium: GoogleFonts.roboto(fontSize: 16, fontWeight: FontWeight.w500),
    titleSmall: GoogleFonts.roboto(fontSize: 14, fontWeight: FontWeight.w500),
    bodyLarge: GoogleFonts.roboto(fontSize: 16, fontWeight: FontWeight.w400),
    bodyMedium: GoogleFonts.roboto(fontSize: 14, fontWeight: FontWeight.w400),
    bodySmall: GoogleFonts.roboto(fontSize: 12, fontWeight: FontWeight.w400),
    labelLarge: GoogleFonts.roboto(fontSize: 14, fontWeight: FontWeight.w500),
    labelMedium: GoogleFonts.roboto(fontSize: 12, fontWeight: FontWeight.w500),
    labelSmall: GoogleFonts.roboto(fontSize: 11, fontWeight: FontWeight.w500),
  );

  static ThemeData get lightTheme => ThemeData(
    useMaterial3: true,
    colorScheme: _lightColorScheme,
    textTheme: _textTheme,
    scaffoldBackgroundColor: _lightColorScheme.surface,
    appBarTheme: AppBarTheme(
      centerTitle: true,
      elevation: 0,
      scrolledUnderElevation: 1,
      backgroundColor: _lightColorScheme.surface,
      foregroundColor: _lightColorScheme.onSurface,
      titleTextStyle: _textTheme.titleLarge?.copyWith(
        color: _lightColorScheme.onSurface,
      ),
    ),
    cardTheme: CardTheme(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: _lightColorScheme.surface,
      selectedItemColor: _lightColorScheme.primary,
      unselectedItemColor: _lightColorScheme.onSurfaceVariant,
      type: BottomNavigationBarType.fixed,
      elevation: 8,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: _lightColorScheme.primary,
      foregroundColor: _lightColorScheme.onPrimary,
      shape: const CircleBorder(),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: _lightColorScheme.surfaceVariant.withOpacity(0.5),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _lightColorScheme.primary, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    dividerTheme: DividerThemeData(
      color: _lightColorScheme.outline.withOpacity(0.3),
      thickness: 1,
    ),
  );

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    colorScheme: _darkColorScheme,
    textTheme: _textTheme,
    scaffoldBackgroundColor: _darkColorScheme.surface,
    appBarTheme: AppBarTheme(
      centerTitle: true,
      elevation: 0,
      scrolledUnderElevation: 1,
      backgroundColor: _darkColorScheme.surface,
      foregroundColor: _darkColorScheme.onSurface,
      titleTextStyle: _textTheme.titleLarge?.copyWith(
        color: _darkColorScheme.onSurface,
      ),
    ),
    cardTheme: CardTheme(
      elevation: 1,
      color: _darkColorScheme.surfaceVariant,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: _darkColorScheme.surface,
      selectedItemColor: _darkColorScheme.primary,
      unselectedItemColor: _darkColorScheme.onSurfaceVariant,
      type: BottomNavigationBarType.fixed,
      elevation: 8,
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: _darkColorScheme.primary,
      foregroundColor: _darkColorScheme.onPrimary,
      shape: const CircleBorder(),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: _darkColorScheme.surfaceVariant.withOpacity(0.5),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: _darkColorScheme.primary, width: 2),
      ),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    dividerTheme: DividerThemeData(
      color: _darkColorScheme.outline.withOpacity(0.3),
      thickness: 1,
    ),
  );
}
