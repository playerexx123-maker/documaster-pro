import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../domain/entities/document.dart';

extension DateTimeExtension on DateTime {
  String get formatted => DateFormat('MMM d, yyyy').format(this);
  String get formattedShort => DateFormat('MMM d').format(this);
  String get timeAgo {
    final now = DateTime.now();
    final diff = now.difference(this);
    if (diff.inDays == 0) {
      if (diff.inHours == 0) return '${diff.inMinutes}m ago';
      return '${diff.inHours}h ago';
    }
    if (diff.inDays == 1) return 'Yesterday';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    if (diff.inDays < 30) return '${diff.inDays ~/ 7}w ago';
    return formatted;
  }
}

extension FileSizeExtension on int {
  String get fileSize {
    if (this < 1024) return '$this B';
    if (this < 1024 * 1024) return '${(this / 1024).toStringAsFixed(1)} KB';
    if (this < 1024 * 1024 * 1024) return '${(this / (1024 * 1024)).toStringAsFixed(1)} MB';
    return '${(this / (1024 * 1024 * 1024)).toStringAsFixed(1)} GB';
  }
}

extension FileTypeExtension on FileType {
  IconData get icon {
    switch (this) {
      case FileType.pdf:
        return Icons.picture_as_pdf;
      case FileType.docx:
        return Icons.description;
      case FileType.xlsx:
        return Icons.table_chart;
      case FileType.pptx:
        return Icons.slideshow;
      case FileType.txt:
      case FileType.md:
        return Icons.text_snippet;
      case FileType.csv:
        return Icons.table_rows;
      case FileType.json:
      case FileType.xml:
      case FileType.html:
        return Icons.code;
      case FileType.image:
        return Icons.image;
      default:
        return Icons.insert_drive_file;
    }
  }

  Color get color {
    switch (this) {
      case FileType.pdf:
        return Colors.red;
      case FileType.docx:
        return Colors.blue;
      case FileType.xlsx:
        return Colors.green;
      case FileType.pptx:
        return Colors.orange;
      case FileType.txt:
      case FileType.md:
        return Colors.grey;
      case FileType.csv:
        return Colors.teal;
      case FileType.json:
      case FileType.xml:
      case FileType.html:
        return Colors.indigo;
      case FileType.image:
        return Colors.purple;
      default:
        return Colors.blueGrey;
    }
  }
}

extension BuildContextExtension on BuildContext {
  ThemeData get theme => Theme.of(this);
  ColorScheme get colors => Theme.of(this).colorScheme;
  TextTheme get textTheme => Theme.of(this).textTheme;
  Size get screenSize => MediaQuery.of(this).size;
  bool get isTablet => MediaQuery.of(this).size.shortestSide >= 600;
  void showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(this).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? colors.error : colors.primary,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
