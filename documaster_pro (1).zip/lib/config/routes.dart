import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../presentation/pages/home_page.dart';
import '../presentation/pages/scanner/scanner_page.dart';
import '../presentation/pages/scanner/camera_page.dart';
import '../presentation/pages/scanner/scan_preview_page.dart';
import '../presentation/pages/ocr/ocr_result_page.dart';
import '../presentation/pages/files/files_page.dart';
import '../presentation/pages/files/folder_contents_page.dart';
import '../presentation/pages/editor/editor_page.dart';
import '../presentation/pages/ai_assistant/ai_assistant_page.dart';
import '../presentation/pages/settings/settings_page.dart';
import '../presentation/pages/converter/converter_page.dart';

class AppRouter {
  AppRouter._();

  static final _rootNavigatorKey = GlobalKey<NavigatorState>();
  static final _shellNavigatorKey = GlobalKey<NavigatorState>();

  static final router = GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/home',
    routes: [
      GoRoute(
        path: '/home',
        name: 'home',
        builder: (context, state) => const HomePage(),
      ),
      GoRoute(
        path: '/scanner',
        name: 'scanner',
        builder: (context, state) => const ScannerPage(),
        routes: [
          GoRoute(
            path: 'camera',
            name: 'camera',
            builder: (context, state) => const CameraPage(),
          ),
          GoRoute(
            path: 'preview',
            name: 'preview',
            builder: (context, state) => const ScanPreviewPage(),
          ),
        ],
      ),
      GoRoute(
        path: '/ocr/:documentId',
        name: 'ocr_result',
        builder: (context, state) {
          final documentId = int.tryParse(state.pathParameters['documentId'] ?? '');
          return OcrResultPage(documentId: documentId);
        },
      ),
      GoRoute(
        path: '/files',
        name: 'files',
        builder: (context, state) => const FilesPage(),
        routes: [
          GoRoute(
            path: 'folder/:id',
            name: 'folder',
            builder: (context, state) {
              final id = int.parse(state.pathParameters['id']!);
              return FolderContentsPage(folderId: id);
            },
          ),
        ],
      ),
      GoRoute(
        path: '/editor',
        name: 'editor',
        builder: (context, state) {
          final filePath = state.uri.queryParameters['path'];
          return EditorPage(filePath: filePath);
        },
      ),
      GoRoute(
        path: '/ai',
        name: 'ai',
        builder: (context, state) => const AiAssistantPage(),
      ),
      GoRoute(
        path: '/converter',
        name: 'converter',
        builder: (context, state) => const ConverterPage(),
      ),
      GoRoute(
        path: '/settings',
        name: 'settings',
        builder: (context, state) => const SettingsPage(),
      ),
    ],
  );
}
