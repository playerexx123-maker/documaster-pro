class AppConstants {
  AppConstants._();

  static const String appName = 'DocuMaster Pro';
  static const String appVersion = '1.0.0';
  static const String appPackage = 'com.documaster.pro';

  // Storage
  static const String appFolderName = 'DocuMasterPro';
  static const String scansFolderName = 'Scans';
  static const String documentsFolderName = 'Documents';
  static const String exportsFolderName = 'Exports';
  static const String thumbnailsFolderName = 'Thumbnails';
  static const String tempFolderName = 'Temp';

  // Database
  static const String databaseName = 'documaster.db';
  static const int databaseVersion = 1;

  // OCR Languages
  static const List<String> supportedOcrLanguages = [
    'en', 'ro', 'hu', 'de', 'it'
  ];

  static const Map<String, String> ocrLanguageNames = {
    'en': 'English',
    'ro': 'Romanian',
    'hu': 'Hungarian',
    'de': 'German',
    'it': 'Italian',
  };

  // File Types
  static const List<String> supportedFileExtensions = [
    '.pdf', '.docx', '.xlsx', '.pptx', '.txt', '.md',
    '.csv', '.json', '.xml', '.html', '.htm',
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp',
  ];

  // Scanning
  static const double defaultScanQuality = 2.0;
  static const int maxScanPages = 100;
  static const int scanCompressionQuality = 85;

  // PDF
  static const int pdfRenderWidth = 1200;
  static const int pdfThumbnailWidth = 200;

  // AI
  static const int maxAiInputLength = 10000;
  static const int maxChatHistory = 50;

  // Security
  static const int minPinLength = 4;
  static const int maxPinLength = 6;

  // Cloud
  static const int maxCloudFileSize = 100 * 1024 * 1024; // 100MB
  static const int syncIntervalMinutes = 30;
}

class StorageKeys {
  StorageKeys._();

  static const String themeMode = 'theme_mode';
  static const String language = 'language';
  static const String biometricEnabled = 'biometric_enabled';
  static const String pinEnabled = 'pin_enabled';
  static const String pinHash = 'pin_hash';
  static const String defaultOcrLanguage = 'default_ocr_language';
  static const String autoEnhanceScans = 'auto_enhance_scans';
  static const String defaultPdfQuality = 'default_pdf_quality';
  static const String cloudSyncEnabled = 'cloud_sync_enabled';
  static const String defaultCloudProvider = 'default_cloud_provider';
  static const String firstLaunch = 'first_launch';
}
